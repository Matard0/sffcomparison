from rdslibrary.core.read_write.SchemaReader import read

from .version import __version__
