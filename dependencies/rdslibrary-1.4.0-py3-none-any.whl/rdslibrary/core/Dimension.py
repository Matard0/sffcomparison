from __future__ import annotations

from typing import Any, List, Optional

import pyspark.sql.functions as F
from pyspark.sql.dataframe import DataFrame
from rdslibrary.utilities.spark import get_dbutils, get_spark

spark = get_spark()
dbutils = get_dbutils(spark)


class Dimension:
    """
    Generic class describing one schema dimension of Redslim standard format.

    Attributes:
        df: Dataframe reprensenting the dimension.
        standard_columns: Standard columns in the dataframe.
    """

    def __init__(
        self,
        df: Optional[DataFrame] = None,
        standard_columns: Optional[List[str]] = None,
    ):
        """Class constructor.

        Args:
            df: Dataframe reprensenting the dimension.
            standard_columns: Standard columns in the dataframe.
        """
        self.df: Optional[DataFrame] = df
        self.standard_columns: Optional[List[str]] = standard_columns

    def get_column_values(self, column: str) -> List[Any]:
        """Returns a list of values from a column of `self.df`.

        Argss:
            column: Name of the column to get values from.

        Returns:
            List of values in the specified column.
        """
        return [row[column] for row in self.df.select(column).collect()]

    def audit_null_check(self, columns: List[str]):
        """
        Raise an exception if `self.df` contains any null values in the provided columns.

        Raises:
            ValueError: Instance dataframe contains null values in the `column` column.

        """
        for column in columns:
            df = self.df.filter(F.col(column).isNull())
            if not df.rdd.isEmpty():
                raise ValueError(
                    f"Dimensions of type '{self.__class__}' contains null values in the '{column}' column."
                )

    def audit_value_in_column(self, column: str, value: str, require_unique: bool = True):
        """Raises an exception if `value` is not present or not unique in
        `column` of `self.df`.

        Raises:
            ValueError: See description.
        """
        results = self.df.filter(F.col(column) == value)
        count_of_value_in_column = results.count()
        if count_of_value_in_column == 0:
            results.show(truncate=False, vertical=True)
            dimension_name = str(self.__class__).split(".")[-1].split("'")[0]
            raise ValueError(
                f"The given value '{value}' is not present in the {column} column of {dimension_name}."
            )
        elif require_unique and count_of_value_in_column != 1:
            results.show(truncate=False, vertical=True)
            dimension_name = str(self.__class__).split(".")[-1].split("'")[0]
            raise ValueError(
                f"The given value '{value}' is not present or unique in the {column} column of {dimension_name}."
            )

    def audit_duplicates_column(self, columns: List[str]):
        """Raises an exception if `self.df` contains duplicates in any provided columns.

        Args:
            columns: List of columns for which you want to check for duplicates.

        Raises:
            ValueError: See description.
        """
        for column in columns:
            df = self.df.groupBy(column).count().filter("count > 1")
            if not df.rdd.isEmpty():
                df.show(truncate=False, vertical=True)
                raise ValueError(
                    f"Dimension of type '{self.__class__}' contains duplicates in the '{column}' column."
                )

    def get_field_type(self, field_name: str, sql_types: dict[str, str]) -> str:
        """Returns as string the SQL type of the `field_name` provided.

        Args:
            field_name: The name of the field for which we need to know the SQL type.
                e.g. `"VALUEHORSPROMO"`
            sql_types: A dictionary containing a mapping of column names to SQL types.
                e.g. `{"VALUE":"float", "VOLUME":"float", "URL":"varchar"}`
        """
        if (sql_types) and (field_name in sql_types.keys()) and (sql_types[field_name]):
            return sql_types[field_name]
        elif (field_name == "TAG") or (field_name.endswith("TAG")):
            return "varchar"
        # elif self.__class__ is Data:
        elif str(self.__class__).endswith("Data'>"):
            return "float"
        elif field_name in ["YEAR", "RANK"]:
            return "int"
        else:
            return "varchar"

    def generate_create_table_string(
        self,
        table_names: dict,
        schema_name: Optional[str] = "dbo",
        sql_types: Optional[dict[str, str]] = {},
        partition_column_name: Optional[str] = "PERIOD_TAG",
    ) -> str:
        """Returns as string a SQL table creation for `self.df`.

        Args:
            table_names: A dictionary of the different names a table will have in the swapping process
                e.g. {"new":"NEW_DANOVEG_PER", "current": "DANOVEG_PER", "old":"OLD_DANOVEG_PER"}
            schema_name: The name of the schema that the table needs to be created in. Defaults to "dbo".
                e.g. `"rdsmweb"`
            sql_types: A dictionary containing a mapping of column names to SQL types.
                e.g. `{"VALUE":"float", "VOLUME":"float", "URL":"varchar"}`
            partition_column_name: A string of the column name the FACT DATA table will be partitioned on.
                Defaults to "PERIOD_TAG"
        """
        # initialise an empty list of the fields
        fields = []
        # we first calculate all the field lengths
        df = self.df
        for col in df.columns:
            df = df.withColumn(col, F.length(F.col(col)))
        lengths = df.agg(*[F.max(col).alias(col) for col in df.columns]).collect()[0]
        del df
        # for each field, we will gather the field type and length, and then create a
        # string for these which is appended to the list called fields
        for field in self.df.schema:
            field_type = self.get_field_type(field.name, sql_types)
            if field_type in ["float", "int"]:
                field_length = ""
            else:
                field_length = lengths[field.name]
                # if the field_length is None, we set it to 1
                if not field_length:
                    field_length = 1
                field_length = f"({field_length})"
            if field.name in ["TAG", "MARKET_TAG", "PRODUCT_TAG", "PERIOD_TAG"]:
                fields.append(f"[{field.name}] [{field_type}]{field_length} NOT NULL")
            else:
                fields.append(f"[{field.name}] [{field_type}]{field_length} NULL")
        # using the fields list and other variables, we assemble a string which will create a SQL table
        # representing this dataframe
        creation_string = (
            f"CREATE TABLE {schema_name}.{table_names['new']} (" + ", ".join(fields) + ");"
        )
        return creation_string

    def upsert_column_value(
        self,
        column_to_populate: str,
        conditional_statement: str,
        value_to_populate: str,
        otherwise_value: str,
    ):
        """Function to allow passing of strings to either insert a new column or update values of an existing column.

        Args:
            column_to_populate: A string of the column to populate.
                e.g. [update value example] "GL Hierarchy"
                     [insert column example] "PRODUCTS"
            conditional_statement: A SQL like string that places a condition where to populate a column.
                Note that a column name with spaces should be surrounded in backticks.
                e.g. [update value example] "TAG = '000000J1E'"
                     [insert column example] "`GL Hierarchy` = 'TOTAL_PRODUCT'"
            value_to_populate: The value with which to populate the column if the conditional_statement returns true.
                Where this is a string, it should be surrounded with single quotes.
                Theoretically you could include other WHEN THEN clauses here, although it is not recommended.
                e.g. [update value example] "'TOTAL_PRODUCT'"
                     [insert column example] "'TOTAL_PRODUCT'"
            otherwise_value: The value with which to populate the column if the conditional_statement returns true.
                When this is updating a value in a column, simply put the column name in backticks to maintain all other values.
                Similar to above, where this is a string, it should be surrounded with single quotes.
                e.g. [update value example] "`GL Hierarchy`"
                     [insert column example] "'TOTAL_PRODUCT!ITEM'"
        """
        self.df = self.df.withColumn(
            column_to_populate,
            F.expr(
                f"CASE WHEN {conditional_statement} THEN {value_to_populate} ELSE {otherwise_value} END"
            ),
        )
