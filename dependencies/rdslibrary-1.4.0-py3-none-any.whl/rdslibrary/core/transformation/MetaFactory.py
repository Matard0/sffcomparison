import re
from typing import List, Optional, Tuple

import pyspark.sql.functions as F
from pyspark.sql.dataframe import DataFrame
from pyspark.sql.types import StringType
from rdslibrary.core.dimensions.Fact import Fact
from rdslibrary.core.dimensions.Market import Market
from rdslibrary.core.dimensions.Meta import Meta
from rdslibrary.core.dimensions.Period import Period
from rdslibrary.core.dimensions.Product import Product
from rdslibrary.utilities.spark import get_spark

spark = get_spark()


class MetaFactory:
    """
    Class describing the MetaFactory object.

    This object aims at providing functions to transform a dataframe into a meta dimension.

    Attributes:
        meta: Meta instance to create.
        df: Dataframe to use creating the meta instance.
        specific_columns: Selected columns in the dataframe.
        tag_type: Tagging style for the dimension.
    """

    def __init__(self, meta_type: type) -> None:
        """Class constructor.

        Args:
            meta_type: Type of the meta instance to create.
        """
        self.meta: Meta = meta_type()
        self.df: Optional[DataFrame] = None
        self.specific_columns: Optional[List[str]] = None
        self.tag_type: str = self.instanciate_tag_type(meta_type)

    @staticmethod
    def instanciate_tag_type(meta_type: type) -> str:
        """Returns a string corresponding to the required tag type depending on
        a given meta type.

        Args:
            meta_type: Type of the meta class, can be one of: `Market`, `Product`, `Period`, `Fact`.

        Raises:
            ValueError: The `meta_type` attribute is not allowed.
        """
        if meta_type is Product:
            tag_type = "md5"
        elif meta_type in [Market, Period, Fact]:
            tag_type = "concatenate"
        else:
            raise ValueError(f"Meta type '{meta_type}' is not allowed to tag.")
        return tag_type

    @staticmethod
    def rename_conflicting_columns(
        df: DataFrame,
        specific_columns: List[str],
        tag_columns: List[str],
        standard_columns: List[str],
    ) -> Tuple[DataFrame, List[str]]:
        """Updates a dataframe column names for columns whose name is conflicting
        with the meta instance standard columns.

        Specific columns are updated. Tag columns are updated if they are a list.

        Args:
            df: Dataframe of the meta instance.
            specific_columns: Specific columns of the dataframe.
            tag_columns: Tag columns of the dataframe.
            standard_columns: Standard columns of the meta instance.

        Returns:
            df: Dataframe with columns renamed.
            specific_columns: Renamed specific columns.
            tag_columns: Renamed tag columns.
        """
        for i in range(len(specific_columns)):
            column = specific_columns[i]
            if column in standard_columns:
                column_duplicate = column + "_DUPLICATE"
                specific_columns[i] = column_duplicate
                df = df.withColumnRenamed(column, column_duplicate)

        if isinstance(tag_columns, list):
            for i in range(len(tag_columns)):
                column = tag_columns[i]
                if column in standard_columns:
                    column_duplicate = column + "_DUPLICATE"
                    tag_columns[i] = column_duplicate

        return df, specific_columns, tag_columns

    @staticmethod
    def setup_dataframe_for_fact(
        df: DataFrame, specific_columns: List[str]
    ) -> Tuple[DataFrame, List[str]]:
        """Creates a dataframe and the proper specific columns for a fact instance given a couple
        of dataframe and specific columns.

        For facts the specific columns are pivoted into a single column dataframe.

        Args:
            df: Dataframe of the fact instance.
            specific_columns: Specific columns to use.

        Returns:
            df: New dataframe of the fact instance.
            specific_columns: Specific columns for the dataframe.
        """
        values = [(value,) for value in df.columns if value in specific_columns]
        df = spark.createDataFrame(values, ["__VALUE__"])
        specific_columns = ["__VALUE__"]
        return df, specific_columns

    @staticmethod
    def setup_dataframe_for_others(
        df: DataFrame, specific_columns: List[str]
    ) -> Tuple[DataFrame, List[str]]:
        """Creates a dataframe and the proper specific columns for a market, product, or period
        instance given a couple of dataframe and specific columns.

        Args:
            df: Dataframe of the meta instance.
            specific_columns: Specific columns to use.

        Returns:
            df: New dataframe of the meta instance.
            specific_columns: Specific columns for the dataframe.
        """
        if specific_columns is None:
            specific_columns = df.columns
        elif isinstance(specific_columns, list):
            pass
        else:
            raise ValueError(
                f"Argument 'specific_columns' cannot be of type '{type(specific_columns)}' when setting up a dataframe."
            )
        return df, specific_columns

    @staticmethod
    def generate_tags(
        df: DataFrame,
        specific_columns: List[str],
        tag_type: str,
        tag_columns: List[str],
        tag_name: str,
    ) -> DataFrame:
        """Populates a tag column in a dataframe based a tag type and a set of columns.

        Args:
            df: Dataframe to populate the tag column for.
            specific_columns: Specific columns to use.
            tag_type: Tag type, can be one of: `concatenate` or `md5`
            tag_columns: Columns to use to build the tags.
            tag_name: Name of the tag column to populate.

        Returns:
            df: Dataframe with populated tag column.
        """
        if tag_columns is None:
            tag_columns = specific_columns

        if tag_type == "concatenate":
            if isinstance(tag_columns, list):
                df = df.withColumn(
                    tag_name,
                    F.upper(F.regexp_replace(F.concat_ws("", *tag_columns), r"[^A-Za-z0-9]", "")),
                )
            elif isinstance(tag_columns, str):
                value = re.sub(r"\s+", " ", tag_columns.strip().upper())
                df = df.withColumn(tag_name, F.lit(value))
            else:
                raise ValueError(
                    f"Parameter 'tag_columns' cannot be of type '{type(tag_columns)}' for tag generation with 'concatenate'."
                )

        elif tag_type == "md5":
            if isinstance(tag_columns, list):
                df = df.withColumn(
                    tag_name,
                    F.upper(F.md5(F.concat_ws("", *tag_columns))),
                )
            else:
                raise ValueError(
                    f"Parameter 'tag_columns' cannot be of type '{type(tag_columns)}' for tag generation with 'md5'."
                )

        else:
            raise AttributeError(f"Tag type '{tag_type}' is not implemented in xxx.")

        return df

    @staticmethod
    def concatenate_standard_columns(
        df: DataFrame, specific_columns: List[str], standard_columns: List[str]
    ) -> DataFrame:
        """Concatenates empty standard columns to a meta instance dataframe.

        Columns `"TAG"` is not added and should already exist in the dataframe.
        Standard columns are put in front of the specific columns

        Args:
            df: Dataframe to add columns to.
            specific_columns: Specific columns in the meta instance dataframe.
            standard_columns: Standard columns to add to the meta instance dataframe.

        Returns:
            df: Dataframe with standard columns concatenated.
        """

        columns = [c for c in standard_columns if c != "TAG"]
        for column in columns:
            df = df.withColumn(column, F.lit(None).cast(StringType()))

        df = df.select(standard_columns + specific_columns)
        return df

    def create_from_dataframe(
        self, df: DataFrame, specific_columns: List[str], tag_columns: List[str]
    ) -> Tuple[Meta, DataFrame]:
        """Main function of the class preparing the meta instance.

        A second dataframe, result of the intermediate processing is also produced.
        This is helpful in the context of a table transformation.

        Args:
            df: Dataframe to use creating the meta instance.
            specific_columns: Selected columns in the dataframe.
            tag_columns: Tag columns of the dataframe.

        Returns:
            meta: Instanciate meta instance.
            df_unrefined: Instance dataframe without column selection and duplicates dropping.
        """
        # Define the self.df and self.specific_columns
        if self.meta.__class__ is Fact:
            self.df, self.specific_columns = self.setup_dataframe_for_fact(df, specific_columns)
        elif self.meta.__class__ in [Market, Product, Period]:
            self.df, self.specific_columns = self.setup_dataframe_for_others(df, specific_columns)
        else:
            # This case cannot happen due to controls when instanciating the class
            pass

        # Remove potential column conflicts between the specific_columns and the
        # meta standard columns
        self.df, self.specific_columns, tag_columns = self.rename_conflicting_columns(
            self.df, self.specific_columns, tag_columns, self.meta.standard_columns
        )

        # Generate tags
        data_tag_name = f"{self.meta.__class__.__name__.upper()}_TAG"
        self.df = self.generate_tags(
            self.df,
            self.specific_columns,
            self.tag_type,
            tag_columns,
            data_tag_name,
        )

        # Keep unrefined
        if self.meta.__class__ is Fact:
            df_unrefined = df
        elif self.meta.__class__ in [Market, Product, Period]:
            df_unrefined = self.df
        else:
            raise ValueError(f"Dimension type '{self.meta.__class__}' is not allowed.")

        # Extract the final dataframe with tag and specific columns
        self.df = (
            self.df.withColumnRenamed(data_tag_name, "TAG")
            .select(["TAG"] + self.specific_columns)
            .dropDuplicates()
        )

        # Add the standard columns to the final dataframe
        self.meta.df = self.concatenate_standard_columns(
            self.df, self.specific_columns, self.meta.standard_columns
        )

        return self.meta, df_unrefined
