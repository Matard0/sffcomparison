from __future__ import annotations

import fnmatch
import os
import re
from typing import Optional, Union

from pyspark.sql.dataframe import DataFrame
from pyspark.sql.utils import AnalysisException
from rdslibrary.utilities.spark import get_dbutils, get_spark
from rdslibrary.utilities.testing import column_names_are_duplicated_modulo_index

spark = get_spark()
dbutils = get_dbutils(spark)


class SchemaReader:
    """
    Class describing the SchemaReader object.

    This object aims at providing functions to read data into a schema of Redslim standard format.

    Attributes:
        market: Specify how to identify the market dimension.
        product: Specify how to identify the product dimension.
        period: Specify how to identify the period dimension.
        fact: Specify how to identify the fact dimension.
        data: Specify how to identify the data dimension.
        apply_special_cases_on_read: Apply known special cases to schema dimension
            dataframe to manage data provider specificities.
        duplicated_columns_renaming_selection_method: A string specifying the method of deduplication.The options are:

            - `"first"` : deduplicate the column with the lowest index.
            - `"most_values"` : deduplicate the column with the most values.
        case_sensitive: A boolean indicating the value for the spark config value "spark.sql.caseSensitive"
    """

    def __init__(
        self,
        market: Union[str, bool],
        product: Union[str, bool],
        period: Union[str, bool],
        fact: Union[str, bool],
        data: Union[str, bool],
        apply_special_cases_on_read: bool,
        duplicated_columns_renaming_selection_method: str,
        case_sensitive: bool,
    ):
        """Class constructor.

        Args:
            market: Specify how to identify the market dimension.
            product: Specify how to identify the product dimension.
            period: Specify how to identify the period dimension.
            fact: Specify how to identify the fact dimension.
            data: Specify how to identify the data dimension.
            apply_special_cases_on_read: Apply known special cases to schema dimension
                dataframe to manage data provider specificities.
            duplicated_columns_renaming_selection_method: A string specifying the method of deduplication. The options are:

                - `"first"` : deduplicate the column with the lowest index.
                - `"most_values"` : deduplicate the column with the most values.
            case_sensitive: A boolean indicating the value for the spark config value "spark.sql.caseSensitive".
        """
        self.market: Union[str, bool] = market
        self.product: Union[str, bool] = product
        self.period: Union[str, bool] = period
        self.fact: Union[str, bool] = fact
        self.data: Union[str, bool] = data
        self.apply_special_cases_on_read: bool = apply_special_cases_on_read
        self.duplicated_columns_renaming_selection_method: str = (
            duplicated_columns_renaming_selection_method
        )
        self.case_sensitive: bool = case_sensitive

    def blob(
        self,
        path: str,
        sep: Optional[str] = ",",
        encoding: Optional[str] = "UTF-8",
        search_enriched: Optional[bool] = True,
        regex_to_replace_from_column_names: Optional[str] = r"\.|`|\s$",
    ):
        r"""Reads a standard schema from blob storage.

        Supported storage options are:

        - Azure Blob Storage (mounted or not)
        - Azure Data Lake Storage Gen2 (mounted or not)

        Supported dimension formats are parquet, delta, and csv. The function
        dynamically detects which format to read.

        Files are detected based on the provided patterns of the `SchemaReader` instance.

        A schema needs to be contained in a single directory.

        Args:
            path: Path to the directory containing the schema.
            sep: Delimiter to use to read the files belonging to the schema.
            encoding: Encoding to use to read the text files belonging to the schema.
            search_enriched: Specify if enriched dimensions from the schema need
                to be read when available.
            regex_to_replace_from_column_names: A regular expression containing a list of options of characters to replace from column names.
                defaults to `r"\.|`|\s$"` or otherwise for example `r"\.|`|%"`
        """
        from rdslibrary.core.schema import Schema

        spark.conf.set("spark.sql.caseSensitive", self.case_sensitive)

        # Format path
        if path.startswith("abfss://"):
            pass
        elif path.startswith("wasbs://"):
            pass
        else:
            path = path if path[0] != "/" else path[1:]
            path = path if path.startswith("dbfs:/mnt") else os.path.join("dbfs:/mnt", path)

        # Define the dimensions pattern
        dimensions_pattern = {
            "market": self.market,
            "product": self.product,
            "period": self.period,
            "fact": self.fact,
            "data": self.data,
        }

        # Assign a path for each dimension
        # Assign None if the pattern provided by the user is False
        ls = dbutils.fs.ls(path)
        dimensions_path = {
            dimension: self.get_dimension_path_to_read(
                ls=ls, search_enriched=search_enriched, pattern=pattern
            )
            if pattern
            else None
            for dimension, pattern in dimensions_pattern.items()
        }

        # Assign a dataframe for each dimension
        # Assign None if the path is None
        dimensions_dataframe = {
            dimension: self.read_dataframe_from_blob(path, sep=sep, encoding=encoding)
            if path is not None
            else None
            for dimension, path in dimensions_path.items()
        }

        # Initialize the schema
        sch = Schema(**dimensions_dataframe)

        # Apply known special cases
        if self.apply_special_cases_on_read:
            sch = sch.apply_special_cases_on_read()

        # Replace problematic characters (".", "`", "$", ...) from data fact tags
        if sch.data is not None:
            sch.data.replace_problematic_characters_from_fact_tags()

        # Replace problematic characters (".", "`", "$", ...) from fact tags
        if sch.fact is not None:
            sch.fact.replace_problematic_characters_from_tags()

        # Check that the fact tags are identical between the data and fact dataframes post replacement
        if sch.data is not None and sch.fact is not None:
            sch.audit_fact_tags_are_coherent_between_data_and_fact()

        # Handle problematic characters (".", "`") from product columns
        if sch.product is not None:
            sch.product.replace_characters_from_column_names(
                pattern=regex_to_replace_from_column_names, replacement="_"
            )

        # Handle problematic characters (".", "`") from market columns
        if sch.market is not None:
            sch.market.replace_characters_from_column_names(
                pattern=regex_to_replace_from_column_names, replacement="_"
            )

        # Handle duplicated modulo index column names
        for dimension in [
            dim for dim in ["fact", "period", "product", "market"] if dimensions_dataframe[dim]
        ]:
            (
                duplicate_columns_present,
                duplicate_columns,
            ) = column_names_are_duplicated_modulo_index(sch.__getattribute__(dimension).df)

            if duplicate_columns_present:
                sch.__getattribute__(dimension).rename_duplicated_modulo_index(
                    duplicate_columns,
                    selection_method=self.duplicated_columns_renaming_selection_method,
                )

        return sch

    @staticmethod
    def get_dimension_path_to_read(ls: list, search_enriched: bool, pattern: str) -> str:
        r"""Returns the path of file to read, given a list of dbutils file infos and parameters.

        - If pattern does not contain `"*"`, an exact file name match if going to be expected.
        - If pattern does contain `"*"`:

            - If search_enriched is `True`, a file names matching the pattern and regex
            `r".*_RDSLM(\.csv|/)[\.a-z0-9]*$"` will be selected. If no match is found, a
            file name only matching the pattern is selected.
            - If search_enriched is `False`, only a file name matching the pattern and not matching
            regex `r".*_RDSLM(\.csv|/)[\.a-z0-9]*$"` will be selected.

        Args:
            ls: List of dbutils file infos, typically given by `dbutils.fs.ls(...)`.
            search_enriched: Specify if an enriched file is expected.
            pattern: Wildcard pattern representing the searched file name.

        Returns:
            Best matching path given the conditions.

        Raises:
            ValueError: More than one files matched the conditions.
            ValueError: No file matched the conditions.
        """
        result = None
        if "*" in pattern:
            candidates = [f for f in ls if fnmatch.fnmatch(f.name, pattern)]
            nonenriched_candidates = [
                f.path
                for f in candidates
                if not bool(re.match(r".*_RDSLM(\.csv|/)[\.a-z0-9]*$", f.name))
            ]
            if search_enriched:
                enriched_candidates = [
                    f.path
                    for f in candidates
                    if bool(re.match(r".*_RDSLM(\.csv|/)[\.a-z0-9]*$", f.name))
                ]
                candidates = (
                    enriched_candidates if len(enriched_candidates) > 0 else nonenriched_candidates
                )
            else:
                candidates = nonenriched_candidates
        else:
            candidates = [f.path for f in ls if f.name == pattern]

        if len(candidates) > 1:
            raise ValueError(
                f"Too many files matched pattern '{pattern}' during read: {candidates}."
            )
        elif len(candidates) == 0:
            raise ValueError(f"No file matched pattern '{pattern}' during read.")
        else:
            result = candidates[0]

        return result

    @staticmethod
    def read_dataframe_from_blob(
        path: str, sep: Optional[str] = None, encoding: Optional[str] = None
    ) -> DataFrame:
        """Returns a dataframe read from a blob file or directory path.

        The format of the file or directory to read is dynamically detected.

        - If the path ends with `"/"` a parquet or delta will be read.
        - If the path does not end with `"/"` a csv with separator and encoding will be read.

        Args:
            path: Path to the file or folder to read as a dataframe.
            sep: Delimiter to parse on if the file is a text file.
            encoding: Encoding to use if the file is a text file.

        Raises:
            AnalysisException: If provided path could not be read as parquet and delta.

        Returns:
            Dataframe representing the file or folder at the provided path.
        """
        df = None
        path_is_a_directory = path[-1] == "/"
        if path_is_a_directory:
            # Read parquet and if failure read delta
            try:
                df = spark.read.parquet(path)
            except AnalysisException:
                try:
                    df = spark.read.format("delta").load(path)
                except AnalysisException as e:
                    raise AnalysisException(
                        f"Path '{path}' could not be read as parquet and delta into a dataframe.",
                        e.stackTrace,
                    )
        else:
            # Read csv
            df = spark.read.csv(path, sep=sep, encoding=encoding, header=True)
        return df


def read(
    market: Union[str, bool] = "*MKT*",
    product: Union[str, bool] = "*PROD*",
    period: Union[str, bool] = "*PER*",
    fact: Union[str, bool] = "*FCT*",
    data: Union[str, bool] = "*DATA*",
    apply_special_cases_on_read: Optional[bool] = True,
    duplicated_columns_renaming_selection_method: Optional[str] = "first",
    case_sensitive: Optional[bool] = True,
) -> SchemaReader:
    """Main entry point to read a schema of Redslim standard format.

    Args:
        market: Specify how to identify the market dimension.
        product: Specify how to identify the product dimension.
        period: Specify how to identify the period dimension.
        fact: Specify how to identify the fact dimension.
        data: Specify how to identify the data dimension.
        apply_special_cases_on_read: Apply known special cases to schema dimension
            dataframe to manage data provider specificities.
        duplicated_columns_renaming_selection_method: A string specifying the method of deduplication. The options are:

            - `"first"` : deduplicate the column with the lowest index.
            - `"most_values"` : deduplicate the column with the most values.
        case_sensitive: A boolean indicating the value for the spark config value "spark.sql.caseSensitive".
    """
    return SchemaReader(
        market=market,
        product=product,
        period=period,
        fact=fact,
        data=data,
        apply_special_cases_on_read=apply_special_cases_on_read,
        duplicated_columns_renaming_selection_method=duplicated_columns_renaming_selection_method,
        case_sensitive=case_sensitive,
    )


def write_dataframe_to_mounted_csv(
    df: DataFrame,
    path: str,
    sep: str,
    encoding: str,
    compression: Optional[str] = None,
):
    """Creates mounted csv folder from dataframe.

    All partitions are written to a single file using `coalesce` equals 1.

    Args:
        path: Path to the csv file to write without compression suffix.
        sep: Delimiter to use to write the text file.
        encoding: Encoding to use to write the text file.
        compression: Compression to use to write the text file, can be `None`,
            `"bzip2"`, `"gzip"`.
    """
    # Add compression suffix to file_name to search for preexisting files
    if compression == "bzip2":
        path += ".bz2"
    elif compression == "gzip":
        path += ".gz"
    else:
        pass

    temporary_directory = path + ".tmp"
    dbutils.fs.rm(temporary_directory, recurse=True)

    # Save as a single text file in a temporary directory
    df.coalesce(1).write.csv(
        path=temporary_directory,
        sep=sep,
        encoding=encoding,
        header=True,
        emptyValue="\u0000",
        compression=compression,
    )


def swap_csv_after_write(path: str, compression: str):
    """Swaps existing csv inside of temporary folder with original csv.

    Args:
        path: Path to the original csv file to swap, a folder called `path + ".tmp"` containing a
            csv starting with `"part-00000"` must also be available.
        compression: Compression to use to write the text file, can be `None`,
            `"bzip2"`, `"gzip"`.
    """
    # Add compression suffix to file_name to search for preexisting files
    if compression == "bzip2":
        path += ".bz2"
    elif compression == "gzip":
        path += ".gz"
    else:
        pass

    # Detect prexisting files
    directory = os.path.dirname(path)
    file_name = os.path.basename(os.path.normpath(path))
    matching_preexisting_files = [
        x
        for x in dbutils.fs.ls(directory)
        if file_name == os.path.basename(os.path.normpath(x.path))
    ]

    # Detect file to use in temporary directory
    temporary_directory = os.path.join(directory, file_name + ".tmp")
    temporary_file_infos = dbutils.fs.ls(temporary_directory)
    temporary_path = [
        file_info.path
        for file_info in temporary_file_infos
        if file_info.name.startswith("part-00000")
    ][0]

    # Remove pre-existing files
    if len(matching_preexisting_files) == 0:
        pass
    elif len(matching_preexisting_files) == 1:
        file_info = matching_preexisting_files[0]
        if file_info.isDir():
            # If the path is a directory, delete it recursively.
            dbutils.fs.rm(path, recurse=True)
        else:
            # If the path is a file, it will be overwritten.
            pass
    else:
        raise ValueError(f"Too many files matched path '{path}' on writting.")

    # Rename temporary path to expected path
    # If working locally use dbutils, if working on databricks use standard python packages.
    # This is designed to overcome the dbutils limitation for large files.
    # This means that when running locally, large files (+200MB) cannot be written as csv!
    if "DATABRICKS_RUNTIME_VERSION" in os.environ:
        os.rename(temporary_path.replace("dbfs:", "/dbfs"), path.replace("dbfs:", "/dbfs"))
    else:
        dbutils.fs.mv(temporary_path, path)
    dbutils.fs.rm(temporary_directory, recurse=True)
