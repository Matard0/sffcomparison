from __future__ import annotations

import os
import re
from typing import Any, Optional, Union

from pyspark.sql.dataframe import DataFrame
from rdslibrary.core.read_write.SchemaReader import (
    swap_csv_after_write,
    write_dataframe_to_mounted_csv,
)
from rdslibrary.utilities.spark import get_dbutils, get_spark

spark = get_spark()
dbutils = get_dbutils(spark)


class SchemaWriter:
    """
    Class describing the SchemaWriter object.

    This object aims at providing functions to write a schema of Redslim standard format.

    Attributes:
        sch: Schema instance to write.
        market: Specify how to name the market dimension.
        product: Specify how to name the product dimension.
        period: Specify how to name the period dimension.
        fact: Specify how to name the fact dimension.
        data: Specify how to name the data dimension.
        modes: Writing format modes supported.
    """

    def __init__(
        self,
        sch,
        market: Union[str, bool],
        product: Union[str, bool],
        period: Union[str, bool],
        fact: Union[str, bool],
        data: Union[str, bool],
    ):
        """Class constructor.

        Args:
            sch: Schema instance to write.
            market: Specify how to name the market dimension.
            product: Specify how to name the product dimension.
            period: Specify how to name the period dimension.
            fact: Specify how to name the fact dimension.
            data: Specify how to name the data dimension.
        """
        self.sch: Union[str, bool] = sch
        self.market: Union[str, bool] = market
        self.product: Union[str, bool] = product
        self.period: Union[str, bool] = period
        self.fact: Union[str, bool] = fact
        self.data: Union[str, bool] = data

        self.modes: dict[str, dict[str, Any]] = {
            "csv": {
                "market": ("csv", None),
                "product": ("csv", None),
                "period": ("csv", None),
                "fact": ("csv", None),
                "data": ("csv", None),
            },
            "parquet": {
                "market": ("parquet", None),
                "product": ("parquet", None),
                "period": ("parquet", None),
                "fact": ("parquet", None),
                "data": ("parquet", None),
            },
            "delta": {
                "market": ("delta", None),
                "product": ("delta", None),
                "period": ("delta", None),
                "fact": ("delta", None),
                "data": ("delta", None),
            },
            "csv_bzip2_compressed": {
                "market": ("csv", "bzip2"),
                "product": ("csv", "bzip2"),
                "period": ("csv", "bzip2"),
                "fact": ("csv", "bzip2"),
                "data": ("csv", "bzip2"),
            },
            "csv_data_bzip2_compressed": {
                "market": ("csv", None),
                "product": ("csv", None),
                "period": ("csv", None),
                "fact": ("csv", None),
                "data": ("csv", "bzip2"),
            },
            "csv_data_parquet": {
                "market": ("csv", None),
                "product": ("csv", None),
                "period": ("csv", None),
                "fact": ("csv", None),
                "data": ("parquet", None),
            },
        }

    def blob(
        self,
        path: str,
        sep: Optional[str] = ",",
        encoding: Optional[str] = "UTF-8",
        mode: Optional[str] = "parquet",
        prefix: Optional[str] = None,
    ):
        """Writes a standard schema to blob storage.

        Supported storage options are:

        - Azure Blob Storage (mounted or not)
        - Azure Data Lake Storage Gen2 (mounted or not)

        When writing delta and parquet, columns are formated accordingly to format necessities. Row
        values are updated when needed, especially for hierarchies.

        Warning:
            The writing of csv is only supported for mounted storage.

        Args:
            path: Path to the directory to write the schema in.
            sep: Delimiter to use for text files belonging to the schema.
            encoding: Encoding to use for text files belonging to the schema.
            mode: Format to use to write the schema, can be `"parquet"`, `"delta"`, `"csv"`, `"csv_data_bzip2_compressed"`, or `"csv_data_parquet"`.
            prefix: Prefix to set in front of file or directory name when writing.
        """
        # Format path
        if path.startswith("abfss://"):
            pass
        elif path.startswith("wasbs://"):
            pass
        else:
            path = path if path[0] != "/" else path[1:]
            path = path if path.startswith("dbfs:/mnt") else os.path.join("dbfs:/mnt", path)

        # Assign the dimensions name
        dimensions_name = {
            "market": self.market,
            "product": self.product,
            "period": self.period,
            "fact": self.fact,
            "data": self.data,
        }

        # Assign the dimensions path
        # Only keep dimensions where the name is different from False
        mode = self.modes[mode]
        dimensions_path = {
            dimension: self.get_dimension_path_to_write(
                path=path, form=mode[dimension][0], prefix=prefix, name=name
            )
            for dimension, name in dimensions_name.items()
            if name
        }

        # Assign schema instance to each dimension
        dimensions_instance = {
            "market": self.sch.market,
            "product": self.sch.product,
            "period": self.sch.period,
            "fact": self.sch.fact,
            "data": self.sch.data,
        }

        # Assign a dataframe to write for each dimension
        # Only keep dimensions where the dataframe is different from None
        dimensions_instance_with_dataframe = {
            dimension: instance
            for dimension, instance in dimensions_instance.items()
            if getattr(instance, "df", None) is not None
        }

        # Write the dataframes
        # A dimension is written if the path is not None and
        # if the dataframe is also not None.
        dims_with_path = set(dimensions_path.keys())
        dims_with_dataframe = set(dimensions_instance_with_dataframe.keys())
        dims_to_write = list(dims_with_path.intersection(dims_with_dataframe))
        dims_to_write.sort(reverse=True)  # Sort to avoid write order inconsistency

        # Write
        for dimension in dims_to_write:
            p = dimensions_path[dimension]
            instance = dimensions_instance_with_dataframe[dimension]
            f, compression = mode[dimension]
            # Format columns to meet parquet and delta requirements when needed
            if dimension != "data" and f in ["parquet", "delta"]:
                instance.replace_characters_from_column_names(r"\s|,|;|\{|\}|\(|\)|\=", "_")
            df = instance.df
            self.write_dataframe_to_blob(
                df=df,
                path=p,
                form=f,
                compression=compression,
                sep=sep,
                encoding=encoding,
            )

        # Swap temporary csv after write with original ones.
        # Removal of originals need to happen once all dataframes have been written
        # otherwise some dataframes might get emptied.
        for dimension in dims_to_write:
            f, compression = mode[dimension]
            if f == "csv":
                p = dimensions_path[dimension]
                swap_csv_after_write(path=p, compression=compression)

    @staticmethod
    def get_dimension_path_to_write(
        path: str, form: str, name: str, prefix: Optional[str] = None
    ) -> str:
        r"""Returns the path of file to write given a blob directory path and a set of parameters.

        - If name matches regex `r".*(\.csv|/)$"`, the name with prefix is taken as is, the format argument is not used.
        - If name does not matche regex `r".*(\.csv|/)$"`, depending on the format, the file name with prefix is completed
            with an extension or a forward slash.

        Args:
            path: Directory path for the file to be written in.
            form: File type to be used, can be `"csv"`, `"parquet"`, or `"delta"`.
            prefix: String to add in front of the file name.
            name: Name of the file.

        Return:
            Path according to the given parameters.

        Raises:
            ValueError: If provided format is not supported.
        """
        # Set prefix to empty if None
        if prefix is None:
            prefix = ""

        result = None
        if bool(re.match(r".*(\.csv|/)$", name)):
            result = os.path.join(path, prefix + name)
        else:
            if form == "csv":
                result = os.path.join(path, prefix + name + ".csv")
            elif form == "parquet" or form == "delta":
                result = os.path.join(path, prefix + name)
            else:
                raise ValueError(f"Format '{form}' is not supported during write.")
        return result

    @staticmethod
    def write_dataframe_to_blob(
        df: DataFrame,
        path: str,
        form: str,
        sep: Optional[str] = ",",
        encoding: Optional[str] = None,
        compression: Optional[str] = None,
    ):
        """Writes dataframe to blob storage path depending on parameters.

        Args:
            df: Dataframe to write.
            path: Mounted path to write to.
            form: Format to use when writing, can be `"parquet"`, `"csv"`, or `"delta"`.
            sep: Delimiter to use to write with csv format.
            encoding: Encoding to use to write with csv format.
            compression: Compression to use to write with csv format, can be `None`,
                `"bzip2"`, or `"gzip"`.

        Raises:
            ValueError: If provided format is not supported.
        """
        if form == "parquet":
            df.write.parquet(path, compression=compression, mode="overwrite")
        elif form == "delta":
            df.write.format("delta").mode("overwrite").save(path)
        elif form == "csv":
            # Write only works on mounted csv!
            write_dataframe_to_mounted_csv(
                df=df, path=path, sep=sep, encoding=encoding, compression=compression
            )
        else:
            raise ValueError(f"Format '{form}' is not supported during write.")
