from __future__ import annotations

import re
from functools import reduce
from typing import Dict, List, Optional, Union

import pyspark.sql.functions as F
from pyspark.sql import Row
from pyspark.sql.column import Column
from pyspark.sql.dataframe import DataFrame
from pyspark.sql.types import DoubleType, IntegerType, StringType, StructField, StructType
from pyspark.sql.window import Window
from rdslibrary.core.dimensions.Data import Data
from rdslibrary.core.dimensions.Fact import Fact
from rdslibrary.core.dimensions.Market import Market
from rdslibrary.core.dimensions.Period import Period
from rdslibrary.core.dimensions.Product import Product
from rdslibrary.core.read_write.SchemaWriter import SchemaWriter
from rdslibrary.core.transformation.MetaFactory import MetaFactory
from rdslibrary.utilities.functions import create_condition, group_dictionaries
from rdslibrary.utilities.spark import get_spark
from rdslibrary.utilities.testing import columns_have_duplicates

spark = get_spark()


class Schema:
    """
    Class describing the schema object for Redslim standard format.

    Attributes:
        market: Market object to represent the market dimension.
        product: Product object to represent the product dimension.
        period: Period object to represent the period dimension.
        fact: Fact object to represent the fact dimension.
        data: Data object to represent the data dimension.
    """

    def __init__(
        self,
        market: Union[DataFrame, Market, None] = None,
        product: Union[DataFrame, Product, None] = None,
        period: Union[DataFrame, Period, None] = None,
        fact: Union[DataFrame, Fact, None] = None,
        data: Union[DataFrame, Data, None] = None,
    ) -> None:
        """Class constructor.

        Args:
            market: Market object to represent the market dimension.
            product: Product object to represent the product dimension.
            period: Period object to represent the period dimension.
            fact: Fact object to represent the fact dimension.
            data: Data object to represent the data dimension.
        """
        self.market: Optional[Market] = Market(market) if isinstance(market, DataFrame) else market
        self.product: Optional[Product] = (
            Product(product) if isinstance(product, DataFrame) else product
        )
        self.period: Optional[Period] = Period(period) if isinstance(period, DataFrame) else period
        self.fact: Optional[Fact] = Fact(fact) if isinstance(fact, DataFrame) else fact
        self.data: Optional[Data] = Data(data) if isinstance(data, DataFrame) else data

    def translate_tags(self, name: str, meta: str, data: str):
        """Replaces existing meta data tags with new values from the `meta` column in a selected dimension.

        Args:
            name: Name of the dimension to translate tag from, can be `"market"`, `"product"`, or `"period"`.
            meta: Column used as mapping in the meta dimension dataframe.
            data: Column to translate in the data dimension dataframe.

        Raises:
            Exception: Column `meta` has duplicated values in the meta data dataframe.
        """
        dimension = self.__getattribute__(name)

        # Check if the meta and data columns do not have duplicates
        assertion, df_duplicates = columns_have_duplicates(dimension.df, [meta])
        if assertion:
            df_duplicates.show(truncate=False, vertical=True)
            raise ValueError(f"Column meta '{meta}' contains duplicates, no translation possible.")

        # Define the mapping
        df_tag_mapping = dimension.df.select(["TAG", meta])

        # Apply the mapping
        self.data.df = self.data.df.join(df_tag_mapping, self.data.df[data] == df_tag_mapping[meta])
        self.data.df = self.data.df.withColumnRenamed("TAG", name.upper() + "_" + "TAG")
        self.data.df = self.data.df.drop(meta, data)

    def translate_facts(self, source: str, target: str, factor_columns: List[str] = []):
        """Translates facts into target values while optionally applying factors.

        The method modifies the fact and data dataframes.

        - In the fact dataframe, the `"TAG"` column will be replaced by the `target` column where the
        value of target is not null.
        - In the data dataframe, the column names will be updated with the new tags. If factor columns
        are passed, factors from the fact dataframe will be applied to the data.

        The resulting facts will be sorted in an ascending manner both in the data and in the fact.

        Args:
            source: Column used as source in the translation.
            target: Column used as target in the translation.
            factor_columns: Columns containing factors to apply on the data values.

        Raises:
            Exception: If columns `source` or `target` have duplicated values.
        """
        # Filter out empty targets in the fact dataframe and order by target
        self.fact.df = self.fact.df.where(F.col(target).isNotNull()).orderBy(target)

        # Check if the source and target columns do not have duplicates
        for name, value in [("source", source), ("target", target)]:
            assertion, df_duplicates = columns_have_duplicates(self.fact.df, [value])
            if assertion:
                df_duplicates.show(truncate=False, vertical=True)
                raise ValueError(
                    f"Column {name} '{value}' contains duplicates, no translation possible."
                )

        # Define selection and calculate the factor for each fact if needed.
        # Factor columns are multiplied between them to have one single "__FACTOR__" column.
        if factor_columns:
            factor_calculation_expression = reduce(
                lambda acc, x: acc
                * F.when(F.col(x).isNull(), 1.0).otherwise(F.col(x).cast(DoubleType())),
                factor_columns,
                1,
            )
            rows = (
                self.fact.df.withColumn("__FACTOR__", factor_calculation_expression)
                .select(source, target, "__FACTOR__")
                .collect()
            )
            facts_selection = [(F.col(r[source]) * r["__FACTOR__"]).alias(r[target]) for r in rows]
        else:
            rows = self.fact.df.select(source, target).collect()
            facts_selection = [F.col(r[source]).alias(r[target]) for r in rows]

        # Apply the selection
        self.data.df = self.data.df.select(
            ["MARKET_TAG", "PRODUCT_TAG", "PERIOD_TAG"] + facts_selection
        )

        self.fact.df = self.fact.df.withColumn("TAG", F.col(target))

    def remove_problematic_characters_on_read(self):
        """Updates fact tags both in data and fact files to avoid any character different from `[A-Z0-9]`.

        Frequent special characters are replaced by a word equivalent: "€"=EURO, "$"="DOLLAR", "%"="PERCENT", "£"="POUND".

        Raises:
            Exception: If duplicated fact tags appear in data or fact dataframes after formatting.
            Exception: If fact tags are different between data and fact dataframes after formatting.

        """
        forbidden_substring_dictionary = {
            "$": "DOLLAR",
            "€": "EURO",
            "%": "PERCENT",
            "£": "POUND",
        }

        # Update data columns
        regex_expression = re.compile(
            "|".join(map(re.escape, forbidden_substring_dictionary.keys()))
        )

        self.data.df = self.data.df.select(
            [
                F.col(f"`{c}`").alias(
                    re.sub(
                        r"[^A-Z0-9]",
                        "",
                        regex_expression.sub(
                            lambda match: forbidden_substring_dictionary[match.group(0)],
                            c.upper(),
                        ),
                    )
                )
                if c not in ["MARKET_TAG", "PRODUCT_TAG", "PERIOD_TAG"]
                else F.col(c)
                for c in self.data.df.columns
            ]
        )

        # Update fact tags
        when_expression = None
        for i, (s, r) in enumerate(forbidden_substring_dictionary.items()):
            condition = F.col("TAG").contains(s)
            replacement = F.regexp_replace(F.col("TAG"), re.escape(s), r)
            if i == 0:
                when_expression = F.when(condition, replacement)
            else:
                when_expression = when_expression.when(condition, replacement)
        when_expression = when_expression.otherwise(F.col("TAG"))

        self.fact.df = self.fact.df.withColumn("TAG", when_expression).withColumn(
            "TAG", F.regexp_replace(F.upper(F.col("TAG")), r"[^A-Z0-9]", "")
        )

        # Check no duplicated tag is in the "TAG" column of the fact dataframe
        if self.fact.df.count() > self.fact.df.dropDuplicates(["TAG"]).count():
            raise Exception(
                "Fact dataframe has duplicated tags following removal of problematic characters on read."
            )

        # Check no duplicated tag is in the columns of the data dataframe
        if len(set(self.data.df.columns)) != len(self.data.df.columns):
            raise Exception(
                "Data dataframe has duplicated fact tags following removal of problematic characters on read."
            )

        # Check all fact tags are in the data
        tags_in_fact = sorted([row["TAG"] for row in self.fact.df.select("TAG").collect()])
        tags_in_data = sorted(self.data.df.columns[3:])

        if tags_in_fact != tags_in_data:
            raise Exception(
                f"Facts incoherence following removal of problematic characters on read, data tags are: {tags_in_data}, fact tags are: {tags_in_fact}."
            )

    def audit_fact_tags_are_coherent_between_data_and_fact(self):
        """Audits that fact tags are identical between data and fact dataframes.

        Raises:
            Exception: If tags are different between data and fact dataframes.
        """
        tags_in_fact = sorted([row["TAG"] for row in self.fact.df.select("TAG").collect()])
        tags_in_data = sorted(
            [
                c
                for c in self.data.df.columns
                if c not in ["MARKET_TAG", "PRODUCT_TAG", "PERIOD_TAG"]
            ]
        )

        if tags_in_fact != tags_in_data:
            raise Exception(
                f"Facts incoherence detected between data and fact, data tags are: {tags_in_data}, fact tags are: {tags_in_fact}."
            )

    def write(
        self,
        market: Union[str, bool] = "MKT",
        product: Union[str, bool] = "PROD",
        period: Union[str, bool] = "PER",
        fact: Union[str, bool] = "FCT",
        data: Union[str, bool] = "DATA",
    ) -> SchemaWriter:
        """Prepares a writer instance in order to write a schema to Redslim standard format.

        Args:
            market: Specify how to identify the market dimension.
            product: Specify how to identify the product dimension.
            period: Specify how to identify the period dimension.
            fact: Specify how to identify the fact dimension.
            data: Specify how to identify the data dimension.
        """
        return SchemaWriter(
            sch=self,
            market=market,
            product=product,
            period=period,
            fact=fact,
            data=data,
        )

    def select(
        self,
        facts: Optional[List[str]] = None,
        aliases: Optional[List[str]] = None,
        aliases_column: Optional[str] = "RDSLM_FACT_ALIGN",
    ):
        """Selects fact columns in `self.data.df` and fact lines in `self.fact.df` depending on facts or aliases list.

        If aliases are passed, the `"TAG"` column of the fact file is translated from the provided aliases column.
        When using aliases, the order of facts in the data dataframe is not preserved.

        Args:
            facts: Fact tags to select on, from column `"TAG"`.
            aliases: Fact aliases to select on.
            aliases_column: Column to search the fact aliases in.

        Raises:
            ValueError: if `facts` and `aliases` are not specified.
        """
        if facts is not None or aliases is not None:
            if facts is not None:
                self.data.df = self.data.df.select(
                    ["MARKET_TAG", "PRODUCT_TAG", "PERIOD_TAG"] + facts
                )
                self.fact.df = self.fact.df.where(F.col("TAG").isin(facts))
            else:
                self.fact.df = self.fact.df.where(F.col(aliases_column).isin(aliases))
                facts = self.fact.get_column_values("TAG")
                self.data.df = self.data.df.select(
                    ["MARKET_TAG", "PRODUCT_TAG", "PERIOD_TAG"] + facts
                )
                self.translate_facts(source="TAG", target=aliases_column)
        else:
            raise ValueError("Select in schema needs 'facts' or 'aliases' to be specified.")
        return self

    def where(self, name: str, condition: Column):
        """Selects lines in `self.data.df` and dimension dataframe based on pyspark filtering condition.

        Args:
            name: name of the dimension to filter, can be `"market"`, `"product"`, and `"period"`.
            condition: pyspark filtering situation.

        Raises:
            ValueError: if `name` is not one of the allowed values.
            ValueError: if the filtering empties the dimension `name`.
        """

        df = None

        # Meta data filtering
        if name == "market":
            self.market.df = self.market.df.where(condition)
            df = self.market.df.select("TAG").withColumnRenamed("TAG", "__TAG__")
        elif name == "product":
            self.product.df = self.product.df.where(condition)
            df = self.product.df.select("TAG").withColumnRenamed("TAG", "__TAG__")
        elif name == "period":
            self.period.df = self.period.df.where(condition)
            df = self.period.df.select("TAG").withColumnRenamed("TAG", "__TAG__")
        else:
            raise ValueError(f"Dimension '{name}' cannot be used in 'where'.")
        if len(df.head(1)) == 0:
            raise ValueError(f"Dimension '{name}' is empty following filtering.")

        # Data filtering
        self.data.df = self.data.df.join(
            df, self.data.df[f"{name.upper()}_TAG"] == df["__TAG__"], how="inner"
        ).drop("__TAG__")

        return self

    def query(
        self,
        facts: Optional[List[str]] = None,
        aliases: Optional[List[str]] = None,
        aliases_column: Optional[str] = "FACT_ALIGN",
        where: List[dict[str, str]] = [],
        safe: bool = False,
    ):
        """Queries data points on columns and meta data conditions.

        Args:
            facts: List of fact tags to select.
            aliases: Fact aliases to select on.
            aliases_column: Column to search the fact aliases in.
            where: List of meta data filtering conditions.
            safe: Check if a dimension got entirely filtered out.

        Raises:
            ValueError: If a dimension got entirely filtered out.
        """

        self.select(facts=facts, aliases=aliases, aliases_column=aliases_column)

        wheres = group_dictionaries(where, "name")
        for name, condition_dict in wheres.items():
            condition_list = [create_condition(**d) for d in condition_dict]
            condition = reduce(lambda acc, x: acc & x, condition_list)

            self.where(name, condition)

            if safe:
                if self.__getattribute__(name).df.count() == 0:
                    raise ValueError(f"Dimension '{name}' got filtered out completely.")

        if safe:
            if self.data.df.count() == 0:
                raise ValueError("Dimension 'data' got filtered out completely.")

        return self

    def audit_tags_are_coherent(self):
        """Audits that meta data tags are identical between the data dataframe and meta data dataframes.

        Raises:
            ValueError: Tags in `"MARKET_TAG"`, `"PRODUCT_TAG"`, `"PERIOD_TAG"` and fact header do not belong to the individual meta data dataframes.
        """
        # fact
        fact_tags = self.fact.df.select("TAG").rdd.flatMap(lambda x: x).collect()
        data_columns = self.data.df.columns[3:]

        if sorted(fact_tags) != sorted(data_columns):

            print(
                "Data columns are missing following facts: ",
                set(fact_tags) - set(data_columns),
            )

            raise ValueError("Fact tags and data columns are different.")

        # market, product, period
        for dimension in ["market", "product", "period"]:
            df_data_dimension = self.data.df.select(f"{dimension.upper()}_TAG").distinct()
            df_dimension = self.__getattribute__(dimension).df

            df_join = df_data_dimension.join(
                df_dimension.select("TAG"),
                df_data_dimension[f"{dimension.upper()}_TAG"] == df_dimension["TAG"],
                how="leftanti",
            )

            if not df_join.rdd.isEmpty():
                df_join.show(truncate=False, vertical=True)
                raise ValueError(
                    f"Tags in '{dimension.upper()}_TAG' column in data do not belong to 'TAG' column in '{dimension}'."
                )

    def audit_data_totals_are_equal_between_levels(
        self,
        facts: List[str],
        hierarchy_name: str,
        hierarchy_level_numbers: Optional[List[str]] = None,
        dimension: str = "product",
        threshold: float = 0.0005,
    ):
        """Audits that fact totals are equal across a dimension levels for each other two dimensions.

        Args:
            facts: Facts to calculate as part of the audit.
            hierarchy_name: Name of the hierarchy to run the audit on.
            hierarchy_level_numbers: Levels to run the audit on.
            dimension: Name of the dimension to run the audit on, can be "product" or "market".
            threshold: Limit for the score above which an error is raised for each aggregation.

        Raises:
            Exception: If aggregations exceed the acceptability limit.
        """
        # Create df_meta_reduce

        # Filter on the hierarchy_name
        df_meta_reduce = self.__getattribute__(dimension).df.where(
            F.col("HIER_NAME") == hierarchy_name
        )

        # If needed filter on the hierarchy_level_numbers
        if hierarchy_level_numbers is not None:
            df_meta_reduce = df_meta_reduce.where(
                F.col("HIER_LEVEL_NUM").isin(hierarchy_level_numbers)
            )

        # Cast "HIER_LEVEL_NUM" to avoid having "1", "10", "2" as order
        df_meta_reduce = df_meta_reduce.withColumn(
            "HIER_LEVEL_NUM",
            F.col("HIER_LEVEL_NUM").cast(IntegerType()),
        )

        # Define variables
        data_columns = [
            x
            for x in ["MARKET_TAG", "PRODUCT_TAG", "PERIOD_TAG"]
            if x != f"{dimension.upper()}_TAG"
        ]
        groupby_columns = data_columns + ["HIER_LEVEL_NUM"]
        window = Window.partitionBy(data_columns).orderBy("HIER_LEVEL_NUM")

        # Base dataframe creation
        df = (
            self.data.df.join(
                df_meta_reduce[["TAG", "HIER_LEVEL_NUM"]],
                self.data.df[f"{dimension.upper()}_TAG"] == df_meta_reduce["TAG"],
                how="inner",
            )
            .groupby(groupby_columns)
            .agg({f: "sum" for f in facts})
            .select(groupby_columns + [F.col(f"sum({c})").alias(c) for c in facts])
        )

        # Iteration over facts with exception raised if gaps are detected
        for f in facts:
            f_parent = f"{f} PARENT"
            f_difference = f"{f} DIFFERENCE"
            f_score = f"{f} SCORE"
            df_f = (
                df.fillna(0, subset=[f])
                .withColumn(f_parent, F.lag(f, 1).over(window))
                .withColumn(
                    f_difference,
                    F.when(F.isnull(F.col(f) - F.col(f_parent)), 0).otherwise(
                        F.col(f) - F.col(f_parent)
                    ),
                )
                .withColumn(
                    f_score,
                    F.when(F.isnull(F.col(f_parent)), 0)
                    .when(F.col(f_parent) == 0, F.col(f_difference) / 0.0000000001)
                    .otherwise(F.col(f_difference) / F.col(f_parent)),
                )
                .where(F.abs(F.col(f_score)) > threshold)
            )

            if df_f.count() > 0:
                df_f.select(groupby_columns + [f, f_parent, f_difference, f_score]).show(
                    truncate=False, vertical=True
                )
                raise Exception(
                    f"Data gaps have been detected between '{dimension}' levels for fact '{f}'."
                )

    def rename_fact_tags(self, column_names: dict[str, str]):
        """Rename tags in the fact dataframe based on a dictionary.

        Args:
            column_names: Dictionary with the fact tags to modify.
        """

        def get_value(value):
            return column_names[value]

        rename_tag = F.udf(get_value, StringType())
        self.fact.df = self.fact.df.withColumn("TAG", rename_tag(F.col("TAG")))

        self.data.df = self.data.df.select(
            *[
                F.col(column).alias(column_names[column])
                if column in column_names.keys()
                else column
                for column in self.data.df.columns
            ]
        )

    def specify_tags(self, name: str, str_add: str):
        """Changes the values of the tags adding a string at the beginning.

        Args:
            name: Name of the dimension to translate tag from, can be `"market"`, `"product"` or `"period"`.
            str_add: String to add at the beginning of the tags.
        """
        dimension = self.__getattribute__(name)

        dimension.df = dimension.df.withColumn("TAG", F.concat(F.lit(str_add), F.col("TAG")))
        self.data.df = self.data.df.withColumn(
            f"{name.upper()}_TAG",
            F.concat(F.lit(str_add), F.col(f"{name.upper()}_TAG")),
        )

    def promote_level(
        self,
        column: str,
        value: str,
        hierarchy_name: str,
        dimension: Optional[str] = "product",
        update_hierarchy_chain: Optional[bool] = False,
        update_parent_tag: Optional[bool] = False,
    ):
        """Creates a root record in a hierarchy of a meta dimension.

        The function adds the required rows to the data file. For these rows, non-additive facts
        are set to `null`.

        Args:
            dimension: Name of the meta data dimension to promote a level for.
            column: Name of the column representing the promoted level.
            value: Value representing the promoted level.
            hierarchy_name: Name of the hierarchy to promote a level for.
            update_hierarchy_chain: Specify if the hierarchy chain column needs to be updated for the hierarchy.
            update_parent_tag: Specify if the parent tag column needs to be updated for the hierarchy.

        Raises:
            ValueError: If 'RDSLM_FACT_TYPE' column in fact dimension does not contain `"ADDITIVE"`.
            ValueError: If 'TAG' column contains duplicates after level promotion.
        """
        meta = self.__getattribute__(dimension)

        # Update meta dataframe

        # Create meta data level dataframe
        hierarchy_number = (
            meta.df.where(F.col("HIER_NAME") == hierarchy_name)
            .select(["HIER_NUM"])
            .distinct()
            .collect()[0]["HIER_NUM"]
        )

        base_columns_dictionary = {
            "TAG": None,
            "SHORT": value,
            "LONG": value,
            "DISPLAY_ORDER": None,
            "PARENT_TAG": None,
            "HIER_NUM": hierarchy_number,
            "HIER_NAME": hierarchy_name,
            "HIER_LEVEL_NUM": "1",
            "HIER_LEVEL_NAME": column,
            column: value,
        }

        other_columns_dictionary = {
            k: None for k in meta.df.columns if k not in base_columns_dictionary.keys()
        }

        base_columns_dictionary.update(other_columns_dictionary)

        if update_hierarchy_chain:
            base_columns_dictionary[hierarchy_name] = column

        schema = StructType(
            [StructField(c, StringType(), True) for c in base_columns_dictionary.keys()]
        )
        df_meta_data_level = spark.createDataFrame([Row(**base_columns_dictionary)], schema=schema)

        tag_type = MetaFactory.instanciate_tag_type(meta.__class__)
        if tag_type == "concatenate":
            df_meta_data_level = df_meta_data_level.withColumn(
                "TAG",
                F.upper(F.regexp_replace(column, r"[^A-Za-z0-9]", "")),
            )

        elif tag_type == "md5":
            df_meta_data_level = df_meta_data_level.withColumn(
                "TAG", F.upper(F.md5(F.concat(column)))
            )

        else:
            raise AttributeError(f"Tag type '{tag_type}' is not implemented.")

        level_tag = [row["TAG"] for row in df_meta_data_level.collect()][0]

        # Add level column to meta data dataframe
        meta.df = meta.df.withColumn(
            column,
            F.when(F.col("HIER_NAME") == hierarchy_name, F.lit(value)).otherwise(None),
        )

        # Update "HIER_LEVEL_NUM" in meta data dataframe
        meta.df = meta.df.withColumn(
            "HIER_LEVEL_NUM",
            F.when(
                F.col("HIER_NAME") == hierarchy_name,
                F.col("HIER_LEVEL_NUM").cast(IntegerType()) + 1,
            ).otherwise(F.col("HIER_LEVEL_NUM")),
        )
        meta.df = meta.df.withColumn("HIER_LEVEL_NUM", F.col("HIER_LEVEL_NUM").cast(StringType()))

        # Update hierarchy chain column values if needed
        if update_hierarchy_chain:
            meta.df = meta.df.withColumn(
                hierarchy_name,
                F.when(
                    (F.col("HIER_NAME") == hierarchy_name),
                    F.concat(F.lit(column + "!"), F.col(hierarchy_name)),
                ).otherwise(F.col(hierarchy_name)),
            )

        # Update 'PARENT_TAG' column values if needed
        if update_parent_tag:
            meta.df = meta.df.withColumn(
                "PARENT_TAG",
                F.when(
                    (F.col("HIER_NAME") == hierarchy_name) & (F.col("PARENT_TAG").isNull()),
                    level_tag,
                ).otherwise(F.col("PARENT_TAG")),
            )

        # Append meta data level dataframe to meta data dataframe
        meta.df = df_meta_data_level.unionByName(meta.df).select(meta.df.columns)

        assertion, df_duplicates = columns_have_duplicates(meta.df, ["TAG"])
        if assertion:
            df_duplicates.show()
            raise ValueError(
                f"Column 'TAG' from '{dimension}' has duplicated values after promoted level appending."
            )

        # Update data dataframe

        # Define facts aggregation and raise exception if 'RDSLM_FACT_TYPE' does not contain "ADDITIVE"

        fact_types = self.fact.df.select(["TAG", "RDSLM_FACT_TYPE"]).collect()
        additive_facts = [f["TAG"] for f in fact_types if f["RDSLM_FACT_TYPE"] == "ADDITIVE"]
        nonadditive_facts = [f["TAG"] for f in fact_types if f["RDSLM_FACT_TYPE"] != "ADDITIVE"]
        facts_aggregation = {f: "sum" for f in additive_facts}

        if len(additive_facts) == 0:
            raise ValueError("Column 'RDSLM_FACT_TYPE' in the fact dimension is empty.")

        # Create data level dataframe by summing additive facts and setting null the others.
        df_meta_children = meta.df.where(
            (F.col("HIER_NAME") == hierarchy_name) & (F.col("HIER_LEVEL_NUM") == "2")
        )

        dimension_data_tag = f"{dimension.upper()}_TAG"
        other_data_tags = [
            x for x in ["MARKET_TAG", "PRODUCT_TAG", "PERIOD_TAG"] if x != dimension_data_tag
        ]

        df_data_level = (
            self.data.df.join(
                df_meta_children[["TAG"]],
                self.data.df[dimension_data_tag] == df_meta_children["TAG"],
                how="inner",
            )
            .groupby(other_data_tags)
            .agg(facts_aggregation)
            .withColumn(dimension_data_tag, F.lit(level_tag))
        )

        columns_translator = {
            column: re.sub(r"^(first|min|max|sum|avg)\((?P<column>(.*))\)$", r"\g<column>", column)
            for column in df_data_level.columns[2:]
        }

        df_data_level = df_data_level.select(
            [
                F.col(column).alias(columns_translator[column])
                if column in columns_translator.keys()
                else column
                for column in df_data_level.columns
            ]
        )

        # Add non additive facts to data dataframe
        for fact in nonadditive_facts:
            df_data_level = df_data_level.withColumn(fact, F.lit(None))

        df_data_level = df_data_level.select(self.data.df.columns)

        # Update the data in schema by appending data level dataframe to data dataframe
        self.data.df = df_data_level.unionByName(self.data.df)

        # Update the meta data in schema
        self.__setattr__(dimension, meta)

    def update_total_level_values(
        self,
        dimension: str,
        total_level_tag: str,
        dimension_where_expression: str,
        fact_aggregations: dict = None,
    ):
        """Function to update the TOTAL_PRODUCT or TOTAL_MARKET level values for a hierarchy following a filter.

        Args:
            dimension: The dimension to update, either of "product" or "market".
            total_level_tag: The TAG to update the values for.
                e.g. "`P000000000000626053100000000009819306860`"
            dimension_where_expression: A string expression to be used to filter the meta dimension that will be aggregated.
                e.g. "`HIER_LEVEL_NUM` = 2 AND `HIER_NUM` = 1"
            fact_aggregations: A dictionary of the aggregate functions to use for each Fact.
                e.g. "`{"VAL":"sum", "VOL": "sum", "WTD":"max"}`"

        Raises:
            ValueError: If dimension is not one of 'market' or 'product'.
        """
        if dimension not in ["market", "product"]:
            raise ValueError(
                f"The dimension value '{dimension}' is not valid. Only 'product' and 'market' are supported."
            )
        # get the default fact_aggregations if these are not provided
        if not fact_aggregations:
            fact_aggregations = {
                fact["TAG"]: "sum" if fact["RDSLM_FACT_TYPE"] == "ADDITIVE" else "avg"
                for fact in self.fact.df.select("TAG", "RDSLM_FACT_TYPE").collect()
            }
        aggregates = [
            F.__getattribute__(function)(fact).alias(fact)
            for fact, function in fact_aggregations.items()
        ]
        # remove the tag that we are about to update from the data
        self.data.df = self.data.df.where(F.col(f"{dimension.upper()}_TAG") != total_level_tag)
        # create a new dataframe that will be the updated values
        new_rows = self.data.df.join(
            self.__getattribute__(dimension).df.where(dimension_where_expression),
            self.data.df[f"{dimension.upper()}_TAG"] == self.__getattribute__(dimension).df["TAG"],
            "inner",
        )
        # dynamically gather the groupby and aggregation statements
        groupBy = {
            "product": ["MARKET_TAG", "PERIOD_TAG"],
            "market": ["PRODUCT_TAG", "PERIOD_TAG"],
        }[dimension]
        new_rows = new_rows.groupBy(*groupBy).agg(*aggregates)
        new_rows = new_rows.withColumn(f"{dimension.upper()}_TAG", F.lit(total_level_tag)).select(
            self.data.df.columns
        )
        # add the new rows to the data df
        self.data.df = self.data.df.union(new_rows)

    def get_all_table_creation_strings(self, database_name: str, table_names={}):
        """Creates a dictionary containing all of the SQL TABLE creation strings for a database.

        Args:
            table_names: a dictionary with the names of the SQL Table names for each dimension of the database.
                e.g. {"market":"LORAKUUS_MKT", "product":"LORAKUUS_PROD", ...}

        Returns:
            dict_of_strings: A dictionary of strings which will enable the table creation process.
        """
        if "SQL_TYPES" in self.fact.df.columns:
            sql_types = (
                self.fact.df.select("TAG", "SQL_TYPES")
                .where(F.col("SQL_TYPES").isNotNull())
                .collect()
            )
            sql_types = {record["TAG"]: record["SQL_TYPES"] for record in sql_types}
        else:
            sql_types = {}
        if not table_names:
            for table in ["market", "product", "period", "fact", "data"]:
                affix = {
                    "market": "_MKT",
                    "product": "_PROD",
                    "period": "_PER",
                    "data": "_DATA",
                    "fact": "_FCT",
                }[table]
                table_names[table] = {
                    "new": f"NEW_{database_name}{affix}",
                    "current": f"{database_name}{affix}",
                    "old": f"OLD_{database_name}{affix}",
                }

        dict_of_strings = {
            "market": self.market.generate_create_table_string(table_names=table_names["market"]),
            "product": self.product.generate_create_table_string(
                table_names=table_names["product"]
            ),
            "period": self.period.generate_create_table_string(table_names=table_names["period"]),
            "fact": self.fact.generate_create_table_string(table_names=table_names["fact"]),
            "data": self.data.generate_create_table_string(
                table_names=table_names["data"], sql_types=sql_types
            ),
        }
        return dict_of_strings

    def get_extended_name(self, database: str, category: Optional[str] = "DEFAULT") -> str:
        """Returns an extended name for the schema.

        The extended name is built as `f"RDSM_{database}_{category}_{last_period}"`, where
        `last_period` is found in the period dimension. Strings `database` and `category`
        are formated by sustitution of any character matching regex `"[^A-Za-z0-9]"`.
        They are also set to uppercase.

        It is a requirement for column `"PER_ALIGN"` of the period dimension to have at least
        one value. It is recommended to run `align_periods` on the period dimension before. The last
        period is defined as the greater non null string in column `"PER_ALIGN"`.

        Args:
            database: Name of the database.
            category: Name of the category.

        Returns:
            Extended name for the schema.

        Raises:
            ValueError: If the period dimension does not contain any value in column `"PER_ALIGN"`.
            ValueError: If the period dimension contains duplicates in column `"PER_ALIGN"`.
            ValueError: If after formatting the database or category strings are empty.

        """

        df_period = self.period.df.where(F.col("PER_ALIGN").isNotNull())
        periods = [r["PER_ALIGN"] for r in df_period.collect()]
        periods.sort()

        # Raise an exception if periods is empty.
        if len(periods) == 0:
            raise ValueError(
                "Column 'PER_ALIGN' of period dimension does not contain any non null value."
            )

        # Raise an exception if periods contains duplicates
        if len(periods) != len(set(periods)):
            raise ValueError("Column 'PER_ALIGN' of period dimension contains duplicates.")

        last_period = periods[-1]

        # Format the database and category values.
        database = re.sub(r"[^A-Za-z0-9]", "", database).upper()
        category = re.sub(r"[^A-Za-z0-9]", "", category).upper()

        if database == "" or category == "":
            raise ValueError(
                f"After formatting 'database' ('{database}') or 'category' ('{category}') are empty."
            )

        return f"RDSM_{database}_{category}_{last_period}"

    def apply_special_cases_on_read(self):
        """Harmonizes schema dataframes with known special cases for each dimension."""
        data = Data(df=getattr(self.data, "df", None))

        if data.df is not None:
            if "MKT_TAG" in data.df.columns:
                data.df = data.df.withColumnRenamed("MKT_TAG", "MARKET_TAG")
            if "PROD_TAG" in data.df.columns:
                data.df = data.df.withColumnRenamed("PROD_TAG", "PRODUCT_TAG")
            if "PER_TAG" in data.df.columns:
                data.df = data.df.withColumnRenamed("PER_TAG", "PERIOD_TAG")
        else:
            pass

        return Schema(self.market, self.product, self.period, self.fact, data)

    def translate_periods(self, period_mapping_df: DataFrame):
        """Updates the data and period dataframes based on the period mapping dataframe.

        Args:
            period_mapping_df: The dataframe corresponding to a period mapping
            The columns of this dataframe are `["_TAG_", "_PERIOD_TAG_", "_FACTOR_"]`

        Raises:
            ValueError: If some TAG(s) in the period dimension are not mapped in the period_mapping_dataframe

        """

        tag_set = {r["TAG"] for r in self.period.df.collect()}
        _tag_set = {r["_TAG_"] for r in period_mapping_df.collect()}
        if tag_set.issubset(_tag_set) is False:
            raise ValueError(
                f"Some TAG(s) in the period dimension are not mapped in the period_mapping_dataframe.\n{print(tag_set-_tag_set)}"
            )

        # Updatting the data dataframe
        self.data.df = self.data.df.join(
            period_mapping_df,
            self.data.df["PERIOD_TAG"] == period_mapping_df["_TAG_"],
            "left",
        )
        self.data.df = self.data.df.drop("PERIOD_TAG", "_TAG_")

        fact_rdd = self.fact.df.select("TAG", "RDSLM_FACT_TYPE").rdd

        fact_keypair_rdd = fact_rdd.map(lambda x: (x[0], x[1]))
        fact_dict = fact_keypair_rdd.collectAsMap()

        for key, value in fact_dict.items():
            if value == "ADDITIVE":
                self.data.df = self.data.df.withColumn(
                    key, self.data.df[key] * self.data.df["_FACTOR_"]
                )

        self.data.df = self.data.df.groupBy("MARKET_TAG", "PRODUCT_TAG", "_PERIOD_TAG_").agg(
            *[
                F.sum(col).alias(col) if t == "ADDITIVE" else F.avg(col).alias(col)
                for col, t in fact_dict.items()
            ]
        )

        self.data.df = self.data.df.withColumnRenamed("_PERIOD_TAG_", "PERIOD_TAG")

        # Updatting the period dataframe
        period_dimension_df = self.period.df.join(
            period_mapping_df,
            self.period.df["TAG"] == period_mapping_df["_TAG_"],
            "inner",
        )

        period_dimension_df = period_dimension_df.select(
            F.col("_PERIOD_TAG_").alias("TAG"), *self.period.df.columns[1:]
        )

        period_dimension_df = period_dimension_df.dropDuplicates(subset=["TAG"])

        period_dimension_df = period_dimension_df.withColumn("SHORT", period_dimension_df["TAG"])
        period_dimension_df = period_dimension_df.withColumn("LONG", period_dimension_df["TAG"])

        self.period.df = period_dimension_df.orderBy(F.col("TAG").asc())

    def create_custom_market(
        self,
        markets_to_aggregate: List[str],
        market_characteristics: Dict,
        fact_aggregations: Optional[dict] = {},
    ):
        """Function to create a new Market based on existing markets. The new Market must be at an existing level.

        Args:
            markets_to_aggregate: a list of the TAGs of Markets to aggregate to create this new Market
                e.g. `["M000000000001000157600000000000010006109", "M000000000000104251900000000000001088573"]`
            market_characteristics: a dictionary of the values the new market needs to have for each column. Any unspecified columns will be populated with null.
                e.g. `{"TAG":"DM", "SHORT": "DM ex dm", "LONG": "DM ex dm", "Level": "Total!MBD", "Total":"Total"}`
            fact_aggregations: a dictionary specifying which aggregation function to use for each and all facts.
                values should be one of the spark aggregate functions, see https://bit.ly/3jSO8Am
                e.g. `{"VAL":"sum", "UNI": "sum", "WTD": "max", "VALSHARE": "avg"}`

        Raises:
            ValueError: If a value for TAG is not specified in the market_characteristics dictionary
        """
        # check each of the markets_to_aggregate is indeed present in the market dimension
        for market in markets_to_aggregate:
            self.market.audit_value_in_column("TAG", market)

        # check that TAG value is specified in the market_characteristics
        if "TAG" not in market_characteristics.keys():
            raise ValueError(
                "A value for 'TAG' has not been specified for the new market. Please specify the TAG that this new market needs to have."
            )

        # Format the TAG to remove any strange characters and set it to upper case
        market_characteristics["TAG"] = re.sub(
            "[^A-Z0-9]", "", market_characteristics["TAG"].upper()
        )

        # add the new market to the market dimension
        # get the data to add in the new row as a list of a single tuple
        values = [
            tuple(
                market_characteristics.get(characteristic, None)
                for characteristic in self.market.df.columns
            )
        ]
        market_schema = StructType(
            [StructField(column_name, StringType(), True) for column_name in self.market.df.columns]
        )
        # create a dataframe with a single row to append to the market dimension
        new_row = spark.createDataFrame(values, market_schema)
        self.market.df = self.market.df.union(new_row)
        # aggregate the data dimension and edit the market tag accordingly
        if not fact_aggregations:
            fact_aggregations = {
                fact["TAG"]: "sum" if fact["RDSLM_FACT_TYPE"] == "ADDITIVE" else "avg"
                for fact in self.fact.df.select("TAG", "RDSLM_FACT_TYPE").collect()
            }
        aggregates = [
            F.__getattribute__(function)(fact).alias(fact)
            for fact, function in fact_aggregations.items()
        ]
        new_rows = (
            self.data.df.where(F.col("MARKET_TAG").isin(*markets_to_aggregate))
            .groupBy("PERIOD_TAG", "PRODUCT_TAG")
            .agg(*aggregates)
        )
        new_rows = new_rows.withColumn("MARKET_TAG", F.lit(market_characteristics["TAG"])).select(
            self.data.df.columns
        )

        # add the new rows the existing fact dimension
        self.data.df = self.data.df.union(new_rows)
        # run audits to check the relationship between fata and meta dimensions is consistent
        self.data.audit_tag_combinations_are_unique()
        self.audit_tags_are_coherent()

    def resample_dimension(self, name: str, columns: List[str]):
        """Updates product or market tags based on identical values contained in `columns` argument.

        Args:
            name: Name of the dimension to the resample on, can be `"product"` or `"market"`.
            columns: List of column names to base the new tag generation on.

        Raises:
                ValueError: If `"name"` is different from product or market.
        """
        fact_rdd = self.fact.df.select("TAG", "RDSLM_FACT_TYPE").rdd
        fact_keypair_rdd = fact_rdd.map(lambda x: (x[0], x[1]))
        fact_dict = fact_keypair_rdd.collectAsMap()

        if name == "product":
            df = self.product.df
            data_tag = "PRODUCT_TAG"
        elif name == "market":
            df = self.market.df
            data_tag = "MARKET_TAG"
        else:
            raise ValueError(
                f"Name parameter must be product or market. This is your name paramater value:{name}."
            )
        df = df.withColumn("TAG_RESAMPLE", F.upper(F.md5(F.concat(*columns))))
        # Join with data ...
        self.data.df = self.data.df.join(
            df.select("TAG", "TAG_RESAMPLE"),
            self.data.df[data_tag] == df["TAG"],
            how="left",
        )
        self.data.df = self.data.df.withColumn(data_tag, F.col("TAG_RESAMPLE")).drop(
            *["TAG", "TAG_RESAMPLE"]
        )
        self.data.df = self.data.df.groupby("MARKET_TAG", "PRODUCT_TAG", "PERIOD_TAG").agg(
            *[
                F.sum(col).alias(col) if t == "ADDITIVE" else F.avg(col).alias(col)
                for col, t in fact_dict.items()
            ]
        )
        df = df.drop_duplicates(subset=columns)
        df = df.withColumn("TAG", F.col("TAG_RESAMPLE")).drop(*["TAG_RESAMPLE"])

        if name == "product":
            self.product.df = df
        if name == "market":
            self.market.df = df

    def create_hierarchy_from_bottom(self, name: str, hierarchy_name: str, hierarchy_columns):
        """Creates hierarchy levels up to an unique root given a layer of records belonging to a single level.

        It is recommended to run some tag resampling on the dimension dataframe before applying the function.

        Args:
            name: Name of the dimension to create the hierarchy levels for, can be `"product"` or `"market"`.
            hierarchy_name: The name of the hierarchy.
            hierarchy_columns: Ordered list of column names that constitute the hierarchy.

        Raises:
            ValueError: If `"name"` is different from product or market.
        """

        if name == "product":
            df = self.product.df
            data_tag = "PRODUCT_TAG"
        elif name == "market":
            df = self.market.df
            data_tag = "MARKET_TAG"
        else:
            raise ValueError(
                f"Name parameter must be 'product' or 'market'. This is your name paramater value: '{name}'."
            )

        # If the first column of the hierarchy contains more than one distinct value, a column
        # containing a single value must be created.
        if not df.select(hierarchy_columns[0]).distinct().count() == 1:
            df = df.withColumn("TOTAL", F.lit("TOTAL"))
            hierarchy_columns = ["TOTAL"] + hierarchy_columns

        # Create the column corresponding to the hierarchy level name for the lowest level.
        df = df.withColumn("ITEM", F.lit("ITEM"))

        # Populate the standard columns for the lowest level
        df = df.withColumn("HIER_LEVEL_NUM", F.lit(len(hierarchy_columns) + 1))
        df = df.withColumn("HIER_LEVEL_NAME", F.lit("ITEM"))
        df = df.withColumn(
            "PARENT_TAG",
            F.upper(F.md5(F.concat(*[F.col(c) for c in hierarchy_columns]))),
        )

        # Create the column storing the "TAG" of the lowest child. For the lowest level values
        # are identical to the "TAG" column, but as levels are created, the "TAG" column evolves
        # while the "CHILD_TAG" does not.
        df = df.withColumn("CHILD_TAG", F.col("TAG"))

        # Iterate over the hierarchy levels and store each layer in a list.
        df_store = [df]
        for i in reversed(range(1, len(hierarchy_columns) + 1)):
            hier_level_num = i
            hier_level_name = hierarchy_columns[i - 1]
            level_columns = hierarchy_columns[:i]

            columns_to_initialize_with_null = [
                c
                for c in df.columns
                if (c not in level_columns + ["TAG", "CHILD_TAG", "PARENT_TAG"])
            ]

            for col in columns_to_initialize_with_null:
                df = df.withColumn(col, F.lit(None))

            df = df.withColumn("HIER_LEVEL_NUM", F.lit(hier_level_num))
            df = df.withColumn("HIER_LEVEL_NAME", F.lit(hier_level_name))
            df = df.withColumn("TAG", F.col("PARENT_TAG"))

            if i == 1:
                df = df.withColumn("PARENT_TAG", F.lit(None))
            else:
                df = df.withColumn(
                    "PARENT_TAG",
                    F.upper(F.md5(F.concat(*[F.col(c) for c in hierarchy_columns[: (i - 1)]]))),
                )

            df_store.append(df)

        # Append the dataframes of each level. Each of the dataframe should have as many rows as
        # the initial lowest level.
        for i, df in enumerate(df_store):
            if i == 0:
                df_hierarchy = df
            else:
                df_hierarchy = df_hierarchy.unionByName(df)

        # Create the hierarchy name and number columns.
        df_hierarchy = df_hierarchy.withColumn("HIER_NAME", F.lit(hierarchy_name))
        df_hierarchy = df_hierarchy.withColumn("HIER_NUM", F.lit(1))

        # Create the data point for the products belonging to the newly created levels.
        self.data.df = self.data.df.join(
            df_hierarchy.select("CHILD_TAG", "TAG"),
            self.data.df[data_tag] == df_hierarchy["CHILD_TAG"],
            how="left",
        )

        # The values from the dimension tag column in data are replaced by the values of the "TAG"
        # column. The columns enabling the tag translation are then dropped. After this step, the
        # data dataframe has the same columns as the original one, but it has a lot more rows.
        self.data.df = self.data.df.withColumn(data_tag, F.col("TAG")).drop(*["CHILD_TAG", "TAG"])

        # Aggregate the data following the numerous dimension tag duplicates caused by the left join
        # coupled with duplicates in the "CHILD_TAG" column.
        fact_rdd = self.fact.df.select("TAG", "RDSLM_FACT_TYPE").rdd
        fact_keypair_rdd = fact_rdd.map(lambda x: (x[0], x[1]))
        fact_dict = fact_keypair_rdd.collectAsMap()

        self.data.df = self.data.df.groupby("MARKET_TAG", "PRODUCT_TAG", "PERIOD_TAG").agg(
            *[
                F.sum(col).alias(col) if t == "ADDITIVE" else F.avg(col).alias(col)
                for col, t in fact_dict.items()
            ]
        )

        # Drop duplicated tags in the dimension and get rid of the "CHILD_TAG" column.
        df_hierarchy = df_hierarchy.dropDuplicates(subset=["TAG"]).drop("CHILD_TAG")

        # Create the hierarchy chain column and terminate.
        if name == "product":
            self.product.df = df_hierarchy
            self.product.set_hierarchy_chain_columns()
        if name == "market":
            self.market.df = df_hierarchy
            self.market.set_hierarchy_chain_columns()

    def create_custom_fact_rows(self, tags: List[str]):
        """Updates fact dataframe rows by adding new TAG(s) based on values contained in `tags` argument.

        Args:
            tags: List of new tags we want to add.

        Raises:
            ValueError: If a tag with the same name already exists in fact dataframe.
        """

        for tag in tags:
            if self.fact.df.where(F.col("TAG") == tag).count() > 0:
                raise ValueError(
                    f"Your list of tags in parameter contains a tag that already exixts in the fact dataframe. This is your list of tags: {tags}"
                )
            else:
                new_row_df = spark.createDataFrame(
                    [(tag, "NON-ADDITIVE")], ["TAG", "RDSLM_FACT_TYPE"]
                )
                self.fact.df = self.fact.df.unionByName(new_row_df)

    def create_new_fact_rows_and_new_data_columns(self, operation: str, arguments: dict):
        """Add TAG(s) in fact dataframe and new column in data dataframe based on values contained in `operation` and `dict_of_operation` arguments.

        Args:
            operation: The operation we want to apply
            arguments: A dictionary that contains the arguments needed to call the right method in Data class

        Raises:
            ValueError: If a tag with the same name already exists in fact dataframe.
        """
        name = arguments["name"]
        if self.fact.df.where(F.col("TAG") == name).count() > 0:
            raise ValueError(
                f"A tag with the same name already exists in the fact dataframe. This is the name you just gave: {name}"
            )
        else:
            if operation == "sum_columns" and len(arguments) == 2:
                self.data.sum_columns(name, arguments["columns"])
            elif operation == "multiply_column_by_factor" and len(arguments) == 3:
                self.data.multiply_column_by_factor(name, arguments["column"], arguments["factor"])
            elif operation == "sum_or_subsctract_two_columns" and len(arguments) == 4:
                self.data.sum_or_subsctract_two_columns(
                    name, arguments["column1"], arguments["column2"], arguments["operator"]
                )
            elif operation == "apply_operation_with_expression" and len(arguments) == 2:
                self.data.apply_operation_with_expression(name, arguments["expression"])

            self.create_custom_fact_rows([name])
