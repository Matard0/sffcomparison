from __future__ import annotations

from typing import Optional

import pyspark.sql.functions as F
from pyspark.sql import Window
from pyspark.sql.dataframe import DataFrame
from rdslibrary.core.dimensions.Meta import Meta
from rdslibrary.utilities.spark import get_dbutils, get_spark
from rdslibrary.utilities.testing import columns_have_duplicates

spark = get_spark()
dbutils = get_dbutils(spark)


class Market(Meta):
    """
    Class describing the market dimension of Redslim standard format.
    """

    def __init__(self, df: Optional[DataFrame] = None):
        """Class constructor.

        Args:
            df: Dataframe reprensenting the dimension.
        """
        std = [
            "TAG",
            "SHORT",
            "LONG",
            "DISPLAY_ORDER",
            "PARENT_TAG",
            "HIER_NUM",
            "HIER_NAME",
            "HIER_LEVEL_NUM",
            "HIER_LEVEL_NAME",
        ]
        super().__init__(df=df, standard_columns=std)

    def rename_duplicate_records(self, column_with_duplicates: str = "SHORT"):
        """Updates records with duplicate values in a column to be unique by appending an increasing integer.

        Args:
            column_with_duplicates: Name of the column which is suspected to have duplicates in
                e.g. "LONG"
        """

        assertion, df_duplicates = columns_have_duplicates(
            self.df, columns=[column_with_duplicates]
        )
        if assertion:
            # Populate a new column labelling those rows which have duplicate market short descriptions
            w = Window.partitionBy(column_with_duplicates).orderBy(column_with_duplicates)
            self.df = (
                self.df.withColumn("__COUNT__", F.count(column_with_duplicates).over(w))
                .withColumn(
                    column_with_duplicates,
                    F.when(
                        F.col("__COUNT__") > 1,
                        F.concat_ws(
                            " ",
                            F.col(column_with_duplicates),
                            F.row_number().over(w),
                        ),
                    ).otherwise(F.col(column_with_duplicates)),
                )
                .drop("__COUNT__")
            )
        else:
            pass
