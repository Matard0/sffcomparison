from __future__ import annotations

import re
from functools import reduce
from itertools import chain
from typing import List, Optional

import pyspark.sql.functions as F
from pyspark.sql import Window
from pyspark.sql.dataframe import DataFrame
from pyspark.sql.types import IntegerType, StringType
from rdslibrary.core.Dimension import Dimension
from rdslibrary.utilities.spark import get_dbutils, get_spark
from rdslibrary.utilities.testing import columns_have_duplicates

spark = get_spark()
dbutils = get_dbutils(spark)


class Meta(Dimension):
    """
    Generic class describing one meta data dimension of Redslim standard format.
    """

    def __init__(
        self,
        df: Optional[DataFrame] = None,
        standard_columns: Optional[List[str]] = None,
    ):
        """
        Class constructor.

        Args:
            df: Dataframe reprensenting the meta.
            standard_columns: Standard columns in the dataframe.
        """
        super().__init__(df=df, standard_columns=standard_columns)

    def select(self, *cols):
        """Selects columns in `self.df`.

        Args:
            cols: Columns to select.
        """
        self.df = self.df.select(*cols)

    def set_descriptions(
        self,
        short: List[str] = None,
        long: List[str] = None,
        separator: Optional[str] = " ",
    ):
        """Populates `"SHORT"` and `"LONG"` columns in `self.df` from the
        concatenation of `columns` using the provided separator.

        Description are truncated after 120 characters.

        Args:
            short: Columns to concatenate to create the short description.
            long: Columns to concatenate to create the long description.
            separator: Character to use as separator of the concatenated values.
        """
        if short is not None:
            self.df = self.df.withColumn(
                "SHORT", F.substring(F.concat_ws(separator, *short), 0, 120)
            )
        if long is not None:
            self.df = self.df.withColumn("LONG", F.substring(F.concat_ws(separator, *long), 0, 120))

    def set_column(self, name: str, column: Optional[str] = None, value: Optional[str] = None):
        """Populates a column by copying an existing one or by hardcoding it.

        Args:
            name: Name of the column to populate.
            column: Column to copy from.
            value: Value to hardcode.
        Raises:
            ValueError: If `column` and `value` are equal to `None`.
        """
        if column is not None:
            self.df = self.df.withColumn(name, F.col(column))
        elif value is not None:
            self.df = self.df.withColumn(name, F.lit(value))
        else:
            raise ValueError(
                f"Column and value parameters cannot be both equal to none when setting '{name}'."
            )

    def set_hierarchies(
        self,
        name_column: Optional[str] = None,
        name_value: Optional[str] = None,
        num_column: Optional[str] = None,
        num_value: Optional[str] = None,
    ):
        """Populates the `"HIER_NAME"` and `"HIER_NUM"` columns in `self.df`.

        Args:
            name_column: Column to copy the hierarchy name from.
            name_value: Value to set as hierarchy name.
            num_column: Column to copy the hierarchy number from.
            num_value: Value to set as hierarchy number.
        """
        self.set_column("HIER_NAME", column=name_column, value=name_value)
        self.set_column("HIER_NUM", column=num_column, value=num_value)

    def set_hierarchy_levels(
        self,
        name_column: Optional[str] = None,
        name_value: Optional[str] = None,
        num_column: Optional[str] = None,
        num_value: Optional[str] = None,
        hierarchies: Optional[dict[str, str]] = None,
        lookup_column: Optional[str] = None,
        lookup_mapping: Optional[dict[List[str]]] = None,
    ):
        """Populates the `"HIER_LEVEL_NAME"` and `"HIER_LEVEL_NUM"` columns.

        There are multiple use cases:

        - If hardcoding or reusing existing values is enough, use `name_column`,
        `name_value`, `num_column`, or `num_value`.
        - If the values are in staircase along columns and `"HIER_NAME"` is populated,
        use `hierarchies`.
        - If a pseudo hierarchy name column exists, use `lookup_column` and `lookup_mapping`. Rows
            with no hierarchy name populated are set to `null`.
        Only a single hierarchy name is supported.

        Args:
            name_column: Column to copy the hierarchy level name from.
            name_value: Value to set as hierarchy level name.
            num_column: Column to copy the hierarchy level number from.
            num_value: Value to set as hierarchy level number.
            hierarchies: Hierarchy names and list of ordered hierarchy level names
                (e.g. `{"H1": ["A", "B", "C"], "H2": ["A", "C"]}`).
            lookup_column: Column name to run lookup against.
            lookup_mapping: Mapping of the values of the lookup column into level name
                and numbers (e.g. `{"LEVEL1": ["1", "CATEGORY"], "LEVEL2": ["2", "BRAND"]}`).
        """
        if hierarchies is not None:
            df_levels = spark.createDataFrame(
                [(k, v) for k, v in hierarchies.items()], ["HIER_NAME", "__LEVELS__"]
            )
            hierarchy_names = list(hierarchies.keys())

            # Create a '__INTERMEDIATE__' column as concatenation of the columns belonging to a hierarchy
            expression = None
            for i, (k, v) in enumerate(hierarchies.items()):
                condition = F.col("HIER_NAME") == k
                value = F.array(*v)
                if i == 0:
                    expression = F.when(condition, value)
                else:
                    expression = expression.when(condition, value)
            expression = expression.otherwise(F.array([]))

            self.df = self.df.withColumn("__INTERMEDIATE__", expression).withColumn(
                "__INTERMEDIATE__",
                F.expr("FILTER(__INTERMEDIATE__, x -> x is not null)"),
            )

            # Create a '__LEVELS__' column from a join with df_levels
            self.df = self.df.join(df_levels, on="HIER_NAME", how="left")

            # Create the 'HIER_LEVEL_NUM' column
            self.df = self.df.withColumn(
                "HIER_LEVEL_NUM",
                F.when(
                    F.col("HIER_NAME").isin(*hierarchy_names),
                    F.size("__INTERMEDIATE__"),
                ).otherwise(None),
            )

            # Create the 'HIER_LEVEL_NAME' column
            self.df = self.df.withColumn(
                "HIER_LEVEL_NAME",
                F.when(
                    F.col("HIER_NAME").isin(*hierarchy_names),
                    F.col("__LEVELS__").getItem(F.col("HIER_LEVEL_NUM") - 1),
                ).otherwise(None),
            ).withColumn("HIER_LEVEL_NUM", F.col("HIER_LEVEL_NUM").cast(StringType()))

            # Cleanup the dataframe
            self.df = self.df.drop(*["__INTERMEDIATE__", "__LEVELS__"])

        elif (lookup_column is not None) and (lookup_mapping is not None):

            # Create a lookup expression to map level names
            expression_num = None
            expression_name = None
            for i, (k, v) in enumerate(lookup_mapping.items()):
                condition = F.col(lookup_column) == k
                num, name = v[0], v[1]
                if i == 0:
                    expression_num = F.when(condition, num)
                    expression_name = F.when(condition, name)
                else:
                    expression_num = expression_num.when(condition, num)
                    expression_name = expression_name.when(condition, name)
            expression_num = expression_num.otherwise(None)
            expression_name = expression_name.otherwise(None)

            # Create hierarchy columns
            self.df = self.df.withColumn("HIER_LEVEL_NUM", expression_num)
            self.df = self.df.withColumn("HIER_LEVEL_NAME", expression_name)

        else:
            self.set_column("HIER_LEVEL_NAME", column=name_column, value=name_value)
            self.set_column("HIER_LEVEL_NUM", column=num_column, value=num_value)

    def set_hierarchy_chain_columns(self):
        """Creates hiearchy chain columns based on existing hierarchy information.

        Columns named after `"HIER_NAME"` column values will be created. They will be
        populated with the relevant `"HIER_LEVEL_NAME"` values based on `"HIER_LEVEL_NUM"`.
        """
        hierarchy_columns = [
            "HIER_NUM",
            "HIER_NAME",
            "HIER_LEVEL_NUM",
            "HIER_LEVEL_NAME",
        ]
        hierarchy_sub_columns = ["HIER_NUM", "HIER_LEVEL_NUM", "HIER_LEVEL_NAME"]

        window = Window.partitionBy("HIER_NUM").orderBy("__HIER_LEVEL_NUM_CAST__")

        df_hierarchies = (
            self.df.select(hierarchy_columns)
            .where(F.col("HIER_NUM").isNotNull())
            .distinct()
            .withColumn("__HIER_LEVEL_NUM_CAST__", F.col("HIER_LEVEL_NUM").cast(IntegerType()))
            .withColumn(
                "__HIERARCHIES__",
                F.concat_ws("!", F.collect_list("HIER_LEVEL_NAME").over(window)),
            )
            .groupBy(hierarchy_sub_columns)
            .pivot("HIER_NAME")
            .agg(F.first("__HIERARCHIES__"))
        )

        self.df = self.df.join(df_hierarchies, on=hierarchy_sub_columns, how="left")

        specific_columns = [c for c in self.df.columns if c not in self.standard_columns]

        self.df = self.df.select(self.standard_columns + specific_columns)

    @staticmethod
    def get_hierlist(df: DataFrame) -> List[str]:
        """Returns a list of non null distinct elements in column `"HIER_NAME"`.

        Args:
            df: Dataframe to get the hierarchy name list from.

        Returns:
            hierlist: List of hierarchy names in dataframe.

        Example:
            `hierlist = ["HIER1", "HIER2"]`
        """
        hierlist = (
            df.select("HIER_NAME")
            .distinct()
            .filter(F.col("HIER_NAME").isNotNull())
            .rdd.flatMap(lambda x: x)
            .collect()
        )
        return hierlist

    @staticmethod
    def get_hierarchy_level_names(df: DataFrame) -> List[str]:
        """Returns a list of non null distinct elements in column `"HIER_LEVEL_NAME"`.

        Args:
            df: Dataframe to get the hierarchy level name list from.

        Returns:
            hierlist: List of all hierarchy level names in dataframe.

        Example:
            `hierlist = ["CATEGORY", "MANUFACTURER", "BRAND"]`
        """
        collection = (
            df.select("HIER_LEVEL_NAME")
            .where(F.col("HIER_LEVEL_NAME").isNotNull())
            .distinct()
            .collect()
        )
        return [r["HIER_LEVEL_NAME"] for r in collection]

    def build_hierarchy_audit_utility_columns(self) -> DataFrame:
        """Returns dataframe from `self.df` with audit utility columns:

        - `"_HIER_LEVEL_LIST_"`:  List of elements in row's chain
        - `"_HIER_LEVEL_NAME_"`:  Last element in row's chain
        - `"_HIER_LEVEL_NUM_"`:  Number of elements in row's chain
        - `"_HIER_HASH_"`: Hash of the hierarchy name and hierarchy level name.

        Returns:
            df: Modified dataframe to be used in further hierarchy checks for the meta instance.
        """
        hierlist = self.get_hierlist(self.df)
        df = self.df.withColumn("_HIER_LEVEL_LIST_", F.lit(None))
        expression = None

        for i, h in enumerate(hierlist):
            condition = F.col("HIER_NAME").cast("string") == h
            value = F.split(F.col(h), "!")

            if i == 0:
                expression = F.when(condition, value)
            else:
                expression = expression.when(condition, value)

        expression = expression.otherwise(F.col("_HIER_LEVEL_LIST_"))

        df = df.withColumn("_HIER_LEVEL_LIST_", expression)
        df = df.withColumn(
            "_HIER_LEVEL_NUM_",
            F.when(F.col("HIER_NAME").isNull(), None).otherwise(F.size("_HIER_LEVEL_LIST_")),
        )
        df = df.withColumn(
            "_HIER_LEVEL_NAME_",
            F.col("_HIER_LEVEL_LIST_").getItem(F.col("_HIER_LEVEL_NUM_") - 1),
        )

        df = df.withColumn("_HIER_HASH_", F.md5(F.concat("HIER_NAME", "HIER_LEVEL_NAME")))

        return df

    @staticmethod
    def get_chainlist(df: DataFrame, hierlist: List[str]) -> List[str]:
        """Returns complete ordered list of longest chains for the given list of hierarchies.

        Args:
            df: Dataframe to get the chainlist from.
            hierlist: List of hierarchy names.

        Returns:
            chainlist: A list containing all elements in longest chain of every hierarchy in dimension.

        Example:
            `chainlist = ["Category", "SubCategory", "Manufacturer", "Brand", "Item"]`
        """
        chainlist = []

        for h in hierlist:
            hierarchy_max_level = (
                df.where(F.col("HIER_NAME") == h).agg({"_HIER_LEVEL_NUM_": "max"}).collect()[0][0]
            )

            hierarchy_chain_list = (
                df.where(F.col("HIER_NAME") == h)
                .where(F.col("_HIER_LEVEL_NUM_") == hierarchy_max_level)
                .limit(1)
                .select("_HIER_LEVEL_LIST_")
                .collect()[0][0]
            )

            [chainlist.append(x) for x in hierarchy_chain_list]

        return chainlist

    def audit_hierarchy_columns_are_populated(self):
        """Audits that the following columns are be present in `self.df`:
        [`HIER_NAME`,`HIER_LEVEL_NAME`,`HIER_LEVEL_NUM`,`HIER_NUM`].

        The hierarchy columns should either be all populated or all empty in any given row.

        Raises:
            ValueError: Instance dataframe is missing one hierarchy column.
            ValueError: Instance dataframe hierarchy columns are partially populated.
        """
        main_hier_columns = [
            "HIER_NAME",
            "HIER_LEVEL_NAME",
            "HIER_NUM",
            "HIER_LEVEL_NUM",
        ]

        if all(elem in self.df.columns for elem in main_hier_columns):
            df_main_hier = self.df.select(main_hier_columns)

            if df_main_hier.na.drop(how="all").count() != df_main_hier.na.drop().count():
                raise ValueError(
                    f"Hierarchy columns in the dimension of type '{self.__class__}' are partially populated."
                )
        else:
            raise ValueError(f"Dimension of type '{self.__class__}' is missing hierarchy columns.")

    @staticmethod
    def audit_hierarchy_coherence_with_chain(
        df: DataFrame, dimension_type: type, chainlist: List[str], hierlist: List[str]
    ):
        """Audits coherence between hierarchy chains and key hierarchy columns in a dataframe:
            - Coherence between `"HIER_LEVEL_NAME"` and `"_HIER_LEVEL_NAME_"`
            - Coherence between `"HIER_LEVEL_NUM"` and `"_HIER_LEVEL_NUM_"`
            - Coherence between elements in chainlist and distinct `"HIER_LEVEL_NAME"` values.

        Args:
            df: Dataframe to run the audit on.
            dimension_type: Type of the dimension the audit is running on.
            chainlist: List of all the elements in this meta dimensions hierarchy.

        Raises:
            ValueError: There is a hierarchy level incoherence in the dimension dataframe.
            valueError: Dimension dataframe does not contain expected hierarchy level names.
        """
        df_hier_coherent = df.filter(
            (F.col("HIER_LEVEL_NAME") != F.col("_HIER_LEVEL_NAME_"))
            | (F.col("HIER_LEVEL_NUM") != F.col("_HIER_LEVEL_NUM_"))
        )

        if not df_hier_coherent.rdd.isEmpty():
            df_hier_coherent.select(
                "TAG",
                "HIER_LEVEL_NAME",
                "HIER_LEVEL_NUM",
                "_HIER_LEVEL_NAME_",
                "_HIER_LEVEL_NUM_",
                *hierlist,
            ).show(truncate=False, vertical=True)
            raise ValueError(
                f"There is a hierarchy level incoherence in the dataframe of the dimension of type '{dimension_type}'."
            )

        levels = (
            df.select("HIER_LEVEL_NAME")
            .filter(F.col("HIER_LEVEL_NAME").isNotNull())
            .distinct()
            .rdd.flatMap(lambda x: x)
            .collect()
        )

        if not all(elem in levels for elem in chainlist):
            element = set(chainlist).difference(set(levels))
            raise ValueError(
                f"Dimension of type `{dimension_type}` does not contain the '{element}' level of its Hierarchy."
            )

    @staticmethod
    def audit_hierarchy_level_name_columns_exist(
        df: DataFrame, dimension_type: type, chainlist: List[str]
    ):
        """Audits a column exists for each hierarchy level names of a dataframe.

        Args:
            df: Dataframe to run the audit on.
            dimension_type: Type of the dimension the audit is running on.
            chainlist: List of all the elements in this meta dimensions hierarchy.

        Raises:
            ValueError: Elements in `"HIER_LEVEL_NAME"` do not have a corresponding column in the dimension dataframe.
        """
        if not all(elem in df.columns for elem in chainlist):
            print("Missing the following columns: ", set(chainlist) - set(df.columns))

            raise ValueError(
                f"Elements in hierarchy do not have a corresponding column for dimension of type '{dimension_type}'."
            )

    @staticmethod
    def audit_hierarchy_root_is_unique(df: DataFrame, dimension_type: type, hierlist: List[str]):
        """Audits there is one single record at the root of each hierarchy of a dataframe.

        Args:
            df: Dataframe to run the audit on.
            dimension_type: Type of the dimension the audit is running on.
            hierlist: List of hierarchy names.

        Raises:
            ValueError: Total is not available for all hierarchies in instance dataframe.
        """
        df_root = (
            df.groupBy("HIER_NAME", "HIER_LEVEL_NUM", "HIER_LEVEL_NAME")
            .count()
            .where(F.col("HIER_LEVEL_NUM") == 1)
        )

        if len(hierlist) != df_root.where(F.col("count") == 1).count():
            df_root.show(truncate=False, vertical=True)
            raise ValueError(
                f"Total is not available for all hierarchies in dataframe of instance type '{dimension_type}'."
            )

    @staticmethod
    def audit_hierarchy_chains_integrity(
        df: DataFrame, dimension_type: type, chainlist: List[str], hierlist: List[str]
    ):
        """Audits that \\Raises an exception if row's chain contains spelling mistakes, non-exisiting elements, or incorrect order of elements when compared to the elements in the chainlist.

        Args:
            df: Dataframe to run the audit on.
            dimension_type: Type of the dimension the audit is running on.
            chainlist: List of all the elements in this meta dimensions hierarchy [Ex. {Category, SubCategory, Manufacturer, Item}]
            hierlist: List of all hierarchies in `df`. [Ex. {LEVEL, LEVEL2, LEVEL3}]

        Raises:
            ValueError: The hierarchy chain for some values in the instance dataframe is not valid.

        Example:
            Incorrect chains given chainlist [Category, SubCategory, Manufacturer, Item]
                -Cat!SubCat!Man
                -Category!SubCategory!Item
                -Manufacturer!Item
                -Manufacturer!Category
        """
        val = chainlist[0]

        for i in range(len(chainlist) - 1):
            val += "!"
            val += chainlist[i + 1]

        df_check_chain = df.withColumn("fullchain", F.lit(val))

        for hier in hierlist:
            df_check_chain_values = df_check_chain.filter(
                (F.col(hier).isNotNull()) & (~F.col("fullchain").contains(F.col(hier)))
            )
            if not df_check_chain_values.rdd.isEmpty():
                df_check_chain_values.select(
                    "TAG", "HIER_LEVEL_NAME", "HIER_LEVEL_NUM", hier, "fullchain"
                ).show(truncate=False, vertical=True)
                raise ValueError(
                    f"The hierarchy chain for some values in dataframe of instance of type '{dimension_type}' is not valid."
                )

    @staticmethod
    def audit_hierarchy_level_name_columns_are_populated(df: DataFrame, dimension_type: type):
        """Audits that the hierarchy level name columns are correctly populated in a dataframe.

        Args:
            df: Dataframe to run the audit on.
            dimension_type: Type of the dimension the audit is running on.

        Raises:
            ValueError: Hierarchy level names columns of the dataframe are not appropriately populated.
        """

        # Create a list of rows with hash and hierarchy level list.
        level_summary = (
            df.select("_HIER_HASH_", "_HIER_LEVEL_LIST_")
            .distinct()
            .where(F.col("_HIER_HASH_").isNotNull())
            .collect()
        )

        # Build a mapping based on hierarchy hash to allow translation of array of column names into array of column values
        level_mapping = F.create_map(
            *chain.from_iterable(
                (F.lit(row["_HIER_HASH_"]), F.array(row["_HIER_LEVEL_LIST_"]))
                for row in level_summary
            )
        )

        # Create the column containing the populated values and keep rows where the number of
        # expected columns populated is not correct.
        df_chain_cols = (
            df.withColumn("_POPULATED_VALUES_", level_mapping[F.col("_HIER_HASH_")])
            .withColumn(
                "_POPULATED_VALUES_",
                F.expr("FILTER(_POPULATED_VALUES_, x -> x is not null)"),
            )
            .filter(F.size(F.col("_POPULATED_VALUES_")) != F.col("_HIER_LEVEL_NUM_"))
        )

        if not df_chain_cols.rdd.isEmpty():
            print(
                "Here is a list of tags for which the hierarchy columns are not appropriatelty populated. \
            The '_HIER_LEVEL_LIST_' column displays the columns that are supposed to be populated. \
            The '_POPULATED_VALUES_' column displays the non-null values that are actually populated given the hierarchy level list."
            )

            df_chain_cols.select("TAG", "_HIER_LEVEL_LIST_", "_POPULATED_VALUES_").show(
                truncate=False, vertical=True
            )
            raise ValueError(
                f"Hierarchy characteristics for the dataframe of instance of type '{dimension_type}' are not appropriately populated."
            )

    def audit_hierarchy(self, checks_to_skip: List[str]):
        """Runs hierarchy audits except those into checks_to_skip parameter.

        Args:
            checks_to_skip: List of checks to be skipped on `self.df`. Options = [hierarchy_coherence_with_chain,
                                                                            hierarchy_level_name_columns_exist,
                                                                            hierarchy_root_is_unique,
                                                                            hierarchy_chains_integrity,
                                                                            hierarchy_level_name_columns_are_populated]

        """
        self.audit_hierarchy_columns_are_populated()

        df = self.build_hierarchy_audit_utility_columns()
        hierlist = self.get_hierlist(df)
        chainlist = self.get_chainlist(df, hierlist)

        if "hierarchy_coherence_with_chain" not in checks_to_skip:
            self.audit_hierarchy_coherence_with_chain(df, self.__class__, chainlist, hierlist)
        if "hierarchy_level_name_columns_exist" not in checks_to_skip:
            self.audit_hierarchy_level_name_columns_exist(df, self.__class__, chainlist)
        if "hierarchy_root_is_unique" not in checks_to_skip:
            self.audit_hierarchy_root_is_unique(df, self.__class__, hierlist)
        if "hierarchy_chains_integrity" not in checks_to_skip:
            self.audit_hierarchy_chains_integrity(df, self.__class__, chainlist, hierlist)
        if "hierarchy_level_name_columns_are_populated" not in checks_to_skip:
            self.audit_hierarchy_level_name_columns_are_populated(df, self.__class__)

    def set_parent_tag(
        self,
        hierarchy_name: Optional[str] = None,
        hierarchy_level_numbers: Optional[List[str]] = None,
        hierarchy_store: Optional[dict[str, str]] = None,
    ):
        """Populates the parent tag column in `self.df` for the given hierarchy names.

        Args:
            hierarchy_name: Name of the hierarchy to build the parent tag relationship for.
            hierarchy_level_numbers: Level numbers to build the parent tag relationship for, in the given hierarchy.
            hierarchy_store: Combination of hierarchy name and level numbers in case the parent tag needs to be created for multiple hierarchies.

        Raises:
            ValueError: If `hierarchy_name` and `hierarchy_store` are both `None`.
            ValueError: If the pseudo tag column contains duplicates.
        """

        # Arguments preparation
        if hierarchy_store is not None:
            pass
        elif hierarchy_name is not None:
            hierarchy_store = {hierarchy_name: hierarchy_level_numbers}
        else:
            raise ValueError(
                "Arguments 'hierarchy_name' and 'hierarchy_store' cannot be both 'None'."
            )

        # Prepare variables
        df_tmp = self.df
        original_columns = df_tmp.columns
        selection_condition = []

        # Build splitting expressions depending on the hierarchy name
        expression_split = None
        expression_split_parent = None
        for i, (h, n) in enumerate(hierarchy_store.items()):
            if n is None:
                condition = F.col("HIER_NAME") == h
            else:
                condition = (F.col("HIER_NAME") == h) & (F.col("HIER_LEVEL_NUM").isin(n))

            value = F.split(F.col(h), "!")
            value_parent = F.array_except(F.split(F.col(h), "!"), F.array(F.col("HIER_LEVEL_NAME")))
            if i == 0:
                expression_split = F.when(condition, value)
                expression_split_parent = F.when(condition, value_parent)
            else:
                expression_split = expression_split.when(condition, value)
                expression_split_parent = expression_split_parent.when(condition, value_parent)

            # Build condition for products to have a parent tag created for
            selection_condition.append(condition)

        selection_condition = reduce(lambda acc, x: acc | x, selection_condition)
        expression_split = expression_split.otherwise(F.array([]))
        expression_split_parent = expression_split_parent.otherwise(F.array([]))

        # Create the concatenation of "HIER_NAME" and "HIER_LEVEL_NAME" to have unique mapping across hierarchy names
        df_tmp = df_tmp.withColumn(
            "__CONCATENATION_HIER_NAME_AND_LEVEL__",
            F.concat(F.col("HIER_NAME"), F.col("HIER_LEVEL_NAME")),
        )

        # Create the mappings for child and parent
        hierarchy_level_names_mapping = (
            df_tmp.select(
                "HIER_NAME",
                "HIER_LEVEL_NUM",
                "HIER_LEVEL_NAME",
                "__CONCATENATION_HIER_NAME_AND_LEVEL__",
                *list(hierarchy_store.keys()),
            )
            .distinct()
            .withColumn("__SPLIT__", expression_split)
            .withColumn("__SPLIT_PARENT__", expression_split_parent)
            .collect()
        )

        level_mapping = F.create_map(
            *chain.from_iterable(
                (
                    F.lit(row["__CONCATENATION_HIER_NAME_AND_LEVEL__"]),
                    F.concat(F.col("HIER_NAME"), *row["__SPLIT__"]),
                )
                for row in hierarchy_level_names_mapping
            )
        )

        level_mapping_parent = F.create_map(
            *chain.from_iterable(
                (
                    F.lit(row["__CONCATENATION_HIER_NAME_AND_LEVEL__"]),
                    F.concat(F.col("HIER_NAME"), *row["__SPLIT_PARENT__"]),
                )
                for row in hierarchy_level_names_mapping
            )
        )

        # Apply parent mapping to input dataframe
        df_tmp = df_tmp.withColumn(
            "__PSEUDO_PARENT_TAG__",
            F.when(
                selection_condition,
                level_mapping_parent[F.col("__CONCATENATION_HIER_NAME_AND_LEVEL__")],
            ).otherwise(None),
        )

        # In addition to the parent mapping, apply the child mapping to the dataframe that is going to map the tags
        df_parent_mapping = (
            df_tmp.where(selection_condition)
            .withColumn(
                "__PSEUDO_TAG__",
                level_mapping[F.col("__CONCATENATION_HIER_NAME_AND_LEVEL__")],
            )
            .select("TAG", "__PSEUDO_TAG__")
            .withColumnRenamed("TAG", "__CREATED_PARENT_TAG__")
        )

        # Check that each pseudo tag value is unique
        assertion_columns_have_duplicates, df_duplicates = columns_have_duplicates(
            df_parent_mapping, ["__PSEUDO_TAG__"]
        )
        if assertion_columns_have_duplicates:
            df_duplicates.show(truncate=False, vertical=True)
            raise ValueError("Column '__PSEUDO_TAG__' contains duplicates.")

        # Join the input dataframe with the tag mapping dataframe
        df_tmp = df_tmp.alias("df1").join(
            df_parent_mapping.alias("df2"),
            F.col("df1.__PSEUDO_PARENT_TAG__") == F.col("df2.__PSEUDO_TAG__"),
            how="left",
        )

        # Re-organize the information inside of the PARENT_TAG column to keep potential information from
        # untouched rows in that column. After that, reorder columns.
        if "PARENT_TAG" in original_columns:
            df_tmp = df_tmp.withColumn(
                "PARENT_TAG",
                F.when(
                    selection_condition,
                    F.col("__CREATED_PARENT_TAG__"),
                ).otherwise(F.col("PARENT_TAG")),
            )
        else:
            df_tmp = df_tmp.withColumnRenamed("__CREATED_PARENT_TAG__", "PARENT_TAG")
            original_columns.append("PARENT_TAG")
        df_tmp = df_tmp.select(original_columns)
        self.df = df_tmp

    def replace_characters_from_column_names(self, pattern: str, replacement: str):
        """Replaces characters from column names and propagates the updates to related field values in `self.df`.

        Args:
            pattern: Regular expression of the substrings to replace.
            replacement: Replacement string for matched substrings.

        Raises:
            ValueError: If duplicated columns appear in `self.df` after the formatting.
            ValueError: If the hierarchy chains are partially in columns.
        """
        # Update column names
        original_columns = self.df.columns
        self.df = self.df.toDF(*[re.sub(pattern, replacement, c) for c in self.df.columns])

        if len(set(original_columns)) != len(set(self.df.columns)):
            raise ValueError(
                f"Duplicated columns generated in 'replace_characters_from_column_names' for dimension type '{self.__class__}' during formatting."
            )

        # Update HIER_NAME, HIER_LEVEL_NAME, and chain field values
        # if str(self.__class__) in ["Market", "Product", "Period"]:
        if str(self.__class__).endswith(tuple(["Market'>", "Product'>", "Period'>"])):
            self.df = self.df.withColumn(
                "HIER_NAME", F.regexp_replace(F.col("HIER_NAME"), pattern, replacement)
            ).withColumn(
                "HIER_LEVEL_NAME",
                F.regexp_replace(F.col("HIER_LEVEL_NAME"), pattern, replacement),
            )

            # Update hierarchy chain field values
            hierarchy_names = Meta.get_hierlist(self.df)
            hierarchy_names_in_columns = [h for h in hierarchy_names if h in self.df.columns]
            # If all hierarchy names are in the columns, update the chain field values
            if len(hierarchy_names) == len(hierarchy_names_in_columns):
                for h in hierarchy_names:
                    h = re.sub(pattern, replacement, h)
                    self.df = self.df.withColumn(
                        h, F.regexp_replace(F.col(h), pattern, replacement)
                    )
            # If no hierarchy name is in the columns, skip
            elif len(hierarchy_names_in_columns) == 0:
                pass
            # If some hierarchy names are in the columns, raise an exception.
            else:
                difference = set(hierarchy_names) - set(hierarchy_names_in_columns)
                raise ValueError(
                    f"Hierarchy names exist partially as chain columns for dimension type '{self.__class__}': columns {difference} are missing."
                )

    def replace_characters_from_values(self, pattern: str, replacement: str):
        """Replaces characters from field values and propagates the updates to related column names.

        Args:
            pattern: Regular expression of the substrings to replace.
            replacement: Replacement string for matched substrings.

        Raises:
            ValueError: If duplicated columns appear in `self.df` after the formatting.
            ValueError: If the hierarchy chains are partially in columns.
        """
        original_columns = self.df.columns

        # Update hierarchy level name column names and chain column names
        # if str(self.__class__) in ["Market", "Product", "Period"]:
        if str(self.__class__).endswith(tuple(["Market'>", "Product'>", "Period'>"])):

            # Update hierarchy level name column names if they are available in the columns
            hierarchy_level_names = Meta.get_hierarchy_level_names(self.df)
            hierarchy_level_names_in_columns = [
                h for h in hierarchy_level_names if h in self.df.columns
            ]

            self.df = self.df.select(
                [
                    F.col(f"`{c}`").alias(re.sub(pattern, replacement, c))
                    if c in hierarchy_level_names_in_columns
                    else c
                    for c in self.df.columns
                ]
            )

            # Update chain column names
            hierarchy_names = Meta.get_hierlist(self.df)
            hierarchy_names_in_columns = [h for h in hierarchy_names if h in self.df.columns]

            # If all hierarchy names are in the columns, update the chain field values
            if len(hierarchy_names) == len(hierarchy_names_in_columns):
                self.df = self.df.select(
                    [
                        F.col(f"`{c}`").alias(re.sub(pattern, replacement, c))
                        if c in hierarchy_names
                        else c
                        for c in self.df.columns
                    ]
                )
            # If no hierarchy name is in the columns, skip
            elif len(hierarchy_names_in_columns) == 0:
                pass
            # If some hierarchy names are in the columns, raise an exception.
            else:
                difference = set(hierarchy_names) - set(hierarchy_names_in_columns)
                raise ValueError(
                    f"Hierarchy names exist partially as chain columns for dimension type '{self.__class__}': columns {difference} are missing."
                )

            # Audit if duplicated values have been created
            if len(set(original_columns)) != len(set(self.df.columns)):
                raise ValueError(
                    f"Duplicated columns generated in 'replace_characters_from_values' for dimension type '{self.__class__}' during formatting."
                )

        # Update field values
        self.df = self.df.select(
            [F.regexp_replace(F.col(c), pattern, replacement).alias(c) for c in self.df.columns]
        )

    def rename_duplicated_modulo_index(
        self, duplicated_columns: List[str], selection_method: str = "first"
    ):
        """Renames columns that have been identified as duplicates with an affix of their index.

        Args:
            duplicated_columns: List of columns that are suspected to be duplicated with a module index affix.
            selection_method: A string specifying the method of deduplication. The options are:

                - `"first"` : deduplicate the column with the lowest index.
                - `"most_values"` : deduplicate the column with the most values.
        Raises:
            ValueError: When the selectio_method is not one of those accepted
        """
        # we get a boolean as to whether or not the spark context is case sensitive
        case_sensitive = spark.conf.get("spark.sql.caseSensitive") == "true"
        # df_columns will look like either {"Brand":"Brand", "GL_Level":"GL_Level"}
        # or otherwise will look like {"Brand":"brand", "GL_Level":"gl_level"}
        df_columns = {col: (col if case_sensitive else col.casefold()) for col in self.df.columns}
        # columns_without_index will look like: {"TAG": "TAG", "CAT2": "CAT", "CAT3": "CAT"}
        columns_without_index = {
            name: re.sub(f"{index}$", "", name) for index, name in enumerate(df_columns)
        }
        # columns_to_deduplicate will look like: {"CAT", "BRAND"}
        columns_to_deduplicate = {
            columns_without_index[c] if case_sensitive else columns_without_index[c].casefold()
            for c in duplicated_columns
        }

        if selection_method == "first":
            for column in df_columns:
                # if we suspect the column is a duplicate, and its' true name has not already been deduplicated
                if (
                    (columns_without_index[column].casefold() in columns_to_deduplicate)
                    or (columns_without_index[column] in columns_to_deduplicate)
                ) and (column in duplicated_columns):
                    self.df = self.df.withColumnRenamed(column, columns_without_index[column])
                    try:
                        columns_to_deduplicate.remove(columns_without_index[column])
                    except KeyError:
                        columns_to_deduplicate.remove(columns_without_index[column].casefold())
        elif selection_method == "most_values":
            for key_column in columns_to_deduplicate:
                count_of_values = {}
                # we find the column with the most number of cells that are not null
                for column in df_columns:
                    if key_column in df_columns[column]:
                        count_of_values[column] = self.df.where(F.col(column).isNotNull()).count()
                column_with_most_values = max(count_of_values, key=count_of_values.get)
                # we rename that column which has the most number of cells that are not null
                self.df = self.df.withColumnRenamed(
                    column_with_most_values,
                    columns_without_index[column_with_most_values],
                )
        else:
            raise ValueError(
                f"The selection_method '{selection_method}' is not supported. Please select one of 'first' and 'most_values'."
            )
