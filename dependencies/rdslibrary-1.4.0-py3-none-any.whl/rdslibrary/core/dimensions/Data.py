from __future__ import annotations

import operator
import re
from typing import List, Optional

import pyspark.sql.functions as F
from pyspark.sql.dataframe import DataFrame
from rdslibrary.core.Dimension import Dimension
from rdslibrary.utilities.spark import get_dbutils, get_spark

spark = get_spark()
dbutils = get_dbutils(spark)

ops = {
    "+": operator.add,
    "-": operator.sub,
    "*": operator.mul,
    "/": operator.truediv,  # use operator.div for Python 2
    "%": operator.mod,
    "^": operator.xor,
}


class Data(Dimension):
    """
    Class describing the data dimension of Redslim standard format.
    """

    def __init__(self, df: Optional[DataFrame] = None):
        """Class constructor.

        Args:
            df: Dataframe reprensenting the dimension.
        """
        std = ["MARKET_TAG", "PRODUCT_TAG", "PERIOD_TAG"]
        super().__init__(df=df, standard_columns=std)

    def replace_problematic_characters_from_fact_tags(self):
        """Updates fact tags in `self.df` to avoid any character different from `[A-Z0-9]`.

        Frequent special characters are replaced by a word equivalent:
        "€": "EURO", "$": "DOLLAR", "%": "PERCENT", "£": "POUND".

        Raises:
            Exception: If duplicated fact tags appear in `self.df`.

        """
        forbidden_substring_dictionary = {
            "$": "DOLLAR",
            "€": "EURO",
            "%": "PERCENT",
            "£": "POUND",
        }

        regex_expression = re.compile(
            "|".join(map(re.escape, forbidden_substring_dictionary.keys()))
        )

        # Update columns
        self.df = self.df.select(
            [
                F.col(f"`{c}`").alias(
                    re.sub(
                        r"[^A-Z0-9]",
                        "",
                        regex_expression.sub(
                            lambda match: forbidden_substring_dictionary[match.group(0)],
                            c.upper(),
                        ),
                    )
                )
                if c not in ["MARKET_TAG", "PRODUCT_TAG", "PERIOD_TAG"]
                else F.col(c)
                for c in self.df.columns
            ]
        )

        # Check no duplicated tag is in the columns of the data dataframe
        if len(set(self.df.columns)) != len(self.df.columns):
            raise Exception(
                "Data dataframe has duplicated fact tags following replacement of problematic characters from columns."
            )

    def audit_tag_combinations_are_unique(self):
        """Audits that `["MARKET_TAG", "PRODUCT_TAG", "PERIOD_TAG"]` columns contain combination duplicates in `self.df`.

        Raises:
            ValueError: Tag combinations in `["MARKET_TAG", "PRODUCT_TAG", "PERIOD_TAG"]` are not unique.
        """
        df_duplicated_combinations = (
            self.df.groupBy("MARKET_TAG", "PRODUCT_TAG", "PERIOD_TAG").count().filter("count > 1")
        )

        if not df_duplicated_combinations.rdd.isEmpty():
            df_duplicated_combinations.show(truncate=False, vertical=True)
            raise ValueError("Data has duplicated tag combinations.")

    def apply_special_cases_on_read(self):
        """Harmonizes `self.df` with known special cases for a specific dimension."""

        if "MKT_TAG" in self.df.columns:
            self.df = self.df.withColumnRenamed("MKT_TAG", "MARKET_TAG")
        if "PROD_TAG" in self.df.columns:
            self.df = self.df.withColumnRenamed("PROD_TAG", "PRODUCT_TAG")
        if "PER_TAG" in self.df.columns:
            self.df = self.df.withColumnRenamed("PER_TAG", "PERIOD_TAG")

    def sum_columns(self, name: str, columns: List[str]):
        """Create a new column in `"Data"` dimension based on `"name"` argument.

        Args:
            name: Name of the column that we want to create.
            columns: List of columns we want to sum.

        Raises:
            ValueError: If a column named `"name"` already exists or if `"columns"` list contains "MARKET_TAG", "PRODUCT_TAG" or "PERIOD_TAG".
        """

        if name in ["MARKET_TAG", "PRODUCT_TAG", "PERIOD_TAG"]:
            raise ValueError(
                f"Name parameter must be different to {'MARKET_TAG'}, {'PRODUCT_TAG'} and {'PERIOD_TAG'}."
            )
        if name in self.df.columns:
            raise ValueError(f"A column named '{name}' already exists.")

        # Creating an addition expression using `join`
        expression = "+".join([f"`{col}`" for col in columns])

        self.df = self.df.withColumn(name, F.expr(expression))

    def multiply_column_by_factor(self, name: str, column: str, factor: float):
        """Create a new column in `"Data"` dimension based on `"name"` argument.

        Args:
            name: Name of the column that we want to create.
            column: Name of the column we want to multiply.
            factor: The number we want to multiply by

        Raises:
            ValueError: If a column named `"name"` already exist or if `"columns"` list contains "MARKET_TAG", "PRODUCT_TAG" or "PERIOD_TAG".
        """

        if name in ["MARKET_TAG", "PRODUCT_TAG", "PERIOD_TAG"]:
            raise ValueError(
                f"Name parameter must be different to {'MARKET_TAG'}, {'PRODUCT_TAG'} and {'PERIOD_TAG'}."
            )
        if name in self.df.columns:
            raise ValueError(f"A column named '{name}' already exists.")

        self.df = self.df.withColumn(name, self.df[column] * factor)

    def sum_or_subsctract_two_columns(self, name: str, column1: str, column2: str, operator: str):
        """Create a new column in `"Data"` dimension based on `"name"` arguument.

        Args:
            name: Name of the column to we want to create.
            column1: The first column of the operation.
            column2: The second column of the operation.
            operator: addition or substraction operator

        Raises:
            ValueError: If a column named `"name"` already exist or if `"columns"` list contains "MARKET_TAG", "PRODUCT_TAG" or "PERIOD_TAG".
        """
        if operator not in ["+", "-"]:
            raise ValueError(
                f"Operator can only be addition or substraction but you give '{operator}'."
            )

        if name in ["MARKET_TAG", "PRODUCT_TAG", "PERIOD_TAG"]:
            raise ValueError(
                f"Name parameter must be different to {'MARKET_TAG'}, {'PRODUCT_TAG'} and {'PERIOD_TAG'}."
            )
        if name in self.df.columns:
            raise ValueError(f"A column named '{name}' already exists.")

        self.df = self.df.withColumn(name, ops[operator](self.df[column1], self.df[column2]))

    def apply_operation_with_expression(self, name: str, expression: str):
        """Create a new column in `"Data"` dimension based on `"name"` arguument.

        Args:
            name: Name of the column to we want to create.
            expression: The expression we want to apply.

        Raises:
            ValueError: If a column named `"name"` already exist or if `"columns"` list contains "MARKET_TAG", "PRODUCT_TAG" or "PERIOD_TAG".
        """

        if name in ["MARKET_TAG", "PRODUCT_TAG", "PERIOD_TAG"]:
            raise ValueError(
                f"Name parameter must be different to {'MARKET_TAG'}, {'PRODUCT_TAG'} and {'PERIOD_TAG'}."
            )
        if name in self.df.columns:
            raise ValueError(f"A column named '{name}' already exists.")

        self.df = self.df.withColumn(name, F.expr(expression))
