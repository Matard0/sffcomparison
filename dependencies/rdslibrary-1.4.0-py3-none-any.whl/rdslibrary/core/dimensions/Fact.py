from __future__ import annotations

import re
from typing import Optional

import pyspark.sql.functions as F
from pyspark.sql import Row
from pyspark.sql.dataframe import DataFrame
from rdslibrary.core.dimensions.Meta import Meta
from rdslibrary.utilities.spark import get_dbutils, get_spark

spark = get_spark()
dbutils = get_dbutils(spark)


class Fact(Meta):
    """
    Class describing the fact dimension of Redslim standard format.
    """

    def __init__(self, df: Optional[DataFrame] = None):
        """Class constructor.

        Args:
            df: Dataframe reprensenting the dimension.
        """
        std = [
            "TAG",
            "SHORT",
            "LONG",
            "DISPLAY_ORDER",
            "CURRENCY",
            "PRECISION",
            "DENOMINATOR",
            "MKT_AGGREGATION",
            "PROD_AGGREGATION",
            "PER_AGGREGATION",
        ]
        super().__init__(df=df, standard_columns=std)

        self.additive_fact_aliases = [
            "VAL",
            "VOL",
            "UNI",
            "VALPRO",
            "VOLPRO",
            "UNIPRO",
        ]

    def align_facts(
        self,
        dictionary: dict[str, str],
        source: Optional[str] = "TAG",
        target_align: Optional[str] = "RDSLM_FACT_ALIGN",
        target_type: Optional[str] = "RDSLM_FACT_TYPE",
        set_type: Optional[bool] = True,
    ):
        """Populates fact alignment columns.

        If source column `"TAG"` is used, a regex formatting removing `"[^A-Za-z0-9]"`
        characters is used to simplify tag values selection. Indeed, for most use cases, `"TAG"`
        as source will be enough.

        The fact type column can optionally be not populated using `set_type` argument. See `set_fact_type` method for
        details on how facts are labeled with type.

        Args:
            dictionary: Dictionary mapping the facts aliases.
            source: Column to translate aliases from.
            target_align: Column to populate with fact aliases.
            target_type: Column to populate with fact types.
            set_type: Specify if the target fact type column needs to be populated.

        Raises:
            ValueError: If values in the dictionary are duplicated.
            ValueError: If a key from the dictionary does no match an existing value in the specified column.
        """
        # Format dictionary keys if column argument is equal to "TAG" to help user selection
        if source == "TAG":
            dictionary = {re.sub(r"[^A-Za-z0-9]", "", k).upper(): v for k, v in dictionary.items()}

        # Create alignment mapping
        df_mapping = spark.createDataFrame(
            [Row(**{"__KEY__": k, "__FACT_ALIGN__": v}) for k, v in dictionary.items()]
        )

        dict_values = dictionary.values()

        if len(set(dict_values)) == len(dict_values):

            self.df = self.df.join(
                df_mapping, self.df[source] == df_mapping["__KEY__"], how="left"
            ).drop("__KEY__")
            self.df = self.df.withColumn(target_align, F.col("__FACT_ALIGN__"))
            self.df = self.df.drop("__FACT_ALIGN__")

            if set_type:
                self.set_fact_type(source=target_align, fact_type_column=target_type)

            if self.df.where(F.col(target_align).isNotNull()).count() != len(dict_values):
                raise ValueError(
                    f"Not all keys from dictionary are available in source column '{source}'."
                )
        else:
            raise ValueError("Dictionary provided has duplicated values.")

    def set_fact_type(self, source, fact_type_column: str = "RDSLM_FACT_TYPE"):
        """Populates fact type column based on source column.

        The fact type is determined by an internal list. Currently supported additive fact aliases are: `["VAL","VOL","UNI","VALPRO",
        "VOLPRO","UNIPRO"]`. Other facts are labeled as `"NON-ADDITIVE"`.

        Args:
            source: Column to use when setting the fact type.
            fact_type_column: Name of the fact type column.
        """
        self.df = self.df.withColumn(
            fact_type_column,
            F.when(F.col(source).isin(self.additive_fact_aliases), "ADDITIVE")
            .when(F.col(source).isNull(), None)
            .otherwise("NON-ADDITIVE"),
        )

    def replace_problematic_characters_from_tags(self):
        """Updates tags in `self.df` to avoid any character different from `[A-Z0-9]`.

        Frequent special characters are replaced by a word equivalent:
        "€": "EURO", "$": "DOLLAR", "%": "PERCENT", "£": "POUND".

        Raises:
            Exception: If duplicated tags appear in `self.df`.

        """
        forbidden_substring_dictionary = {
            "$": "DOLLAR",
            "€": "EURO",
            "%": "PERCENT",
            "£": "POUND",
        }

        # Update fact tags
        when_expression = None
        for i, (s, r) in enumerate(forbidden_substring_dictionary.items()):
            condition = F.col("TAG").contains(s)
            replacement = F.regexp_replace(F.col("TAG"), re.escape(s), r)
            if i == 0:
                when_expression = F.when(condition, replacement)
            else:
                when_expression = when_expression.when(condition, replacement)
        when_expression = when_expression.otherwise(F.col("TAG"))

        self.df = self.df.withColumn("TAG", when_expression).withColumn(
            "TAG", F.regexp_replace(F.upper(F.col("TAG")), r"[^A-Z0-9]", "")
        )

        # Check no duplicated tag is in the "TAG" column of the fact dataframe
        if self.df.count() > self.df.dropDuplicates(["TAG"]).count():
            raise Exception(
                "Fact dataframe has duplicated tags following replacement of problematic characters."
            )

    def audit_check_align_and_type(self):
        """Audits that `"RDSLM_FACT_ALIGN"` or `"RDSLM_FACT_TYPE"` column are empty in `self.df`

        Raises:
            ValueError: The `"RDSLM_FACT_ALIGN"`, `"RDSLM_FACT_TYPE"` column is empty.
        """
        for col in ["ALIGN", "TYPE"]:
            if self.df.filter(F.col(f"RDSLM_FACT_{col}").isNull()).count() == self.df.count():
                raise ValueError(f"The 'RDSLM_FACT_{col}' column is empty.")
