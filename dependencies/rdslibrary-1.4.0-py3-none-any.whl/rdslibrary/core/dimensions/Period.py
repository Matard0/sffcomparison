from __future__ import annotations

import re
from math import floor
from typing import List, Optional

import pyspark.sql.functions as F
from pyspark.sql import Window
from pyspark.sql.dataframe import DataFrame
from pyspark.sql.types import DateType, IntegerType, StringType, StructField, StructType
from rdslibrary.core.dimensions.Meta import Meta
from rdslibrary.utilities.spark import get_dbutils, get_spark
from rdslibrary.utilities.testing import columns_have_duplicates

spark = get_spark()
dbutils = get_dbutils(spark)


class Period(Meta):
    """
    Class describing the period dimension of Redslim standard format.
    """

    def __init__(self, df: Optional[DataFrame] = None, periodicity: Optional[str] = None):
        """Class constructor.

        Args:
            df: Dataframe reprensenting the dimension.
        """
        std = [
            "TAG",
            "SHORT",
            "LONG",
            "DISPLAY_ORDER",
            "PARENT_TAG",
            "HIER_NUM",
            "HIER_NAME",
            "HIER_LEVEL_NUM",
            "HIER_LEVEL_NAME",
        ]
        super().__init__(df=df, standard_columns=std)
        self.periodicity = periodicity

    def align_periods(
        self,
        periodicity: str,
        parser: str,
        columns: Optional[List[str]] = ["TAG"],
        regex: Optional[str] = None,
        mappings: Optional[dict[str, str]] = None,
        set_period_align: bool = True,
        set_datetime: bool = True,
        rank_type: str = "default",
        audit_year_and_rank_columns: bool = True,
    ):
        """Populates period alignment columns.

        The following columns can be created:

          - `"PER_ALIGN"`: Standard tag for the period.
          - `"DATETIME"`: Datetime representing the period.
          - `"YEAR"`: Year of the period.
          - `"RANK"`: Rank of the period in the year.

        For more information on datetime formatting and parsing, visit
        [Spark datetime pattern reference](https://spark.apache.org/docs/latest/sql-ref-datetime-pattern.html).

        Args:
            periodicity: Periodicity name, can be `"monthly"`, `"weekyday"`, `"weekynum"`, `"4weekynum"`, `"4weekyday"`, `"yearly"` or `"445weekynum"`.
            parser: String defining the date format of the input period value e.g. `"MMM yyyy"`.
            columns: List of column names to use to create the different alignment columns.
            regex: Regular expression to extract from the concatenation of columns, the first match is extracted.
            mappings: Dictionary defining a mapping of values which will not be recognised by the English
                language pyspark datetime parser, to those that will be recognised by this function,
                e.g. `{"FEBRY":"Feb", "AP":"Apr", "ENERO": "Jan"}`
            set_period_align: Boolean requesting column `"PER_ALIGN"` to be populated.
            set_datetime: Boolean requesting columns `"DATETIME"`, `"YEAR"`, and `"RANK"` to be populated.
            rank_type: String to be used if `set_datetime` is also `True`. Will default to `"default"`, otherwise use `"no53"`.
            audit_year_and_rank_columns: A boolean used to specify whether or not to audit the YEAR and RANK columns after population.

        Raises:
            ValueError: If duplicates are found in:

                - The concatenation of columns.
                - The concatenation of columns after regex extraction.
                - The concatenation of columns after mapping.
                - The period align column.

            ValueError: If the extraction regex does not match for some records.
        """
        self.periodicity = periodicity
        # Merge columns from parameter and extract useful substring
        self.df = self.df.withColumn("__PERIOD__", F.concat_ws(" ", *columns))

        # Raise an exception if the __PERIOD__ column contains duplicate values
        assertion, df_duplicates = columns_have_duplicates(self.df, ["__PERIOD__"])
        if assertion:
            self.df.show(truncate=False, vertical=True)
            raise ValueError(
                f"There are duplicated values for the concatenation of columns {columns} in column '__PERIOD__'."
            )

        if regex is not None:
            self.df = self.df.withColumn(
                "__PERIOD_REGEX__", F.regexp_extract("__PERIOD__", regex, 0)
            )
            df_extraction_failure = self.df.where(
                F.col("__PERIOD__").isNotNull() & (F.col("__PERIOD_REGEX__") == "")
            )

            # Raise an exception if the extraction regex does not match for some records.
            if df_extraction_failure.count() != 0:
                df_extraction_failure.show(truncate=False, vertical=True)
                raise ValueError(
                    f"Use of regex '{regex}' did not match for some records in column '__PERIOD__'."
                )

            # Raise an exception if the __PERIOD_REGEX__ column contains duplicate values
            assertion, df_duplicates = columns_have_duplicates(self.df, ["__PERIOD_REGEX__"])
            if assertion:
                self.df.show(truncate=False, vertical=True)
                raise ValueError(
                    f"There are duplicated values for the concatenation of columns {columns} after regex extraction on '__PERIOD__'."
                )

            self.df = self.df.withColumn("__PERIOD__", F.col("__PERIOD_REGEX__"))

        # Change strange month names or other values, that are unrecognisable to english language date parser
        if mappings:
            self.df = self.df.withColumn("__PERIOD_MAPPING__", F.col("__PERIOD__"))
            for each in mappings:
                find = f"(.*)({each})(.*)"
                replace_with = f"$1{mappings[each]}$3"
                self.df = self.df.withColumn(
                    "__PERIOD_MAPPING__",
                    F.regexp_replace(F.col("__PERIOD_MAPPING__"), find, replace_with),
                )

            # Raise an exception if the __PERIOD_MAPPING__ column contains duplicate values
            assertion, df_duplicates = columns_have_duplicates(self.df, ["__PERIOD_MAPPING__"])
            if assertion:
                self.df.show(truncate=False, vertical=True)
                raise ValueError(
                    f"There are duplicated values for the concatenation of columns {columns} after mapping on '__PERIOD__'."
                )

            self.df = self.df.withColumn("__PERIOD__", F.col("__PERIOD_MAPPING__"))

        # Set PER_ALIGN
        period_align_formats = {
            "monthly": "'M'yyyyMM",
            "weekyday": "'W'yyyyMMdd",
            "4weekyday": "'W'yyyyMMdd",
        }

        if set_period_align:
            if self.periodicity in period_align_formats.keys():
                self.df = self.df.withColumn(
                    "PER_ALIGN",
                    F.date_format(
                        F.to_date("__PERIOD__", parser),
                        period_align_formats[self.periodicity],
                    ),
                )
            elif self.periodicity in ["weekynum", "4weekynum", "445weekynum"]:
                # No format is provided, it is expected to be valid
                self.df = self.df.withColumn("PER_ALIGN", F.col("__PERIOD__"))
            else:
                raise ValueError(f"Periodicity '{self.periodicity}' is not supported.")

            # Raise an exception if the PER_ALIGN column contains duplicate values
            assertion, df_duplicates = columns_have_duplicates(self.df, ["PER_ALIGN"])
            if assertion:
                self.df.show(truncate=False, vertical=True)
                raise ValueError(
                    "There are duplicated values in the 'PER_ALIGN' column after date formatting on '__PERIOD__'."
                )

        # Set DATETIME, RANK, YEAR
        if set_datetime:
            self.set_datetime_orchestration(
                parser=parser,
                rank_type=rank_type,
                audit_year_and_rank_columns=audit_year_and_rank_columns,
            )

        # Cleanup the intermediate columns
        self.df = self.df.drop("__PERIOD__", "__PERIOD_REGEX__", "__PERIOD_MAPPING__")

    def set_datetime_orchestration(
        self, parser: str, rank_type: str, audit_year_and_rank_columns: bool = True
    ):
        """Function to orchestrate the creation of the YEAR, RANK and DATETIME columns.

        Args:
            parser: String defining the date format of the input period value e.g. `"MMM yyyy"`.
            rank_type: String to be used if `set_datetime` is also `True`. Will default to `"default"`, otherwise use `"no53"`.
            audit_year_and_rank_columns: A boolean used to specify whether or not to audit the YEAR and RANK columns after population.

        Raises:
            ValueError: If the periodicity is not supported.
        """
        # If any of the columns we would like to add are already present, we rename them
        for column_to_rename in ["YEAR", "RANK", "DATETIME"]:
            self.df = self.df.withColumnRenamed(column_to_rename, f"LOCAL_{column_to_rename}")
        # We now continue to set the YEAR, RANK and DATETIME columns
        if self.periodicity == "monthly":
            self.df = self.df.withColumn("DATETIME", F.last_day(F.to_date("__PERIOD__", parser)))
            self.df = self.df.withColumn("YEAR", F.year("DATETIME"))
            self.df = self.df.withColumn("RANK", F.month("DATETIME"))
        elif self.periodicity == "weekyday":
            self.df = self.df.withColumn("DATETIME", F.to_date("__PERIOD__", parser))
            self.df = self.df.withColumn("YEAR", F.date_format("DATETIME", "yyyy"))
            self.df = self.df.withColumn("RANK", F.weekofyear("DATETIME"))
        elif self.periodicity == "4weekyday":
            self.df = self.df.withColumn("DATETIME", F.to_date("__PERIOD__", parser))
            self.df = self.df.withColumn("YEAR", F.date_format("DATETIME", "yyyy"))
            self.df = self.df.withColumn("RANK", F.ceil(F.weekofyear("DATETIME") / 4))
        elif self.periodicity in ["weekynum", "4weekynum", "445weekynum"]:
            self.set_datetime_weekynum(parser)
        elif self.periodicity == "yearly":
            self.set_datetime_yearly(parser)
        elif self.periodicity == "quarterly":
            self.set_datetime_quarterly(parser)
        else:
            raise Exception(f"Periodicity '{self.periodicity}' is not supported.")
        # now that the YEAR and RANK columns are populated, if specified we then remove the 53rd RANK
        if rank_type == "no53":
            self.remove_week_53_from_rank()
        if audit_year_and_rank_columns:
            self.audit_year_and_rank_columns()
        self.df = self.df.withColumn("YEAR", F.col("YEAR").cast(StringType()))
        self.df = self.df.withColumn("RANK", F.col("RANK").cast(StringType()))

    def set_datetime_quarterly(self, parser: str):
        """Function to orchestrate the creation of the YEAR, RANK and DATETIME columns in the case of a quarterly periodicity

        Args:
            parser: String defining the date format of the input period value. Use Q to indicate the quarter number in the tag
            and use `"yy"` or `"yyyy"` to indicate the year. e.g. `"Qyyyy"`.
        """
        # We have to differentiate the case where there is a "Q" in the parser because it is not treated the same way by spark
        if "Q" in parser:
            parser = parser.replace("'", "")
            # Get the index of the quarter information, and then the information itself from the PERIOD
            index_quarter = parser.index("Q") + 1
            self.df = self.df.withColumn(
                "RANK", F.substring("__PERIOD__", index_quarter, 1).cast(IntegerType())
            )
            # Check for different year format (2 or 4 digits) and get the index, then information itself again
            if re.match("^[^y]*y{4}[^y]*$", parser):
                year_start, year_length = (parser.index("yyyy") + 1, 4)
                self.df = self.df.withColumn(
                    "YEAR",
                    F.substring("__PERIOD__", year_start, year_length),
                )
            elif re.match("^[^y]*y{2}[^y]*$", parser):
                year_start, year_length = (parser.index("yy") + 1, 2)
                self.df = self.df.withColumn(
                    "YEAR",
                    F.concat_ws(
                        "",
                        F.lit("20"),
                        F.substring("__PERIOD__", year_start, year_length),
                    ),
                )
            self.df = self.df.withColumn(
                "DATETIME",
                F.last_day(
                    F.concat_ws("-", F.col("YEAR"), F.col("RANK") * 3, F.lit("01")).cast(DateType())
                ),
            )
        else:
            self.df = self.df.withColumn("DATETIME", F.to_date("__PERIOD__", parser))
            self.df = self.df.withColumn("YEAR", F.date_format("DATETIME", "yyyy"))
            self.df = self.df.withColumn("RANK", F.quarter("DATETIME"))

    def set_datetime_weekynum(self, parser: str = "*yyyyww"):
        """Populates period alignment columns for `"weekynum"` and `"4weekynum"` periodicity.

        Populate column `"YEAR"` with the year of the period in each row.
        Populate column `"RANK"` with the rank of each period within the year it is in.
        Populate column `"DATETIME"` with the date of the Sunday of the week number represented.

        Args:
            parser: A string specifying the form of the TAG. The letter 'y' being used to correspond to the year, and the letter 'w' being used to correspond to the week number.
                All of other letters will be ignored, and form only as placeholders. Recommend using '*' as a default placeholder. This conforms to the spark datetime parser,
                and a spark datetime parser string using 'w' for weeknumber will work with this function.
                e.g. "'W'yyyyww" for a TAG of the form "W202051" or similarly "*yy0ww" will work for a TAG of the form "W20051"

        Raises:
            ValueError: If the parser string does not contain either of "yyyy" or "yy"

        """
        parser = parser.replace("'", "")
        # Check for different lengths of specified year in the parser, and extract the indexes from the parser
        if re.match("^[^y]*y{4}[^y]*$", parser):
            year_start, year_length = (parser.index("yyyy") + 1, 4)
        elif re.match("^[^y]*y{2}[^y]*$", parser):
            year_start, year_length = (parser.index("yy") + 1, 2)
        else:
            raise ValueError(
                f"parser argument is invalid, '{parser}' does not specify where the YEAR is located in the TAG"
            )
        week_start = parser.index("ww") + 1

        self.df = self.df.withColumn("YEAR", F.substring("TAG", year_start, year_length))
        # If the year_length is 2, we need to make the string a full year, and prepend the 20 - (update when we reach the year 2100)
        if year_length == 2:
            self.df = self.df.withColumn("YEAR", F.concat(F.lit("20"), F.col("YEAR")))

        self.df = self.df.withColumn("RANK", F.substring("TAG", week_start, 2).cast(IntegerType()))

        # Now begins the calculation of the DATETIME column
        self.df = self.df.withColumn("__POST_FIRST_WEEK_DAYS__", (F.col("RANK") - 1) * 7)
        self.df = self.df.withColumn("__FIRST_DAY__", F.to_date("YEAR", "yyyy"))
        self.df = self.df.withColumn(
            "__LAST_DAY__", F.to_date(F.concat("YEAR", F.lit("1231")), "yyyymmdd")
        )
        self.df = self.df.withColumn("OFFSET", (8 - F.dayofweek("__FIRST_DAY__")) % 7)
        self.df = self.df.withColumn("__FIRST_WEEK__", F.expr("date_add(__FIRST_DAY__, OFFSET)"))
        # When it is not the last week of the year, and the first day of the year is Monday, Tuesday, Wednesday or Thursday (keep as normal)
        self.df = self.df.withColumn(
            "DATETIME",
            F.when(
                (F.col("TAG").substr(week_start, 2) != "52")
                & (F.dayofweek("__FIRST_DAY__").isin(2, 3, 4, 5)),
                F.expr("date_add(__FIRST_WEEK__, __POST_FIRST_WEEK_DAYS__)"),
            ).otherwise(F.lit(None)),
        )

        # When it is not the last week of the year, and the first day of the year is Friday, Saturday or Sunday (add 7 days)
        self.df = self.df.withColumn(
            "DATETIME",
            F.when(
                ~(F.col("TAG").substr(week_start, 2).isin("52", "53"))
                & (F.dayofweek("__FIRST_DAY__").isin(1, 6, 7)),
                F.date_sub(F.expr("date_add(__FIRST_WEEK__, __POST_FIRST_WEEK_DAYS__)"), -7),
            ).otherwise(F.col("DATETIME")),
        )

        # When it is the 52nd week of the year, and the last day of the year is Wednesday, Thursday or Friday (keep as normal)
        self.df = self.df.withColumn(
            "DATETIME",
            F.when(
                (F.col("TAG").substr(week_start, 2) == "52")
                & (F.dayofweek("__LAST_DAY__").isin(4, 5, 6, 7)),
                F.expr("date_add(__FIRST_WEEK__, __POST_FIRST_WEEK_DAYS__)"),
            ).otherwise(F.col("DATETIME")),
        )

        # When it is the 52nd week of the year, and the last day of the year is Sunday, Monday or Tuesday (add 7 days)
        self.df = self.df.withColumn(
            "DATETIME",
            F.when(
                (F.col("TAG").substr(week_start, 2) == "52")
                & (F.dayofweek("__LAST_DAY__").isin(1, 2, 3)),
                F.date_sub(F.expr("date_add(__FIRST_WEEK__, __POST_FIRST_WEEK_DAYS__)"), -7),
            ).otherwise(F.col("DATETIME")),
        )

        # now we do cleanup
        self.df = self.df.drop(
            "__POST_FIRST_WEEK_DAYS__",
            "__FIRST_DAY__",
            "__LAST_DAY__",
            "OFFSET",
            "__FIRST_WEEK__",
        )
        self.df = self.df.select(
            *[column for column in self.df.columns if column not in ["YEAR", "RANK", "DATETIME"]]
            + ["DATETIME", "YEAR", "RANK"]
        )
        if self.periodicity == "4weekynum":
            # for 4weekynum databases divide the RANK by 4
            self.df = self.df.withColumn("RANK", F.ceil(F.col("RANK") / 4).cast(IntegerType()))
        elif self.periodicity == "445weekynum":
            # for 445weekynum databases apply logic to get a rank within the year
            self.df = self.df.withColumn(
                "RANK",
                F.round((F.col("RANK") + 0 - (F.col("RANK") + 0 - 4) / 13) / 4).cast(IntegerType()),
            )
            # fix RANK of zero
            self.df = self.df.withColumn(
                "YEAR",
                F.when(F.col("RANK") == 0, F.col("YEAR") - 1)
                .otherwise(F.col("YEAR"))
                .cast(IntegerType()),
            )
            self.df = self.df.withColumn(
                "RANK", F.when(F.col("RANK") == 0, F.lit(12)).otherwise(F.col("RANK"))
            )

    def remove_week_53_from_rank(self):
        """Shifts the YEAR and RANK columns around in order to remove any RANK of 53.
        This conforms with a standard provided by Mars, which shifts week numbers back one in 2020
        in order to make up for the 53 weeks in 2020.

        Raises:
            ValueError: If the periodicity is not one of those supported (`"weekyday"`, `"weekynum"`, `"4weekyday"` and `"4weekynum"`)
        """
        # the below dictionary defines the ranks to change depending on the periodicity of the database
        periodicity_specifics = {
            "weekynum": {"last_rank": 52},
            "4weekynum": {"last_rank": 13},
            "weekyday": {"last_rank": 52},
            "4weekyday": {"last_rank": 13},
        }
        if self.periodicity not in periodicity_specifics.keys():
            raise ValueError(
                f"periodicity argument is invalid for remove_week_53_from_rank, '{self.periodicity}'. "
                f"Those periodicities currently supported for this function are {str(list(periodicity_specifics.keys()))}."
            )
        self.df = self.df.withColumn("__YEAR__", F.col("YEAR").cast(IntegerType()))
        self.df = self.df.withColumn("__RANK__", F.col("RANK"))
        self.df = self.df.withColumn(
            "__RANK__",
            F.when(
                F.col("__RANK__") == periodicity_specifics[self.periodicity]["last_rank"] + 1,
                F.lit(periodicity_specifics[self.periodicity]["last_rank"]),
            ).otherwise(F.col("__RANK__")),
        )
        period_window = Window.partitionBy().orderBy("DATETIME")
        if self.periodicity in ["weekynum", "weekyday"]:
            self.df = self.df.withColumn(
                "RANK", F.lag("__RANK__", 1).over(period_window)
            ).withColumn(
                "RANK",
                F.when(F.col("__YEAR__") >= 2021, F.col("__RANK__")).otherwise(F.col("RANK")),
            )
            self.df = self.df.withColumn(
                "YEAR", F.lag("__YEAR__", 1).over(period_window)
            ).withColumn(
                "YEAR",
                F.when(F.col("__YEAR__") >= 2021, F.col("__YEAR__")).otherwise(F.col("YEAR")),
            )
        elif self.periodicity in ["4weekynum", "4weekyday"]:
            self.df = self.df.withColumn(
                "RANK", F.lag("__RANK__", 1).over(period_window)
            ).withColumn(
                "RANK",
                F.when(
                    (F.col("__YEAR__") >= 2021) & (F.col("__RANK__") != 13),
                    F.col("__RANK__"),
                ).otherwise(F.col("RANK")),
            )
            self.df = self.df.withColumn(
                "YEAR", F.lag("__YEAR__", 1).over(period_window)
            ).withColumn(
                "YEAR",
                F.when(
                    (F.col("__YEAR__") >= 2021) & (F.col("__RANK__") != 13),
                    F.col("__YEAR__"),
                ).otherwise(F.col("YEAR")),
            )
        # now we just need to fix the first period that is missed by the lag function
        second_record = self.df.select("RANK", "YEAR").orderBy("DATETIME").limit(2).collect()
        rank_to_insert_null = [row["RANK"] for row in second_record][1]
        year_to_insert_null = [row["YEAR"] for row in second_record][1]
        year_to_insert_null = (
            year_to_insert_null if rank_to_insert_null != 1 else year_to_insert_null - 1
        )
        rank_to_insert_null = (
            rank_to_insert_null - 1
            if rank_to_insert_null != 1
            else periodicity_specifics[self.periodicity]["last_rank"]
        )
        self.df = self.df.withColumn(
            "RANK",
            F.when(F.col("RANK").isNull(), F.lit(rank_to_insert_null)).otherwise(F.col("RANK")),
        )
        self.df = self.df.withColumn(
            "YEAR",
            F.when(F.col("YEAR").isNull(), F.lit(year_to_insert_null)).otherwise(F.col("YEAR")),
        )
        self.df = self.df.drop("__YEAR__", "__RANK__")

    def set_datetime_yearly(self, parser):
        """Function to populate the YEAR, RANK and DATETIME columns for a yearly database.
        This will also create new "dummy" rows for each YEAR to avoid errors in SPRINT.

        Args:
            parser: String defining the date format of the input period value e.g. `"MMM yyyy"`.
        """
        # populate the YEAR, RANK and DATETIME columns for the initial period rows
        self.df = self.df.withColumn("DATETIME", F.to_date("__PERIOD__", parser))
        self.df = self.df.withColumn("YEAR", F.date_format("DATETIME", "yyyy"))
        self.df = self.df.withColumn("RANK", F.lit(None))

        # get all the years data from the period dimension
        years = self.df.select("TAG", "YEAR", "RANK", "DATETIME").collect()
        # initialise a list of values to which we will add values for each year
        all_values = []
        # create our schema
        period_schema = StructType(
            [StructField(column_name, StringType(), True) for column_name in self.df.columns]
        )
        for row in years:
            year = row["YEAR"]
            values = {
                "TAG": f"DUMMY{year}",
                "SHORT": f"Y{year}",
                "LONG": f"Y{year}",
                "YEAR": year,
                "RANK": "1",
                "DATETIME": f"{year}-12-31",
            }
            values = tuple(values.get(value, None) for value in self.df.columns)
            all_values.append(values)
        new_rows = spark.createDataFrame(all_values, period_schema)
        self.df = self.df.union(new_rows).withColumn("DATETIME", F.col("DATETIME").cast(DateType()))

    def audit_years_available(self, ranks_per_year: int, expected_years: int):
        """Checks if the number of whole years available of a period dimension matches that of the number expected.
        This assumes that the ranks_per_year provided is correct.

        Args:
            ranks_per_year: An integer of the number of ranks per whole year.
                e.g. 12 for a monthly database
            expectected_years: An integer of the whole number of years expected in the dimension
                e.g. 2

        Raises:
            ValueError: If the number of years available does not match the number expected.
        """
        # we get the whole number of years using the RANK and ranks_per_year
        whole_number_of_years = int(
            self.df.where(F.col("RANK").isNotNull()).count() / ranks_per_year
        )
        # raise an error if the expected number of whole years does not match the number found
        if whole_number_of_years != expected_years:
            raise ValueError(
                "The number of whole years available in the period dimensions does not match that in the SPRINT config.\n"
                "Please check the SPRINT config, as well as the Period dimension of this database.\n"
                f"Number of years in period dimension : {whole_number_of_years}\n"
                f"Number of years according to SPRINT config : {expected_years}"
            )

    def audit_periodicity(self, expected_periodicity: str, full_years: int):
        """Checks if the periodicity of a period dimension matches that of an expected one.
        This assumes that the full_years provided is correct and that the RANK column is correctly populated.

        Args:
            expectected_periodicity: A string of the expected periodicity of the dimension. One of:
                "Monthly", "4-4-5 weeks", "Four-weekly", "Weekly", "Quarterly", "Bimonthly", "Yearly"
            full_years: An integer of the whole number of years available in the dimension.

        Raises:
            ValueError: If the periodicity found does not match the expected_periodicity.
        """
        if expected_periodicity == "Yearly":
            periodicity = self.df.where(F.col("RANK").isNotNull()).count()
            # raise an error if the number of years does not match the expected number of years
            if periodicity != full_years:
                raise ValueError(
                    "The periodicity in the period dimension does not match that in the SPRINT config.\n"
                    f"We found {periodicity} years available in the period dimension, which does not match the expected full_years available {full_years}.\n"
                    f"Please check the SPRINT config matches the number of years in the Period dimension."
                )
        else:
            # use the maximum in the Rank column to indicate the periodicity
            max_rank = int(
                [
                    x.RANK
                    for x in self.df.select("RANK")
                    .orderBy(F.col("RANK").cast(IntegerType()).desc())
                    .limit(1)
                    .collect()
                ][0]
            )
            # get the max_rank of the expected_periodicity
            expected_periodicity = {
                "Monthly": [12],
                "4-4-5 weeks": [12],
                "Four-weekly": [13, 14],
                "Weekly": [52, 53],
                "Quarterly": [4],
                "Bimonthly": [6],
            }[expected_periodicity]
            # raise an error if the expected periodicity does not match the periodicity found
            if max_rank not in expected_periodicity:
                raise ValueError(
                    "The periodicity in the period dimension does not match that in the SPRINT config."
                    f"The maximum rank found in the period dimension was {max_rank}.\n"
                    f"This does not fit with our expected periodicity from SPRINT config of {expected_periodicity}."
                )

    def audit_year_and_rank_columns(self):
        """Checks if the `YEAR` and `RANK` columns are sequential in the period dimension

        Raises:
            ValueError: If there are duplicate combinations of `YEAR` and `RANK` columns.
            ValueError: If `YEAR` and `RANK` columns are not sequential.
        """
        # remove those rows where the YEAR and RANK columns are null, for example for pre-aggregated periods
        spec_df = self.df.where((F.col("YEAR").isNotNull()) & (F.col("RANK").isNotNull()))
        # Raise an error if there are duplicate combinations of YEAR and RANK columns
        if spec_df.count() > spec_df.dropDuplicates(subset=["YEAR", "RANK"]).count():
            raise ValueError("There are duplicate combinations of YEAR and RANK columns.")

        # Create a windows spec order by Year column
        spec = Window.orderBy("YEAR", "RANK")

        # Create two columns named RANK_LAGGED and YEAR_LAGGED
        spec_df = spec_df.withColumn("RANK_LAGGED", self.df.RANK - F.lag("RANK").over(spec))
        spec_df = spec_df.withColumn("YEAR_LAGGED", self.df.YEAR - F.lag("YEAR").over(spec))

        # Remove the first row of the dataframe. The first row is supposed to be the one with null value on RANK_LAGGED and YEAR_LAGGED columns
        spec_df = spec_df.where(F.col("RANK_LAGGED").isNotNull())

        # Get the max value of RANK_LAGGED column
        max_rank = spec_df.agg(F.max(F.abs(spec_df.RANK_LAGGED))).first()[0]

        # Create a new dataframe by filtering where RANK_LAGGED is different to both max_rank and 1 or where YEAR_LAGGED is different to both 0 and 1
        spec_df = spec_df.filter(
            ((F.abs(spec_df.RANK_LAGGED) != max_rank) & (spec_df.RANK_LAGGED != 1))
            | ((F.abs(spec_df.YEAR_LAGGED) != 0) & (spec_df.YEAR_LAGGED != 1))
        )

        # Count the number of rows of the result dataframe and raise en error if it is not empty
        if spec_df.count() > 0:
            raise ValueError(
                f"One of the YEAR and RANK columns are not sequential.\n{spec_df.show(20, False)}"
            )

    def audit_pre_aggregated_periods(self, pre_aggregated_periods: List[str], full_years: int):
        """Checks that pre-aggregated period records exist for each year available and
        for each pre-aggregated calculation. Also check that the pre-aggregated periods are
        correctly callibrated according to the latest year.

        Args:
            pre_aggregated_periods: A list of strings of the pre-aggregated periods the database should have.
                e.g. ["YTD", "MAT", "L1M", "L3M"]
            full_years: An integer of the whole number of years available in the dimension.

        Raises:
            ValueError: If the number of records for a pre-aggregated period is incorrect.
            ValueError: If a pre-aggregated period is missing for one of the whole years available.
        """
        for pre_aggregated_period in pre_aggregated_periods:
            rows_with_aggregate = self.df.where(
                F.col("TAG").startswith(pre_aggregated_period)
            ).count()
            if rows_with_aggregate != full_years:
                raise ValueError(
                    f"There are missing pre-aggregated periods in the period dimension.\n"
                    f"The number of rows starting with {pre_aggregated_period} is : {rows_with_aggregate}\n"
                    f"Whereas the expected number was {full_years}."
                )
            whole_years = [
                x.YEAR
                for x in self.df.select("YEAR")
                .distinct()
                .orderBy(self.df.YEAR.desc())
                .limit(full_years)
                .collect()
            ]
            if (
                self.df.where(
                    (F.col("YEAR").isin(whole_years))
                    & (F.col("TAG").startswith(pre_aggregated_period))
                ).count()
                != full_years
            ):
                raise ValueError(
                    f"The pre-aggregated period '{pre_aggregated_period}' is missing for one of the whole years available."
                    "Please check the YEAR column of the Period dimension is correctly populated for the pre-aggregated periods."
                )

    def add_year_and_rank_after_period_translation(
        self, parser: str = r"P(\d{4})(\d{2})", year_group: int = 1, rank_group: int = 2
    ):
        r"""Function to populate YEAR and RANK columns following the translate periods.
        Rows for pre-aggregated periods are populated wit null.

        Args:
            parser: A regular expression pattern specifying where the year and rank are in the TAG.
                e.g. "`P(\d{4})(\d{2})`" or "`PERIOD(\d{4})0(\d{2})`"
            year_group: The group number in the parser that is represented by the YEAR. Default is 1.
            rank_group: The group number in the parser that is represented by the RANK. Default is 2.
        """
        # Get the YEAR from the TAG using the regex from the parser
        # we need the year_group in case the YEAR comes after the RANK in the TAG
        self.df = self.df.withColumn("YEAR", F.regexp_extract(F.col("TAG"), parser, year_group))
        # when the YEAR is just two digits we left fill with '20'
        self.df = self.df.withColumn(
            "YEAR",
            F.when(F.length(F.col("YEAR")) == 2, F.concat(F.lit("20"), F.col("YEAR"))).otherwise(
                F.col("YEAR")
            ),
        )
        # for pre-aggregated periods we need to set the YEAR to null (regexp_extract returns empty string when there is no match)
        self.df = self.df.withColumn(
            "YEAR", F.when(F.col("YEAR") == "", F.lit(None)).otherwise(F.col("YEAR"))
        )
        # Get the RANK from the TAG using the regex from the parser
        # we need the rank_group in case the RANK comes before the YEAR in the TAG
        self.df = self.df.withColumn(
            "RANK",
            F.regexp_extract(F.col("TAG"), parser, rank_group).cast(IntegerType()),
        )

        self.audit_year_and_rank_columns()

    def populate_ytd(self):
        """Function to populate a new column "YTD" that will label the Year to Date for this period dimension.
        This relies on the `YEAR` and `RANK` columns being populated.
        """
        ending_year = int(
            self.df.withColumn("YEAR", F.col("YEAR").cast(IntegerType()))
            .agg({"YEAR": "max"})
            .first()[0]
        )
        ending_rank = int(
            self.df.where(F.col("YEAR") == ending_year)
            .withColumn("RANK", F.col("RANK").cast(IntegerType()))
            .agg({"RANK": "max"})
            .first()[0]
        )
        self.df = self.df.withColumn(
            "YTD",
            F.when(
                F.col("RANK") <= ending_rank,
                F.concat(
                    F.lit("YTDY"),
                    F.lit(ending_year - F.col("YEAR") + 1).cast(IntegerType()),
                ),
            ).otherwise(F.lit(None)),
        )

    def populate_mat(self) -> int:
        """Function to populate a new column "MAT" that will label the Moving Annual Total for this period dimension.
        This relies on the `YEAR` and `RANK` columns being populated.

        Returns:
            number_of_whole_years: An integer of the whole number of years in the database or 1 if there is less than 1 whole year.
        """
        # get the maximum value of the "RANK" column
        max_rank = int(
            self.df.withColumn("RANK", F.col("RANK").cast(IntegerType()))
            .agg({"RANK": "max"})
            .first()[0]
        )
        self.df = self.df.withColumn("MAT", F.lit(None))
        # rank the records and get as a multiple of rows per year
        windowSpec = Window.orderBy(F.col("TAG").asc())
        self.df = self.df.withColumn("__RANK__", F.rank().over(windowSpec))
        # get the maximum ranking to create our moving cycle
        max_ranking = self.df.agg({"__RANK__": "max"}).first()[0]
        # get the whole number of years in the database
        number_of_whole_years = max(floor(max_ranking / max_rank), 1)
        # for each moving year populate the MAT column
        for year in range(number_of_whole_years):
            self.df = self.df.withColumn(
                "MAT",
                F.when(
                    (max_ranking >= F.col("__RANK__"))
                    & (F.col("__RANK__") > max_ranking - max_rank),
                    F.lit(f"MATY{year + 1}"),
                ).otherwise(F.col("MAT")),
            )
            # subtract one to move to the next year
            max_ranking -= max_rank
        self.df = self.df.drop("__RANK__")
        return number_of_whole_years
