from __future__ import annotations

import re
from functools import reduce
from typing import List, Optional

import pyspark.sql.functions as F
from pyspark.sql.dataframe import DataFrame
from pyspark.sql.types import StringType
from rdslibrary.core.dimensions.Meta import Meta
from rdslibrary.utilities.spark import get_dbutils, get_spark
from rdslibrary.utilities.testing import column_names_are_duplicated_modulo_index

spark = get_spark()
dbutils = get_dbutils(spark)


class Product(Meta):
    """
    Class describing the product dimension of Redslim standard format.
    """

    def __init__(self, df: Optional[DataFrame] = None):
        """Class constructor.

        Args:
            df: Dataframe reprensenting the dimension.
        """
        std = [
            "TAG",
            "SHORT",
            "LONG",
            "DISPLAY_ORDER",
            "PARENT_TAG",
            "HIER_NUM",
            "HIER_NAME",
            "HIER_LEVEL_NUM",
            "HIER_LEVEL_NAME",
        ]
        super().__init__(df=df, standard_columns=std)

    def rename_duplicated_columns_associated_with_hierarchies(
        self,
        hierarchy_names: List[str],
        floating_columns: Optional[List[str]] = [],
        prefix: Optional[str] = "LOCAL_",
    ):
        """Renames hierarchy associated columns to avoid duplicated names.

        Pyspark automatically prefixes on read duplicated column names (case-unsensitive) with column index. The function
        provides a way of adding a prefix in front of local hierarchy characteristics to avoid conflicts with enrichment
        characteristics. It also takes care of removing pyspark indexes.

        Args:
            hierarchy_names: Hierarchies to rename characteristics for.
            floating_columns: Columns associated to a hierarchy but not corresponding to a level.
            prefix: Prefix to add in front of column names both in the header and the values of the dataframe.

        Raises:
            ValueError: If duplicated columns modulo index are detected after renaming.
        """

        # Get columns to rename from the dataframe.
        # Columns to rename are defined by the set of hierarchy level names of the passed hierarchy names united with the set of passed floating columns
        df_reduction = (
            self.df.where(F.col("HIER_NAME").isNotNull())
            .groupby("HIER_NAME")
            .agg(F.collect_set("HIER_LEVEL_NAME").alias("HIER_LEVEL_NAME"))
        )
        hierarchy_levels = {
            r["HIER_NAME"]: r["HIER_LEVEL_NAME"]
            for r in df_reduction.collect()
            if r["HIER_NAME"] in hierarchy_names
        }
        columns_to_rename = list(
            reduce(lambda acc, x: acc.union(set(x)), hierarchy_levels.values(), set())
        )
        columns_to_rename = list(set(columns_to_rename).union(set(floating_columns)))

        # Rename hierarchy columns
        selection_expression = []
        for index, column in enumerate(self.df.columns):
            # The uppercase transformation is required take into account
            # the lack of case sensitivity of pyspark.
            column_corrected = re.sub(f"{index}$", "", column)
            column_upper = column.upper()
            column_upper_corrected = re.sub(f"{index}$", "", column_upper)
            if column_corrected in columns_to_rename:
                column_expression = F.col(column).alias(prefix + column_corrected)
            elif column_upper_corrected in columns_to_rename:
                # Correct the index postfix created by pyspark
                column_expression = F.col(column).alias(column_corrected)
            else:
                column_expression = F.col(column)
            selection_expression.append(column_expression)

        self.df = self.df.select(selection_expression)

        # Rename hierarchy level names
        # Floating columns are not impacted
        self.df = self.df.withColumn(
            "HIER_LEVEL_NAME",
            F.when(
                F.col("HIER_NAME").isin(hierarchy_names),
                F.concat(F.lit(prefix), F.col("HIER_LEVEL_NAME")),
            ).otherwise(F.col("HIER_LEVEL_NAME")),
        )

        # Rename hierarchy chains
        # Floating columns are not impacted
        concatenate_prefix_udf = F.udf(
            lambda x: "!".join([prefix + c for c in x]) if x is not None else None,
            StringType(),
        )
        for hierarchy_name in hierarchy_names:
            self.df = self.df.withColumn(
                hierarchy_name,
                concatenate_prefix_udf(F.split(hierarchy_name, "!")),
            )

        # Check that no duplicates have been found
        assertion, column_duplicates = column_names_are_duplicated_modulo_index(self.df)
        if assertion:
            raise ValueError(
                f"Duplicated columns have been found following renaming {column_duplicates}."
            )
