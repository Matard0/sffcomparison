import os
from typing import List, Optional

import pyspark.sql.functions as F
import pyspark.sql.types as T
from pyspark.sql.dataframe import DataFrame
from pyspark.sql.types import StringType, StructField, StructType
from pyspark.sql.utils import AnalysisException
from rdslibrary.core.schema import Schema
from rdslibrary.utilities.functions import read_json
from rdslibrary.utilities.spark import get_dbutils, get_spark

spark = get_spark()
dbutils = get_dbutils(spark)


def read_period_mapping(period_mapping_file: str, iso_code: str) -> DataFrame:
    """Create and return a dataframe based ont the period mapping file and the iso code.

    Args:
        period_mapping_file: The path of the period mapping file in csv format.
        e.g. `"dbfs:/mnt/lab_mount/teld/data/periodmapping_test.csv"`

        iso_code: A string for filtering data in the period mapping file. e.g. `"DE"`, `"PL"`

    Raises:
            ValueError: If there are no data available for this iso code

    Returns:
        period_mapping_df: A spark dataframe that contains the transformed data
    """

    # Schema for specifying the names and the types of the dataframe fileds
    schema = T.StructType(
        [
            T.StructField("mapping_input", T.StringType(), False),
            T.StructField("mapping_output", T.StringType(), False),
        ]
    )

    # Create a spark dataframe based on the csv file path
    period_mapping_df = spark.read.csv(period_mapping_file, header=False, schema=schema)

    # Filter the dataframe to get only lines that begin with iso_code on the mapping_input column
    period_mapping_df = period_mapping_df.filter(
        period_mapping_df.mapping_input.startswith(iso_code + "_")
    )

    if period_mapping_df.count() == 0:
        raise ValueError("There are no data available for this iso code")

    # Create a column that contains an array of the values of mapping_output column by splitting by | character
    period_mapping_df = period_mapping_df.withColumn(
        "split_mapping_output", F.split(period_mapping_df["mapping_output"], r"\|")
    )

    # Remove iso code + '_' in the begining of mapping_input column
    period_mapping_df = period_mapping_df.withColumn(
        "mapping_input", F.split(period_mapping_df["mapping_input"], "_").getItem(1)
    )

    # We create a new line with each item in the list in split_mapping_output column
    period_mapping_df = period_mapping_df.select(
        "mapping_input",
        "mapping_output",
        "split_mapping_output",
        F.explode("split_mapping_output").alias("explode_mapping_output"),
    )

    # Create the _PERIOD_TAG column
    period_mapping_df = period_mapping_df.withColumn(
        "_PERIOD_TAG_",
        F.when(
            period_mapping_df["explode_mapping_output"].contains("*"),
            F.split(period_mapping_df["explode_mapping_output"], r"\*").getItem(1),
        ).otherwise(period_mapping_df["explode_mapping_output"]),
    )

    # Create the _FACTOR_ column
    period_mapping_df = period_mapping_df.withColumn(
        "_FACTOR_",
        F.when(
            period_mapping_df["explode_mapping_output"].contains("*"),
            F.split(period_mapping_df["explode_mapping_output"], r"\*").getItem(0),
        ).otherwise("1/1"),
    )

    # Rename mapping_input column to _TAG_
    period_mapping_df = period_mapping_df.withColumnRenamed("mapping_input", "_TAG_")

    # Calculate de the value of the fraction in _FACTOR_ column
    period_mapping_df = period_mapping_df.withColumn(
        "_FACTOR_",
        F.split(period_mapping_df["_FACTOR_"], r"\/").getItem(0)
        / F.split(period_mapping_df["_FACTOR_"], r"\/").getItem(1),
    )

    # Select only the expected columns
    period_mapping_df = period_mapping_df.select("_TAG_", "_PERIOD_TAG_", "_FACTOR_")

    return period_mapping_df


def aggregated_periods_qc(
    sch,
    fact_driver: str,
    parser: Optional[str] = r"P(\d{4})(\d{2})",
    mat_labels: Optional[List[str]] = ["MATY1", "MATY2", "MATY3"],
    ytd_labels: Optional[List[str]] = ["YTDY1", "YTDY2", "YTDY3"],
):
    """QC the pre-aggregated period mapping of the Consolidation Preparation

    Args:
        sch: A rdslibrary schema object of the prepared SFF.
        parser: A regular expression to identify the non pre-aggregated periods in the period dimension.
        mat_labels: An ordered list of the labels used for the MAT in the period mapping.
        ytd_labels: An ordered list of the labels used for the YTD in the period mapping.

    Raises:
        Exception: When the MAT aggregate values for the fact driver do not match what is expected.
        Exception: When the YTD aggregate values for the fact driver do not match what is expected.
    """
    # filter out the pre-aggregated periods from our comparison
    data_df = (
        sch.data.df.where(F.col("PERIOD_TAG").rlike(parser))
        .groupBy("PERIOD_TAG")
        .agg(F.sum(fact_driver).alias(fact_driver))
    )
    period_df = sch.period.df.where(F.col("TAG").rlike(parser))
    fact_df = sch.fact.df.where(F.col("TAG") == fact_driver)
    comparison = Schema(data=data_df, period=period_df, fact=fact_df)
    # get the whole number of years and populate the MAT and YTD columns of th period dimension
    number_of_whole_years = comparison.period.populate_mat()
    comparison.period.populate_ytd()
    # add new rows to the period dimension for each MAT and YTD
    new_values = []
    for mat in range(number_of_whole_years):
        comparison.period.df = comparison.period.df.withColumn(
            "MAT",
            F.when(F.col("MAT") == f"MATY{mat + 1}", mat_labels[mat]).otherwise(F.col("MAT")),
        )
        values = {"TAG": mat_labels[mat]}
        new_values.append(
            tuple(
                values.get(characteristic, None) for characteristic in comparison.period.df.columns
            )
        )
    for iteration, ytd in enumerate(
        comparison.period.df.where(F.col("YTD").isNotNull())
        .select("YTD", "YEAR")
        .distinct()
        .orderBy(F.col("YEAR").desc(), F.col("YTD").desc())
        .collect()
    ):
        comparison.period.df = comparison.period.df.withColumn(
            "YTD",
            F.when(F.col("YTD") == f"YTDY{iteration + 1}", ytd_labels[iteration]).otherwise(
                F.col("YTD")
            ),
        )
        values = {"TAG": ytd_labels[iteration], "YEAR": ytd["YEAR"]}
        new_values.append(
            tuple(
                values.get(characteristic, None) for characteristic in comparison.period.df.columns
            )
        )
    period_schema = StructType(
        [
            StructField(column_name, StringType(), True)
            for column_name in comparison.period.df.columns
        ]
    )
    new_rows = spark.createDataFrame(new_values, period_schema)
    comparison.period.df = comparison.period.df.union(new_rows)

    # join our data and period dimensions to get the MAT and YTD columns on the data
    comparison.data.df = comparison.data.df.join(
        comparison.period.df,
        comparison.data.df["PERIOD_TAG"] == comparison.period.df["TAG"],
        "left",
    )
    # check that the MAT totals are correct
    expected = (
        comparison.data.df.where(F.col("MAT").isNotNull())
        .groupBy("MAT")
        .agg(F.round(F.sum(fact_driver), 6).alias(fact_driver))
        .withColumnRenamed("MAT", "PERIOD_TAG")
    )
    actual = (
        sch.data.df.where(F.col("PERIOD_TAG").like("%MAT%"))
        .groupBy("PERIOD_TAG")
        .agg(F.round(F.sum(fact_driver), 6).alias(fact_driver))
    )
    if actual.orderBy("PERIOD_TAG").collect() != expected.orderBy("PERIOD_TAG").collect():
        raise Exception(
            "There is an error with the MAT population in the SFF, the values do not match expected logic."
        )
    # check that the YTD totals are correct
    expected = (
        comparison.data.df.where(F.col("YTD").isNotNull())
        .groupBy("YTD")
        .agg(F.round(F.sum(fact_driver), 6).alias(fact_driver))
        .withColumnRenamed("YTD", "PERIOD_TAG")
    )
    actual = (
        sch.data.df.where(F.col("PERIOD_TAG").like("%YTD%"))
        .groupBy("PERIOD_TAG")
        .agg(F.round(F.sum(fact_driver), 6).alias(fact_driver))
    )
    if actual.orderBy("PERIOD_TAG").collect() != expected.orderBy("PERIOD_TAG").collect():
        raise Exception(
            "There is an error with the YTD population in the SFF, the values do not match expected logic."
        )


def check_preparations_latest_periods(
    build_inputs: list, configuration_databases: list, check: Optional[bool] = False
):
    """Checks if the latest period files are written and if it is the same for all databases.
    Args:
        build_inputs: List of the build inputs paths informations.
            e.g. `[FileInfo(path="path/input/db1", name="RDSM_DATABASE")]`
        configuration_databases: List of the databases used as contributions from the configuration files.
        check: Optionnal boolean to check if the latest period are equal.

    Raises:
        Exception: When the build input database and configuration database are different.
        Exception: When there is a missing status.json file in one of the databases used for build.
        Exception: When the latest period for the different databases are not equal if check is set to True.
    """
    build_databases = [file_info.name.replace("/", "") for file_info in build_inputs]
    # verifies if the build inputs are missing or if they don't match the configuration databases
    if not set(configuration_databases) == set(build_databases):
        a = sorted(set(build_databases).difference(set(configuration_databases)))
        b = sorted(set(configuration_databases).difference(set(build_databases)))
        raise Exception(
            "The databases in the build input and in the configuration databases are different"
            + (len(a) > 0)
            * f"\n The build database(s) {a} did not match one of the configuration databases"
            + (len(b) > 0)
            * f"\n The configuration database(s) {b} did not match one of the build databases"
        )

    # defines from the build inputs, the list of status.json paths and the database they belong
    latest_periods = []
    missing_status = []
    for file_info in build_inputs:
        try:
            status = read_json(os.path.join(file_info.path, "status.json"))
            latest_periods.append((file_info.name.replace("/", ""), status["latest_period"]))
            if status["latest_period"] is None:
                missing_status.append(file_info.name.replace("/", ""))
        except AnalysisException:
            missing_status.append(file_info.name.replace("/", ""))

    # defines a list of databases with missing status.json file
    if len(missing_status) > 0:
        raise Exception(f"The status.json file is missing for the database(s) : {missing_status}")

    # gets a list of each database and its latest periods
    if check:
        if not len({x[1] for x in latest_periods}) == 1:
            raise Exception(
                f"The latest periods in the build inputs are different \n {latest_periods}"
            )
    return latest_periods[0][1]
