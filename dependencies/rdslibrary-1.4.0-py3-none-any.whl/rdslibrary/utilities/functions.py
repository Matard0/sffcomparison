import fnmatch
import json
import os
import re
from typing import List, Union

import pyspark.sql.functions as F
import requests
from pyspark.sql.column import Column
from rdslibrary.utilities.spark import get_dbutils, get_spark

spark = get_spark()
dbutils = get_dbutils(spark)


def get_paths(directory: str, pattern: str) -> list:
    """Lists files or directories from datalake matching wildcard pattern.

    Args:
        directory: Path of the directory where to look for files.
        pattern: Wildcard or list of wildcards for files / directories.
    Returns:
        paths: List of files or directories matching the wildcard pattern in the directory.
    """
    if isinstance(pattern, str):
        pattern = [pattern]

    file_infos = dbutils.fs.ls(directory)

    paths = []

    for p in pattern:
        paths += [info.path for info in file_infos if fnmatch.fnmatch(info.name, p)]
    paths = list(set(paths))

    return paths


def create_condition(column: str, rule: str, parameter: Union[str, list]) -> Column:
    """Creates a column filtering condition based on a rule name and parameter.

    Args:
        column: Column name to create a condition for.
        rule: Name of the filtering rule. Must be of the following: `"is_equal_to"`, `"is_not_equal_to"`,
            `"is_in"`, `"is_not_in"`, `"is_match_of"`, `"is_not_match_of"`, `"does_contain"`,  `"does_not_contain"`.
        parameter: Parameter to apply the rule on.

    Raises:
        ValueError: if the rule is not one of the available rules.

    """
    col = F.col(column)
    condition = None
    if rule == "is_equal_to":
        condition = col == parameter
    elif rule == "is_not_equal_to":
        condition = col != parameter
    elif rule == "is_in":
        condition = col.isin(parameter)
    elif rule == "is_not_in":
        condition = col.isin(parameter) is False
    elif rule == "is_match_of":
        condition = col.rlike(parameter)
    elif rule == "is_not_match_of":
        condition = ~col.rlike(parameter)
    elif rule == "does_contain":
        condition = col.contains(parameter)
    elif rule == "does_not_contain":
        condition = col.contains(parameter) is False
    else:
        raise ValueError(f"Rule '{rule}' is not valid.")
    return condition


def group_dictionaries(dicts: List[dict], key: str) -> dict:
    """Nests a list of dictionaries by key.

    Args:
        dicts: List of dictionaries.
        key: Dictionary key to nest on.

    Example:
        Let's consider the following input list::

            [
                {"key": "a", "other": "a1"},
                {"key": "b", "other": "b1"},
                {"key": "a", "other": "a2"}
            ]

        Using `key="key"`, the function will return::

            {
                "a": [{"other": "a1"}, {"other": "a2"}],
                "b": [{"other": "b1"}]
            }

    """
    acc = {}
    nest = [{d.pop(key): [d]} for d in dicts]
    for d in nest:
        name, params = next(iter(d.items()))
        acc[name] = acc.get(name, []) + params
    return acc


def format_column_parquet(column: str) -> str:
    r"""Format a column to ensure a string with the following attributes:
        - uppercase
        - whithout trailing / leading white spaces
        - multiple white spaces replaces by single
        - substitution of (.) by "_" (pyspark requirement)
        - substitution of (\s|,|;|{|}|\(|\)|\\n|\\t|=) by "_" (parquet requirement)

    Args:
        column (str): column to format

    Returns:
        column (str): formatted column
    """
    column = re.sub(
        r"(\s|,|;|{|}|\(|\)|\n|\t|=)", "_", column
    )  # Remove forbidden characters for parquet

    return column


def refresh_sprint_cache(database_name: str, prepare_cache: bool = True):
    """Issues requests to the SPRINT website API to delete the cache for the database provided.
       Also, will optionally issue the prepare cache command. This behaviour is default.

    Args:
        database_name: String of the database name e.g. LPCHOCOLATE
        prepare_cache: Boolean specifying whether or not to prepare the SPRINT cache e.g. True
    """
    sprint_cache_login_password = dbutils.secrets.get("testscope", "sprintcacheloginpassword")
    with requests.Session() as s:
        s.post(
            url="https://sprint.redslim.net/Account/SprintLoginConfirm?",
            data={
                "Email": "autoloader@redslim.net",
                "Password": sprint_cache_login_password,
            },
        )
        s.get(
            url=f"https://sprint.redslim.net/Admin/DeleteCacheForDatabaseAjax?name={database_name}"
        )
        if prepare_cache:
            s.get(
                url=f"https://sprint.redslim.net/Admin/PrepareCacheForDatabaseAjax?name={database_name}"
            )


def read_json(path: str) -> dict:
    """Reads json file from datalake to dictionary.

    Args:
        path: Path to the json file to use.

    Returns:
        dictionary: Dictionary equivalent to the json.
    """
    # Format path
    path = path if path[0] != "/" else path[1:]
    path = path if path.startswith("dbfs:/mnt") else os.path.join("dbfs:/mnt", path)

    rows = spark.read.text(path).collect()
    j = ""
    for row in rows:
        j += row.value.strip()

    configuration = json.loads(j)

    return configuration


def get_longest_substring(data: List[str]) -> str:
    """Returns longest substring from a list of strings.

    Args:
        data: List of strings to find longest substring for.

    Returns:
        Longest substring from list.
    """
    substring = ""
    if len(data) > 1 and len(data[0]) > 0:
        for i in range(len(data[0])):
            for j in range(len(data[0]) - i + 1):
                index = i + j
                value = is_substring(data[0][i:index], data)
                if j > len(substring) and value:
                    substring = data[0][i:index]
    return substring


def is_substring(substring: str, data: List[str]) -> bool:
    """Returns if a substring is a substring of all items in list.

    Args:
        substring: Substring to search for.
        data: List of strings to search substring for.

    Returns:
        Boolean specifying if the substring is a substring of all items in the list.
    """
    if len(data) < 1 and len(substring) < 1:
        return False
    for i in range(len(data)):
        if substring not in data[i]:
            return False
    return True
