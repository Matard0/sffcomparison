import collections
import re
from typing import List, Tuple

import pyspark.sql.functions as F
from pyspark.sql.dataframe import DataFrame
from rdslibrary.utilities.spark import get_spark

spark = get_spark()


def columns_have_duplicates(df: DataFrame, columns: List[str]) -> Tuple[bool, DataFrame]:
    """Returns if columns of a dataframe contain duplicated values and duplicates.

    Args:
        df: Dataframe to check for duplicates on.
        columns: List of columns to check for duplicates on.

    Returns:
        result: Boolean specifying if duplicates exist.
        df_duplicates: Dataframe with the duplicated values.
    """
    df_duplicates = df.groupBy(columns).count().where(F.col("count") > 1)
    result = df_duplicates.count() > 0
    return result, df_duplicates


def column_names_are_duplicated_modulo_index(df: DataFrame) -> Tuple[bool, List[str]]:
    """Returns if column names of a dataframe are duplicated modulo case and index appended by pyspark read.

    A column `column` at index `index` is duplicated if:

        - It is named the same as a column at another index modulo case
        - It is suspect, in other words if it follows `column != re.sub(f"{index}$", "", column))`, and its
        index-free version is duplicated among other index-free suspects.

    Args:
        df: Dataframe to analyse.

    Returns:
        result: Boolean specifying if duplicated columns are found.
        column_duplicates: Duplicated columns with index appended.
    """
    # we get a boolean as to whether or not the spark context is case sensitive
    case_sensitive = spark.conf.get("spark.sql.caseSensitive") == "true"
    # Initialize with simple duplicates
    columns = [c if case_sensitive else c.upper() for c in df.columns]
    column_duplicates = [item for item, count in collections.Counter(columns).items() if count > 1]
    for col in df.columns:
        if (col.upper() in column_duplicates) and (col not in column_duplicates):
            column_duplicates.append(col)

    # Define the suspect columns
    pyspark_columns = [
        (column_with_index, re.sub(f"{index}$", "", column_with_index))
        for index, column_with_index in enumerate(df.columns)
    ]
    suspect_columns = [
        (column_with_index, column, column.upper())
        for column_with_index, column in pyspark_columns
        if column_with_index != column
    ]
    uppercase_suspect_columns = list({c[2] for c in suspect_columns})
    # Append index-free suspect duplicates
    for t in suspect_columns:
        column_with_index, column, column_upper = t
        if column_upper in uppercase_suspect_columns:
            column_duplicates.append(column_with_index)

    result = len(column_duplicates) != 0
    return result, column_duplicates
