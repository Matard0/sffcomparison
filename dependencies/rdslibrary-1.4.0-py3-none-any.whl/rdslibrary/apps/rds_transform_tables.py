import datetime
import logging
import sys
import time
from typing import Union

import rdslibrary.core.dimensions.Fact as fact
import rdslibrary.core.dimensions.Market as market
import rdslibrary.core.dimensions.Period as period
import rdslibrary.core.dimensions.Product as product
from pyspark.sql.utils import AnalysisException
from rdslibrary.apps.configurations.Configuration import Configuration
from rdslibrary.core.dimensions.Data import Data
from rdslibrary.core.schema import Schema
from rdslibrary.core.transformation.MetaFactory import MetaFactory
from rdslibrary.utilities.functions import read_json
from rdslibrary.utilities.spark import get_spark

spark = get_spark()


def main(directory: str, configuration: Union[str, dict]):
    """
    Tranforms tables into Redslim Data Standard format files.

    Args:
        directory: Path to the directory containing the files.
        configuration: Path to the configuration file.

    Raises:
        AnalysisException: If matching input files cannot be read as csv, parquet, or delta.
        ValueError: If the provided prefix does not follow the requirements.
    """
    # Time run
    start = time.time()

    # Initialize logger
    logging.basicConfig(
        stream=sys.stdout,
        level=logging.DEBUG,
        format="%(asctime)s - %(levelname)s - %(message)s",
    )
    logging.getLogger("py4j").setLevel(logging.ERROR)  # Limit cluster logging
    logger = logging.getLogger(__name__)

    logger.info(f"Starting 'rds_transform_tables' at '{directory}'.")

    # Parse configuration
    if isinstance(configuration, str):
        configuration = read_json(configuration)
        configuration = configuration["rds_transform_tables"]
    else:
        pass

    configuration = Configuration(configuration)

    path_store = configuration.get_path_dimensions(directory)

    # Initialize empty schema
    sch = Schema()
    # Prepare the meta data
    for path, l in path_store.items():

        # Read
        df = None
        read = configuration.read
        path_is_a_directory = path[-1] == "/"
        if path_is_a_directory:
            # Read parquet and if failure read delta
            try:
                df = spark.read.parquet(path)
            except AnalysisException:
                try:
                    df = spark.read.format("delta").load(path)
                except AnalysisException as e:
                    raise AnalysisException(
                        f"Path '{path}' could not be read as parquet or delta into a dataframe.",
                        e.stackTrace,
                    )
        else:
            # Read csv
            df = spark.read.csv(
                path,
                sep=read.parameters["sep"],
                encoding=read.parameters["encoding"],
                header=True,
                inferSchema=False,
            )
        dict_dimension = {"market": market, "product": product, "period": period, "fact": fact}
        # Market, Product, Period, and Fact preparation
        if "data" in l:
            l.remove("data")
            for name in l:
                logger.info(f"Creating '{name}' from '{path}'.")
                config = configuration.__getattribute__(name)
                meta_type = getattr(dict_dimension[name], name.title())
                factory = MetaFactory(meta_type)
                dimension, df = factory.create_from_dataframe(df, config.columns, config.tag)
                sch.__setattr__(name, dimension)
            logger.info(f"Creating 'data' from '{path}'.")
            sch.data = Data(df)
        else:
            for name in l:
                logger.info(f"Creating '{name}' from '{path}'.")
                config = configuration.__getattribute__(name.lower())
                # meta_type = getattr(rds_dimensions, name.title())
                meta_type = getattr(dict_dimension[name], name.title())
                factory = MetaFactory(meta_type)
                dimension, _ = factory.create_from_dataframe(df, config.columns, config.tag)
                sch.__setattr__(name, dimension)

                tag_translation = configuration.data.tag_translation[name.lower()]
                sch.translate_tags(name, meta=tag_translation["meta"], data=tag_translation["data"])

    # Prepare the data
    sch.translate_facts(source="__VALUE__", target="TAG")

    data_standard_columns = sch.data.standard_columns
    sch.data.df = sch.data.df.select(
        data_standard_columns + [c for c in sch.data.df.columns if c not in data_standard_columns]
    )

    period_alignment_was_performed = False
    # Apply the services asked for in the configuration
    for name in ["market", "product", "period", "fact", "data"]:
        dimension = sch.__getattribute__(name)
        for service in configuration.__getattribute__(name).services:
            method_name = service.get("name")
            method_parameters = service.get("parameters", {})
            method = getattr(dimension, method_name)
            logger.info(f"Applying on '{name}' service '{method_name}'.")
            method(**method_parameters)
            if method_name == "align_periods":
                if "set_period_align" in method_parameters.keys():
                    period_alignment_was_performed = method_parameters["set_period_align"]
                else:
                    period_alignment_was_performed = True

    # Write the schema
    logger.info("Writing schema ...")

    # Set the prefix for files to write
    write = configuration.write
    if period_alignment_was_performed and isinstance(write.parameters["prefix"], str):
        # Create prefix based on period and existing prefix
        prefix = write.parameters["prefix"].split("_")
        if prefix[0] == "RDSM" and prefix[1] != "" and prefix[2] != "" and len(prefix) == 3:
            _, database, category = tuple(prefix[:3])
            write.parameters["prefix"] = (
                sch.get_extended_name(database=database, category=category) + "_"
            )
        else:
            raise ValueError(
                "Prefix '"
                + write.parameters["prefix"]
                + "' is not valid, it should be of form 'RDSM_{database}_{category}' with database and category not empty."
            )
    else:
        # Use the provided prefix
        pass

    sch.write(**write.dimension_names).blob(
        directory,
        sep=write.parameters["sep"],
        encoding=write.parameters["encoding"],
        mode=write.parameters["mode"],
        prefix=write.parameters["prefix"],
    )

    # Finalize run
    elapsed = datetime.timedelta(seconds=(time.time() - start))
    logger.info(f"Ending 'rds_transform_tables' successfully (elapsed='{elapsed}').")
