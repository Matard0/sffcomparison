import datetime
import json
import logging
import os
import sys
import time
from typing import Optional, Union

import pyspark.sql.functions as F
import rdslibrary as rds
from pyspark.sql.types import DoubleType, IntegerType, StringType
from rdslibrary.apps.configurations.ConfigurationConsolidation import ConfigurationConsolidation
from rdslibrary.core.schema import Schema
from rdslibrary.utilities.consolidation_utilities import aggregated_periods_qc, read_period_mapping
from rdslibrary.utilities.functions import read_json
from rdslibrary.utilities.spark import get_dbutils, get_spark

spark = get_spark()
dbutils = get_dbutils(spark)


def main(
    directory_input: str,
    database: str,
    configuration: Union[str, dict],
    directory_output: Optional[str] = None,
    logging_file_handler: Optional[logging.FileHandler] = None,
) -> Schema:
    """
    Prepares Redslim Data Standard schema for a consolidation build.

    Args:
        directory_input: Path to the directory to read from.
        database: Name of the database.
        configuration: Path to the configuration file or configuration dictionary specific to the application.
        directory_output: Path to the directory to write to, if none is passed the output schema is not written.
        logging_file_handler: a logging.FileHandler object that can be used to write logs to file as well as to stdout.

    Returns:
        Prepared schema that can also be written using optional argument `directory_output`.
    """
    # Time run
    start = time.time()

    # Initialize logger
    logging.basicConfig(
        stream=sys.stdout,
        level=logging.DEBUG,
        format="%(asctime)s - %(levelname)s - %(message)s",
    )
    logging.getLogger("py4j").setLevel(logging.ERROR)  # Limit cluster logging
    logger = logging.getLogger(__name__)
    # if we have an extra logging handler to add, then add this
    if logging_file_handler:
        logger.addHandler(logging_file_handler)

    logger.info(
        f"Starting 'rds_prepare_consolidation' with input='{directory_input}' and output='{directory_output}'."
    )

    # Parse configuration
    if isinstance(configuration, str):
        configuration = read_json(configuration)
        configuration = configuration["rds_consolidation"]
    else:
        pass

    configuration = ConfigurationConsolidation(configuration, database)

    # Read the schema

    read = configuration.preparation_read
    sch = rds.read(
        **read.dimension_patterns,
        apply_special_cases_on_read=read.parameters["apply_special_cases_on_read"],
        case_sensitive=read.parameters["case_sensitive"],
    ).blob(
        directory_input,
        sep=read.parameters["sep"],
        encoding=read.parameters["encoding"],
        search_enriched=read.parameters["search_enriched"],
    )

    # Reduce the schema with fact alignment and factor application
    logger.info("Applying fact alignment and translation.")
    fact_alignment_target = configuration.preparation_translate_facts["target"]
    sch.fact.df = sch.fact.df.withColumn(
        fact_alignment_target,
        F.when(
            F.col(configuration.preparation_select_facts_column) == "TRUE",
            F.col(fact_alignment_target),
        ).otherwise(F.lit(None)),
    )
    sch.translate_facts(**configuration.preparation_translate_facts)
    sch.fact.df = sch.fact.df.withColumn("RDSLM_FACT_ALIGN", F.col("TAG"))
    sch.fact.set_fact_type(source="RDSLM_FACT_ALIGN", fact_type_column="RDSLM_FACT_TYPE")

    if configuration.preparation_filter_schema:
        for query in configuration.preparation_filter_schema:
            logger.info(
                f"Filtering the {query['dimension']} dimension of the sff with the condition '{query['condition']}'."
            )
            sch.where(query["dimension"], query["condition"])

    # before translating periods, calculate the total value of the fact_driver to compare with after
    total_before_period_translation = sch.data.df.agg(
        F.sum(configuration.preparation_qc["fact_driver"]).alias(
            configuration.preparation_qc["fact_driver"]
        )
    ).first()[0]

    # Apply period alignment
    logger.info("Apply period alignment.")
    df_period_mapping = read_period_mapping(
        configuration.preparation_period_mapping,
        iso_code=configuration.preparation_period_mapping_id,
    )
    sch.translate_periods(df_period_mapping)
    sch.period.add_year_and_rank_after_period_translation(
        **configuration.preparation_year_and_rank_population
    )

    # check that the total value remains the same, while excluding pre-aggregated periods
    total_after_period_translation = (
        sch.data.df.where(
            F.col("PERIOD_TAG").rlike(configuration.preparation_year_and_rank_population["parser"])
        )
        .agg(
            F.sum(configuration.preparation_qc["fact_driver"]).alias(
                configuration.preparation_qc["fact_driver"]
            )
        )
        .first()[0]
    )

    if (
        abs(1 - total_after_period_translation / total_before_period_translation) > 0.000000001
    ) and configuration.preparation_qc["compare_totals_after_period_translation"]:
        raise Exception(
            f"The total value of {configuration.preparation_qc['fact_driver']} is different to before the period translation. Please verify the mapping file."
        )
    if configuration.preparation_qc["verify_pre_aggregated_periods"]:
        aggregated_periods_qc(
            sch=sch,
            parser=configuration.preparation_year_and_rank_population["parser"],
            fact_driver=configuration.preparation_qc["fact_driver"],
            mat_labels=configuration.preparation_qc["mat_labels"],
            ytd_labels=configuration.preparation_qc["ytd_labels"],
        )

    # Specify tags
    logger.info("Apply tag specification.")
    for name in ["market", "product"]:
        sch.specify_tags(name, database)

    # Filtering of columns and standard formatting
    consolidation_columns = configuration.consolidation_columns["product"]
    sch.product.df = (
        sch.product.df.select(sch.product.standard_columns + consolidation_columns)
        .withColumn("DISPLAY_ORDER", F.lit(None).cast(IntegerType()))
        .withColumn("PARENT_TAG", F.lit(None).cast(StringType()))
        .withColumn("HIER_NUM", F.lit(None).cast(IntegerType()))
        .withColumn("HIER_NAME", F.lit(None).cast(StringType()))
        .withColumn("HIER_LEVEL_NUM", F.lit(None).cast(IntegerType()))
        .withColumn("HIER_LEVEL_NAME", F.lit(None).cast(StringType()))
    )

    consolidation_columns = configuration.consolidation_columns["market"]
    sch.market.df = (
        sch.market.df.select(sch.market.standard_columns + consolidation_columns)
        .withColumn("DISPLAY_ORDER", F.lit(None).cast(IntegerType()))
        .withColumn("PARENT_TAG", F.lit(None).cast(StringType()))
        .withColumn("HIER_NUM", F.lit(None).cast(IntegerType()))
        .withColumn("HIER_NAME", F.lit(None).cast(StringType()))
        .withColumn("HIER_LEVEL_NUM", F.lit(None).cast(IntegerType()))
        .withColumn("HIER_LEVEL_NAME", F.lit(None).cast(StringType()))
    )

    extra_period_columns = ["YEAR", "RANK"]
    sch.period.df = (
        sch.period.df.select(sch.period.standard_columns + extra_period_columns)
        .withColumn("SHORT", F.col("TAG"))
        .withColumn("LONG", F.col("TAG"))
        .withColumn("DISPLAY_ORDER", F.lit(None).cast(IntegerType()))
        .withColumn("PARENT_TAG", F.lit(None).cast(StringType()))
        .withColumn("HIER_NUM", F.lit(None).cast(IntegerType()))
        .withColumn("HIER_NAME", F.lit(None).cast(StringType()))
        .withColumn("HIER_LEVEL_NUM", F.lit(None).cast(IntegerType()))
        .withColumn("HIER_LEVEL_NAME", F.lit(None).cast(StringType()))
    )

    extra_fact_columns = ["RDSLM_FACT_ALIGN", "RDSLM_FACT_TYPE"]
    sch.fact.df = (
        sch.fact.df.select(sch.fact.standard_columns + extra_fact_columns)
        .withColumn("SHORT", F.col("TAG"))
        .withColumn("LONG", F.col("TAG"))
        .withColumn("DISPLAY_ORDER", F.lit(None).cast(IntegerType()))
        .withColumn("CURRENCY", F.lit(None).cast(StringType()))
        .withColumn("PRECISION", F.lit(None).cast(IntegerType()))
        .withColumn("DENOMINATOR", F.lit(None).cast(DoubleType()))
        .withColumn("MKT_AGGREGATION", F.lit(None).cast(StringType()))
        .withColumn("PROD_AGGREGATION", F.lit(None).cast(StringType()))
        .withColumn("PER_AGGREGATION", F.lit(None).cast(StringType()))
    )

    # Write the schema
    if directory_output:
        logger.info("Writing schema ...")
        write = configuration.preparation_write
        sch.write(**write.dimension_names).blob(
            directory_output,
            sep=write.parameters["sep"],
            encoding=write.parameters["encoding"],
            mode=write.parameters["mode"],
            prefix=write.parameters["prefix"],
        )
        # Write status.json in the directory output with one key 'latest_period' = latest period of the sff
        latest_period = (
            sch.period.df.where(
                F.col("TAG").rlike(configuration.preparation_year_and_rank_population["parser"])
            )
            .agg({"TAG": "max"})
            .first()[0]
        )
        period_dict = json.dumps({"latest_period": latest_period}, indent=4)
        dbutils.fs.put(os.path.join(directory_output, "status.json"), period_dict, True)

    # Finalize run
    elapsed = datetime.timedelta(seconds=(time.time() - start))
    logger.info(f"Ending 'rds_prepare_consolidation' successfully (elapsed='{elapsed}').")

    return sch
