import datetime
import logging
import ntpath
import sys
import time
from typing import Union

import rdslibrary as rds
from rdslibrary.apps.configurations.Configuration import Configuration
from rdslibrary.core.read_write.SchemaReader import SchemaReader
from rdslibrary.utilities.functions import get_longest_substring, read_json
from rdslibrary.utilities.spark import get_dbutils, get_spark

spark = get_spark()
dbutils = get_dbutils(spark)


def main(directory: str, configuration: Union[str, dict]):
    """
    Applies methods to Redslim Data Standard format files.

    Args:
        directory: Path to the directory containing the files.
        configuration: Path to the configuration file or configuration dictionary specific to the application.

    Raises:
        ValueError: If a provided activity name is not valid.
    """
    # Time run
    start = time.time()

    # Initialize logger
    logging.basicConfig(
        stream=sys.stdout,
        level=logging.DEBUG,
        format="%(asctime)s - %(levelname)s - %(message)s",
    )
    logging.getLogger("py4j").setLevel(logging.ERROR)  # Limit cluster logging
    logger = logging.getLogger(__name__)

    logger.info(f"Starting 'rds_apply_services' at '{directory}'.")

    # Parse configuration
    if isinstance(configuration, str):
        configuration = read_json(configuration)
        configuration = configuration["rds_apply_services"]
    else:
        pass

    configuration = Configuration(configuration)

    # Read the schema
    read = configuration.read
    sch = rds.read(
        **read.dimension_patterns,
        apply_special_cases_on_read=read.parameters["apply_special_cases_on_read"],
    ).blob(
        directory,
        sep=read.parameters["sep"],
        encoding=read.parameters["encoding"],
        search_enriched=read.parameters["search_enriched"],
    )

    # Set the prefix for files to write
    write = configuration.write
    if isinstance(write.parameters["prefix"], str):
        # Use the provided prefix
        pass
    else:
        # Use dynamic prefix defined as the longest substring of read files
        ls = dbutils.fs.ls(directory)
        dimensions_read_path = [
            SchemaReader.get_dimension_path_to_read(ls, read.parameters["search_enriched"], pattern)
            for pattern in read.dimension_patterns.values()
            if pattern
        ]
        dimensions_read_filename = [ntpath.basename(p) for p in dimensions_read_path]
        prefix = get_longest_substring(dimensions_read_filename)
        write.parameters["prefix"] = prefix

    # Apply methods to the schema
    for activity in configuration.activities:
        name = activity.dimension
        logger.info(f"Applying on '{name}' services ...")
        if name in ["market", "product", "period", "fact", "data"]:
            dimension = sch.__getattribute__(name)
            for service in activity.services:
                method_name = service.get("name")
                method_parameters = service.get("parameters", {})
                method = getattr(dimension, method_name)
                logger.info(f"Applying on '{name}' service '{method_name}'.")
                method(**method_parameters)
        elif name == "schema":
            for service in activity.services:
                method_name = service.get("name")
                method_parameters = service.get("parameters", {})
                method = getattr(sch, method_name)
                logger.info(f"Applying on '{name}' service '{method_name}'.")
                method(**method_parameters)
        else:
            raise ValueError(f"Activity name '{name}' is not valid.")

    # Write the schema
    logger.info("Writing schema ...")
    sch.write(**write.dimension_names).blob(
        directory,
        sep=write.parameters["sep"],
        encoding=write.parameters["encoding"],
        mode=write.parameters["mode"],
        prefix=write.parameters["prefix"],
    )

    # Finalize run
    elapsed = datetime.timedelta(seconds=(time.time() - start))
    logger.info(f"Ending 'rds_apply_services' successfully (elapsed='{elapsed}').")
