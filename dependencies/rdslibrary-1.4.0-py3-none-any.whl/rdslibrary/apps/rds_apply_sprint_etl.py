import datetime
import logging
import sys
import time
from typing import Union

import pyspark.sql.functions as F
import pyspark.sql.types as T
import rdslibrary as rds
from rdslibrary.apps.configurations.ConfigurationApplySprintETL import ConfigurationApplySprintETL
from rdslibrary.apps.rds_validate_against_sprint_config import validate_against_sprint_config
from rdslibrary.utilities.consolidation_utilities import read_period_mapping
from rdslibrary.utilities.functions import read_json
from rdslibrary.utilities.spark import get_dbutils, get_spark

spark = get_spark()
dbutils = get_dbutils(spark)


def main(
    directory_output: str,
    configuration: Union[str, dict],
    directory_input: str = None,
    sch: rds.core.schema.Schema = None,
    logging_file_handler: logging.FileHandler = None,
):
    """
    Prepares Redslim Data Standard format files to be loaded into Sprint.

    Args:
        directory_output: Path to the directory to write to.
        configuration: Path to the configuration file or configuration dictionary specific to the application.
        directory_input: Path to the directory to read from.
        sch: An rdslibrary schema object already representing the SFF to ETL.
        logging_file_handler: a logging.FileHandler object that can be used to write logs to file as well as to stdout.
    """
    # Time run
    start = time.time()

    # Initialize logger
    logging.basicConfig(
        stream=sys.stdout,
        level=logging.DEBUG,
        format="%(asctime)s - %(levelname)s - %(message)s",
    )
    logging.getLogger("py4j").setLevel(logging.ERROR)  # Limit cluster logging
    global logger
    logger = logging.getLogger(__name__)
    # if we have an extra logging handler to add, then add this
    if logging_file_handler:
        logger.addHandler(logging_file_handler)

    logger.info(
        f"Starting 'rds_apply_sprint_etl' with input='{directory_input}' and output='{directory_output}'."
    )

    # Parse configuration
    if isinstance(configuration, str):
        configuration = read_json(configuration)
        configuration = configuration["rds_apply_sprint_etl"]
    else:
        pass

    configuration = ConfigurationApplySprintETL(configuration)

    if directory_input:
        # Read the schema
        read = configuration.read
        sch = rds.read(
            **read.dimension_patterns,
            apply_special_cases_on_read=read.parameters["apply_special_cases_on_read"],
            case_sensitive=read.parameters["case_sensitive"],
        ).blob(
            directory_input,
            sep=read.parameters["sep"],
            encoding=read.parameters["encoding"],
            search_enriched=read.parameters["search_enriched"],
        )
    elif isinstance(sch, rds.core.schema.Schema):
        # if the schema is provided as an argument, continue
        pass
    else:
        raise Exception(
            "Neither a directory input or valid schema object were supplied to the main function."
            " Please supply either one of these as argument to the function call."
        )

    for custom_market in configuration.create_custom_market:
        logger.info(f"Creating a new custom market from {custom_market['markets_to_aggregate']}.")
        sch.create_custom_market(**custom_market)

    if configuration.rename_duplicated_columns_associated_with_hierarchies is not None:
        logger.info("Renaming product columns associated with hierarchies.")
        sch.product.rename_duplicated_columns_associated_with_hierarchies(
            **configuration.rename_duplicated_columns_associated_with_hierarchies
        )

    logger.info("Applying fact alignment and translation.")
    fact_alignment_target = configuration.translate_facts["target"]
    sch.fact.df = sch.fact.df.withColumn(
        fact_alignment_target,
        F.when(
            F.col(configuration.select_facts_column) == "TRUE",
            F.col(fact_alignment_target),
        ).otherwise(F.lit(None)),
    )
    sch.translate_facts(**configuration.translate_facts)

    if configuration.translate_periods:
        logger.info(
            f"Translating periods according to file {configuration.translate_periods['period_mapping_file_path']}"
        )
        period_mapping = read_period_mapping(
            configuration.translate_periods["period_mapping_file_path"],
            configuration.translate_periods["iso_code"],
        )
        sch.translate_periods(period_mapping)

    logger.info("Applying period alignment.")
    sch.period.align_periods(**configuration.align_periods)
    sch.period.df = sch.period.df.withColumn("SDESC", F.col("SHORT"))

    if configuration.filter_schema:
        for query in configuration.filter_schema:
            logger.info(
                f"Filtering the {query['dimension']} dimension of the sff with the condition '{query['condition']}'."
            )
            sch = sch.where(query["dimension"], query["condition"])

    for update in configuration.update_total_level_values:
        logger.info(f"Updating total level values for dimension TAG '{update['total_level_tag']}'")
        sch.update_total_level_values(**update)

    for promotion in configuration.promote_level:
        logger.info(f"Promoting dimension {promotion['dimension']}")
        sch.promote_level(**promotion)

    logger.info("Renaming market description duplicates.")
    sch.market.rename_duplicate_records("SHORT")
    sch.market.rename_duplicate_records("LONG")

    logger.info("Removing problematic characters from product dimension values and columns.")
    sch.product.replace_characters_from_values(r";|\||¶", "_")
    sch.product.replace_characters_from_values(r"\s+", " ")  # White space replacement
    sch.product.replace_characters_from_column_names(r";|\||¶|\[|\]", "_")
    sch.product.replace_characters_from_column_names(r"\s+", " ")  # White space replacement

    # Dropping potential duplicates
    sch = drop_tag_duplicates(sch, configuration)

    # Cast types of data
    sch.data.df = sch.data.df.select(
        [
            F.col(c).cast(T.DoubleType())
            if c not in ["MARKET_TAG", "PRODUCT_TAG", "PERIOD_TAG"]
            else c
            for c in sch.data.df.columns
        ]
    )

    for statement in configuration.upsert_columns:
        logger.info(
            f"Effectively running the following SQL statement in upsert_column_value method:\n"
            f"UPSERT {statement['dimension']}.{statement['column_to_populate']} CASE WHEN {statement['conditional_statement']} "
            f"THEN {statement['value_to_populate']} ELSE {statement['otherwise_value']} END"
        )
        sch.__getattribute__(statement["dimension"]).upsert_column_value(
            statement["column_to_populate"],
            statement["conditional_statement"],
            statement["value_to_populate"],
            statement["otherwise_value"],
        )

    sch.data.df = sch.data.df.cache()

    # Audit

    logger.info("Auditing meta data tag duplicates ...")
    sch.market.audit_duplicates_column(["TAG"])
    sch.period.audit_duplicates_column(["TAG"])
    sch.fact.audit_duplicates_column(["TAG"])
    sch.product.audit_duplicates_column(["TAG"])

    audit_total_market_column = configuration.audit.audit_total_market["column"]
    audit_total_market_value = configuration.audit.audit_total_market["value"]
    logger.info(
        f"Auditing existence of a total market (called {audit_total_market_value}) in column {audit_total_market_column} ..."
    )
    sch.market.audit_value_in_column(
        column=audit_total_market_column, value=audit_total_market_value
    )

    logger.info("Auditing the hierarchy of the product file ...")
    sch.product.audit_hierarchy(configuration.audit.product_audits_to_skip)

    logger.info("Auditing data tag duplicates ...")
    sch.data.audit_tag_combinations_are_unique()

    logger.info("Auditing tag coherence ...")
    sch.audit_tags_are_coherent()

    if "check_SPRINT_config" not in configuration.audit.sprint_config_checks_to_skip:
        logger.info("Validating the database against the SPRINT config ...")
        validate_against_sprint_config(
            database=configuration.sprint_database_name,
            logger=logger,
            sch=sch,
            checks_to_skip=configuration.audit.sprint_config_checks_to_skip,
        )

    if configuration.sprint_cube_load:
        create_table_strings = sch.get_all_table_creation_strings(
            database_name=configuration.sprint_database_name
        )
        meta_pk = f"[{sch.period.df.columns[0]}]"  # e.g. [TAG]
        data_pk = ", ".join(
            [f"[{column_name}]" for column_name in sch.data.df.columns[:3]]
        )  # e.g. [MARKET_TAG], [PRODUCT_TAG], [PERIOD_TAG]
    else:
        create_table_strings, meta_pk, data_pk = (None, None, None)

    # Write the schema
    logger.info("Writing schema ...")
    write = configuration.write
    sch.write(**write.dimension_names).blob(
        directory_output,
        sep=write.parameters["sep"],
        encoding=write.parameters["encoding"],
        mode=write.parameters["mode"],
        prefix=write.parameters["prefix"],
    )

    sch.data.df.unpersist()

    # Finalize run
    elapsed = datetime.timedelta(seconds=(time.time() - start))
    logger.info(f"Ending 'rds_apply_services' successfully (elapsed='{elapsed}').")

    return create_table_strings, meta_pk, data_pk, configuration.raw_sql


def drop_tag_duplicates(sch, configuration):
    """Function to orchestrate calling of drop duplicates for each dimension.

    Args:
        sch: A schema object of the SFF.
        configuration: a configuration object for the ETL.
    """
    if configuration.drop_tag_duplicates is not None:
        if configuration.drop_tag_duplicates.market:
            logger.info("Dropping tag duplicates for dimension 'market'.")
            sch.market.df = sch.market.df.dropDuplicates(subset=["TAG"])
        if configuration.drop_tag_duplicates.product:
            logger.info("Dropping tag duplicates for dimension 'product'.")
            sch.product.df = sch.product.df.dropDuplicates(subset=["TAG"])
        if configuration.drop_tag_duplicates.period:
            logger.info("Dropping tag duplicates for dimension 'period'.")
            sch.period.df = sch.period.df.dropDuplicates(subset=["TAG"])
        if configuration.drop_tag_duplicates.data:
            logger.info("Dropping tag duplicates for dimension 'data'.")
            sch.data.df = sch.data.df.dropDuplicates(
                subset=["MARKET_TAG", "PRODUCT_TAG", "PERIOD_TAG"]
            )
    return sch
