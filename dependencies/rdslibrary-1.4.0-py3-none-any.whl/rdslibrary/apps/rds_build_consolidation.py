import datetime
import logging
import sys
import time
from typing import Optional, Union

import pyspark.sql.functions as F
import rdslibrary as rds
from rdslibrary.apps.configurations.ConfigurationConsolidation import ConfigurationConsolidation
from rdslibrary.core.schema import Schema
from rdslibrary.utilities.consolidation_utilities import check_preparations_latest_periods
from rdslibrary.utilities.functions import read_json
from rdslibrary.utilities.spark import get_dbutils, get_spark

spark = get_spark()
dbutils = get_dbutils(spark)


def main(
    directory_input: str,
    configuration: Union[str, dict],
    directory_output: Optional[str] = None,
    logging_file_handler: Optional[logging.FileHandler] = None,
) -> Schema:
    """
    Build Redslim Data Standard schema for a consolidated cube.

    Args:
        directory_input: Path to the directory to read the prepared cubes from.
        configuration: Path to the configuration file or configuration dictionary specific to the application.
        directory_output: Path to the directory to write to, if none is passed the output schema is not written.
        logging_file_handler: a logging.FileHandler object that can be used to write logs to file as well as to stdout.

    Returns:
        Built schema that can also be written using optional argument `directory_output`.
    """

    # Time run
    start = time.time()

    # Initialize logger
    logging.basicConfig(
        stream=sys.stdout,
        level=logging.DEBUG,
        format="%(asctime)s - %(levelname)s - %(message)s",
    )
    logging.getLogger("py4j").setLevel(logging.ERROR)  # Limit cluster logging
    logger = logging.getLogger(__name__)
    # if we have an extra logging handler to add, then add this
    if logging_file_handler:
        logger.addHandler(logging_file_handler)

    logger.info(
        f"Starting 'rds_build_consolidation' with input='{directory_input}' and output='{directory_output}'."
    )

    # Parse configuration
    if isinstance(configuration, str):
        configuration = read_json(configuration)
        configuration = configuration["rds_consolidation"]
    else:
        pass

    configuration = ConfigurationConsolidation(configuration)
    configuration_databases = list(configuration.contributions.keys())

    build_inputs = dbutils.fs.ls(directory_input)

    # Append prepared schemas
    check_preparations_latest_periods(
        build_inputs, configuration_databases, check=configuration.build_qc_latest_period
    )

    dimension_patterns = {
        dimension: name + "*"
        for dimension, name in configuration.preparation_write.dimension_names.items()
    }

    dfs_data = []
    dfs_columns = []
    for i, file_info in enumerate(build_inputs):
        if i == 0:
            sch = rds.read(**dimension_patterns).blob(file_info.path)
            dfs_data.append(sch.data.df)
            dfs_columns += sch.data.df.columns

        else:
            sch_tmp = rds.read(**dimension_patterns).blob(file_info.path)
            dfs_data.append(sch_tmp.data.df)
            dfs_columns += sch_tmp.data.df.columns

            sch.market.df = sch.market.df.unionByName(sch_tmp.market.df)
            sch.product.df = sch.product.df.unionByName(sch_tmp.product.df)
            sch.period.df = sch.period.df.unionByName(sch_tmp.period.df)
            sch.fact.df = sch.fact.df.unionByName(sch_tmp.fact.df)

    # The data dimension needs specific append because of missing columns
    # This is temporary on Spark>=3.1.x, use unionByName with `allowMissingColumns=True`
    data_tag_columns = ["MARKET_TAG", "PRODUCT_TAG", "PERIOD_TAG"]
    dfs_columns = data_tag_columns + sorted(
        [c for c in list(set(dfs_columns)) if c not in data_tag_columns]
    )
    dfs_data = [
        df.select([F.col(c) if c in df.columns else F.lit(None).alias(c) for c in dfs_columns])
        for df in dfs_data
    ]
    for i, df in enumerate(dfs_data):
        if i == 0:
            sch.data.df = df
        else:
            sch.data.df = sch.data.df.unionByName(df)

    sch.period.df = sch.period.df.drop_duplicates(subset=["TAG"])
    sch.fact.df = sch.fact.df.drop_duplicates(subset=["TAG"])
    sch.fact.df = sch.fact.df.withColumn("RDSLM_SPRINT_USE", F.lit("TRUE"))

    # Product tag resampling
    sch.resample_dimension("product", columns=configuration.consolidation_columns["product"])

    # Product hierarchy creation
    create_hierarchy_product = configuration.build_create_hierarchy["product"]
    sch.create_hierarchy_from_bottom(
        "product",
        hierarchy_name=create_hierarchy_product["hierarchy_name"],
        hierarchy_columns=create_hierarchy_product["hierarchy_columns"],
    )

    # Write the schema
    if directory_output:
        logger.info("Writing schema ...")
        write = configuration.build_write
        sch.write(**write.dimension_names).blob(
            directory_output,
            sep=write.parameters["sep"],
            encoding=write.parameters["encoding"],
            mode=write.parameters["mode"],
            prefix=write.parameters["prefix"],
        )

    # Finalize run
    elapsed = datetime.timedelta(seconds=(time.time() - start))
    logger.info(f"Ending 'rds_build_consolidation' successfully (elapsed='{elapsed}').")

    return sch
