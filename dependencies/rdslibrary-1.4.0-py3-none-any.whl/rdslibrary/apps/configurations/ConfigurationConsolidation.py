import re
from typing import Optional

from rdslibrary.apps.configurations.Read import Read
from rdslibrary.apps.configurations.Write import Write


class ConfigurationConsolidation:
    r"""
    Class to represent the main configuration in `rds_prepare_consolidation`.

    Attributes:
        contributions: Dictionary of local contributions to consolidated cube.
        database_contribution: Contribution of the database being prepared.
        preparation_read: Object describing the read for the preparation.
        preparation_write: Object describing the write for the preparation.
        preparation_select_facts_column: Column specifying which facts to keep for the preparation.
        preparation_translate_facts: Fact translation arguments.
        preparation_filter_schema: List of schema reduction arguments.
        preparation_period_mapping: Path to the period mapping file.
        preparation_period_mapping_id: Expression in the period mapping csv lines helping to identify the ones to be used.
        preparation_qc: A dictionary specifying the fact_driver and whether to skip two of the qc steps
            e.g. `{"fact_driver": "FCT000030000", "compare_totals_after_period_translation": true, "verify_pre_aggregated_periods": true}`
        preparation_year_and_rank_population: A dictionary of arguments to pass to the add_year_and_rank_after_period_translation method.
            e.g. `{"parser": "P(\d{4})(\d{2})", "year_group": 1, "rank_group": 2}`
        build_qc_latest_period: Boolean specifying whether the check if the latest periods are similar
        build_create_hierarchy: Dictionary specifying how to create the product hierarchy.
        build_write: Object describing the write for the build.
        consolidation_columns: List of columns to keep for market and product in addition to standard ones.
    """

    def __init__(self, dictionary: dict, database: Optional[str] = None):
        """
        Class constructor.

        Args:
            dictionary: Object dictionary representation.
            database: Name of the database.
        """
        is_preparation = database is not None
        self.contributions: dict = dictionary["contributions"]
        self.consolidation_columns: dict = dictionary["consolidation_columns"]
        self.preparation_write: Write = Write(dictionary.get("preparation_write", {}))

        # Define the different attributes depending on the preparation or build context.
        if is_preparation:
            self.database_contribution: dict = self.contributions[database]

            self.preparation_read: Read
            if "preparation_read" in self.database_contribution:
                self.preparation_read = Read(self.database_contribution["preparation_read"])
            else:
                self.preparation_read = Read(dictionary.get("preparation_read", {}))

            self.preparation_select_facts_column: str
            if "preparation_select_facts_column" in self.database_contribution:
                self.preparation_select_facts_column = self.database_contribution[
                    "preparation_select_facts_column"
                ]
            else:
                self.preparation_select_facts_column = dictionary.get(
                    "preparation_select_facts_column", "RDSLM_CONSOLIDATION_USE"
                )

            self.preparation_translate_facts: dict
            if "preparation_translate_facts" in self.database_contribution:
                self.preparation_translate_facts = self.database_contribution[
                    "preparation_translate_facts"
                ]
            else:
                self.preparation_translate_facts = dictionary["preparation_translate_facts"]

            self.preparation_filter_schema: list
            if "preparation_filter_schema" in self.database_contribution:
                self.preparation_filter_schema = self.database_contribution[
                    "preparation_filter_schema"
                ]
            else:
                self.preparation_filter_schema = dictionary.get("preparation_filter_schema", [])

            self.preparation_period_mapping: str
            if "preparation_period_mapping" in self.database_contribution:
                self.preparation_period_mapping = self.database_contribution[
                    "preparation_period_mapping"
                ]
            else:
                self.preparation_period_mapping = dictionary["preparation_period_mapping"]

            self.preparation_period_mapping_id: str = self.database_contribution.get(
                "preparation_period_mapping_id", database
            )

            self.preparation_qc: dict = dictionary.get(
                "preparation_qc",
                {
                    "fact_driver": "FCT000030000",
                    "compare_totals_after_period_translation": True,
                    "verify_pre_aggregated_periods": True,
                },
            )

            if "preparation_year_and_rank_population" in self.database_contribution:
                self.preparation_year_and_rank_population = self.database_contribution[
                    "preparation_year_and_rank_population"
                ]
            else:
                self.preparation_year_and_rank_population = dictionary.get(
                    "preparation_year_and_rank_population",
                    {"parser": r"P(\d{4})(\d{2})"},
                )

        else:
            self.build_create_hierarchy = dictionary["build_create_hierarchy"]
            self.build_write: Write = Write(dictionary.get("build_write", {}))
            self.build_qc_latest_period: bool = dictionary["build_qc_latest_period"]

            # Update the column names to take into account parquet formatting of the preparation
            if ("parquet" in self.preparation_write.parameters["mode"]) or (
                "delta" in self.preparation_write.parameters["mode"]
            ):
                self.consolidation_columns["product"] = [
                    re.sub(r"\s|,|;|\{|\}|\(|\)|\=", "_", c)
                    for c in self.consolidation_columns["product"]
                ]
