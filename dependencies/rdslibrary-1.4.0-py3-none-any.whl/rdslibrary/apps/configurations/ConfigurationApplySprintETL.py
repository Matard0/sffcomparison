from typing import List, Optional

from rdslibrary.apps.configurations.Auditer import Auditer
from rdslibrary.apps.configurations.Read import Read
from rdslibrary.apps.configurations.TagDuplicatesDropper import TagDuplicatesDropper
from rdslibrary.apps.configurations.Write import Write


class ConfigurationApplySprintETL:
    """
    Class to represent the main configuration in `rds_apply_sprint_etl`.

    Attributes:
        read: Object describing the read.
        write: Object describing the write.
        create_custom_market: Object custom markets to create and if so how to create these.
        filter_schema: Object describing filters to apply to the SFF.
        rename_duplicated_columns_associated_with_hierarchies: Object describing product hierarchy columns renaming.
        align_periods: Object describing the period alignment.
        select_facts_column: Column specifying which facts to keep for the etl.
        translate_facts: Object describing the fact translation.
        drop_tag_duplicates: Object describing if tag duplicates should be dropped.
        promote_level: Object describing dimensions in which to promote the level hierarchy.
        update_total_level_values: Object describing total values to update and from which level of the hierarchy.
        translate_periods: Object describing if and how to translate the periods.
        audit: Object describing the optional audits to be conducted.
        sprint_database_name: String matching the short name of the database in SPRINT.
        raw_sql: A dictionary of raw SQL statements that will need to be run during the load to SPRINT.
        upsert_columns: A list of dictionaries containing values to be passed to upsert_column_value.
        sprint_cube_load: A boolean specifying whether to output variables needed to finish the load to SPRINT.

    """

    def __init__(self, dictionary: dict):
        """
        Class constructor.

        Args:
            dictionary: Object dictionary representation.
        """
        self.read: Optional[Read] = Read(dictionary.get("read", {}))
        self.write: Optional[Write] = Write(dictionary.get("write", {}))

        self.create_custom_market: Optional[dict] = dictionary.get("create_custom_market", [])
        self.filter_schema: Optional[list] = dictionary.get("filter_schema", [])
        self.rename_duplicated_columns_associated_with_hierarchies: Optional[dict] = dictionary.get(
            "rename_duplicated_columns_associated_with_hierarchies", None
        )
        self.align_periods: dict = dictionary["align_periods"]
        # if "audit_year_and_rank_columns" is not present in align_periods config then add it
        self.align_periods["audit_year_and_rank_columns"] = self.align_periods.get(
            "audit_year_and_rank_columns", True
        )
        self.select_facts_column: str = dictionary.get("select_facts_column", "RDSLM_SPRINT_USE")
        self.translate_facts: dict = dictionary["translate_facts"]
        self.promote_level: Optional[list] = dictionary.get("promote_level", [])
        self.update_total_level_values: Optional[list] = dictionary.get(
            "update_total_level_values", []
        )
        self.translate_periods: Optional[dict] = dictionary.get("translate_periods", False)

        self.drop_tag_duplicates: Optional[TagDuplicatesDropper] = None
        if "drop_tag_duplicates" in dictionary.keys():
            self.drop_tag_duplicates = TagDuplicatesDropper(dictionary["drop_tag_duplicates"])

        self.audit: Optional[Auditer] = Auditer(dictionary["audit"])
        self.sprint_database_name: Optional[str] = dictionary.get("sprint_database_name", "")
        self.raw_sql: Optional[str] = dictionary.get("raw_sql", {})
        self.upsert_columns: Optional[List[dict]] = dictionary.get("upsert_columns", [])
        self.sprint_cube_load: Optional[bool] = dictionary.get("sprint_cube_load", False)
