from collections import defaultdict

from rdslibrary.apps.configurations.Activity import Activity
from rdslibrary.apps.configurations.Descriptor import Descriptor
from rdslibrary.apps.configurations.Read import Read
from rdslibrary.apps.configurations.Write import Write
from rdslibrary.utilities.functions import get_paths


class Configuration:
    """
    Class to represent the main configuration in `rds_transform_tables` and `rds_apply_services`.

    Attributes:
        read: IO object describing the read.
        write: IO object describing the write.
        market: Descriptor of the market dimension.
        product: Descriptor of the product dimension.
        period: Descriptor of the period dimension.
        fact: Descriptor of the fact dimension.
        data: Descriptor of the data dimension.
        activities: List of activities to run.
    """

    def __init__(self, dictionary: dict):
        """
        Class constructor.

        Args:
            dictionary: Object dictionary representation.
        """
        self.read: Read = Read(dictionary.get("read", {}))
        self.write: Write = Write(dictionary.get("write", {}))
        self.market: Descriptor = Descriptor(dictionary.get("market", {}))
        self.product: Descriptor = Descriptor(dictionary.get("product", {}))
        self.period: Descriptor = Descriptor(dictionary.get("period", {}))
        self.fact: Descriptor = Descriptor(dictionary.get("fact", {}))
        self.data: Descriptor = Descriptor(dictionary.get("data", {}))
        self.activities: list = [Activity(d) for d in dictionary.get("activities", [])]

    def get_path_dimensions(self, directory: str) -> dict:
        store = {
            "market": get_paths(directory, self.market.pattern),
            "product": get_paths(directory, self.product.pattern),
            "period": get_paths(directory, self.period.pattern),
            "fact": get_paths(directory, self.fact.pattern),
            "data": get_paths(directory, self.data.pattern),
        }

        for key in store.keys():
            if len(store[key]) == 0:
                raise Exception(f"No file matched by {key} in {directory}")
            elif len(store[key]) > 1:
                raise Exception(f"More than one file matched by {key} in {directory}")
            else:
                store[key] = store[key][0]

        res = defaultdict(list)
        for key, val in sorted(store.items()):
            res[val].append(key)

        store_reversed = res

        if len(store_reversed.keys()) == 1:
            key = list(store_reversed.keys())[0]
            if "data" not in store_reversed[key]:
                store_reversed[key].append("data")

        return store_reversed
