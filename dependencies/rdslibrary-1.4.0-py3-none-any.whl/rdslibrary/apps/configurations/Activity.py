class Activity:
    """
    Class to represent an activity in `rds_apply_services`.

    Attributes:
        dimension: Dimension to apply services on, can be `"market"`, `"product"`, `"period"`, `"fact"`, `"data"`, `"schema"`.
        services: List of parameterized services to apply to the dimension.
    """

    def __init__(self, dictionary: dict):
        """
        Class constructor.

        Args:
            dictionary: Object dictionary representation.
        """
        self.dimension: str = dictionary.get("dimension", "schema")
        self.services: list = dictionary["services"]
