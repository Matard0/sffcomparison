from typing import List, Union


class Auditer:
    """
    Class to represent audit calls.

    Attributes:
        product_audits_to_skip: List of product hierarchy audits that have been requested to be skipped.
        audit_total_market: A dictionary containing the market hierrachy column and the label of the total market in this hierarchy. Defaults to {"column": "Level", "value": "Total"}.
    """

    def __init__(self, audits: dict):
        """
        Class constructor.

        Args:
            audits: Object dictionary representation.
        """
        self.product_audits_to_skip: Union[List[str], bool] = self.verify_products_audits_to_skip(
            audits
        )
        self.audit_total_market: Union[dict, bool] = audits.get(
            "audit_total_market", {"column": "Level", "value": "Total"}
        )
        self.sprint_config_checks_to_skip: Union[List[str], bool] = self.verify_checks_to_skip(
            audits
        )

    def verify_checks_to_skip(self, audits: dict) -> List[str]:
        """Function to validate that checks that have been requested to be skipped are part of those that we run

        Args:
            audits: the dictionary representing the audits part of the etl config.

        Raises:
            ValueError: when a check has been requested to be skipped does not exist

        Returns:
            checks_to_skip: a potentially empty list of strings that correspond to valid SPRINT config validation checks
        """
        expected_checks = [
            "check_SPRINT_config",
            "check_columns_in_product",
            "check_columns_in_market",
            "check_columns_in_data",
            "check_total_tag_in_market",
            "check_total_tag_in_product",
            "check_full_product_hierarchy_value",
            "check_full_market_hierarchy_value",
            "check_years_available",
            "check_periodicity",
            "check_aggregated_periods",
        ]
        for check_to_skip in audits.get("sprint_config_checks_to_skip", []):
            if check_to_skip not in expected_checks:
                raise ValueError(
                    f"There is an error in the configuration. '{check_to_skip}' is not an expected value.\n"
                    f"The expected values are {expected_checks}"
                )
        return audits.get("sprint_config_checks_to_skip", [])

    def verify_products_audits_to_skip(self, audits: dict) -> List[str]:
        """Function to validate that product hierarchy audits that have been requested to be skipped are part of those that we run

        Args:
            audits: the dictionary representing the audits part of the etl config.

        Raises:
            ValueError: when an audit has been requested to be skipped, but does not exist

        Returns:
            product_audits_to_skip: a potentially empty list of strings that correspond to product audits to skip
        """
        expected_audits = [
            "hierarchy_root_is_unique",
            "hierarchy_coherence_with_chain",
            "hierarchy_level_name_columns_exist",
            "hierarchy_chains_integrity",
            "hierarchy_level_name_columns_are_populated",
        ]
        for audit in audits.get("product_audits_to_skip", []):
            if audit not in expected_audits:
                raise ValueError(
                    f"There is an error in the configuration. '{audit}' is not an expected value.\n"
                    f"The expected values are {expected_audits}"
                )
        return audits.get("product_audits_to_skip", [])
