from typing import Union


class Read:
    """
    Class to represent a read configuration in `rds_transform_tables` or `rds_apply_services`.

    Attributes:
        dimension_patterns: Dictionary of dimension patterns.
        method: Method to use to read.
        parameters: Read parameters.
    """

    def __init__(self, dictionary: dict):
        """
        Class constructor.

        Args:
            dictionary: Object dictionary representation.
        """
        dimension_patterns = dictionary.get("dimension_patterns", {})
        self.dimension_patterns: dict[str, Union[str, bool]] = {
            "market": dimension_patterns.get("market", "*MKT*"),
            "product": dimension_patterns.get("product", "*PROD*"),
            "period": dimension_patterns.get("period", "*PER*"),
            "fact": dimension_patterns.get("fact", "*FCT*"),
            "data": dimension_patterns.get("data", "*DATA*"),
        }

        self.method: str = dictionary.get("method", "mount")

        parameters = dictionary.get("parameters", {})
        self.parameters: dict[str, Union[str, bool]] = {
            "sep": parameters.get("sep", ","),
            "encoding": parameters.get("encoding", "UTF-8"),
            "search_enriched": parameters.get("search_enriched", True),
            "apply_special_cases_on_read": parameters.get("apply_special_cases_on_read", True),
            "case_sensitive": parameters.get("case_sensitive", True),
            "regex_to_replace_from_column_names": parameters.get(
                "regex_to_replace_from_column_names", r"\.|`|\s$"
            ),
        }
