from typing import Union


class Write:
    """
    Class to represent a write configuration in `rds_transform_tables` or `rds_apply_services`.

    Attributes:
        dimension_names: Dictionary of dimension names.
        method: Method to use to write.
        parameters: Write parameters.
    """

    def __init__(self, dictionary: dict):
        """
        Class constructor.

        Args:
            dictionary: Object dictionary representation.
        """
        dimension_names = dictionary.get("dimension_names", {})
        self.dimension_names: dict[str, Union[str, bool]] = {
            "market": dimension_names.get("market", "MKT"),
            "product": dimension_names.get("product", "PROD"),
            "period": dimension_names.get("period", "PER"),
            "fact": dimension_names.get("fact", "FCT"),
            "data": dimension_names.get("data", "FACT_DATA"),
        }
        # Warning: the default name for the data dimension is "FACT_DATA" whereas the default of
        # the write function is "DATA".

        self.method: str = dictionary.get("method", "mount")

        parameters = dictionary.get("parameters", {})
        self.parameters: dict[str, Union[str, bool]] = {
            "sep": parameters.get("sep", ","),
            "encoding": parameters.get("encoding", "UTF-8"),
            "mode": parameters.get("mode", "csv_data_bzip2_compressed"),
            "prefix": parameters.get("prefix", None),
        }
