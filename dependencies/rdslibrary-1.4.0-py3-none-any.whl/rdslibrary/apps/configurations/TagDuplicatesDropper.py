class TagDuplicatesDropper:
    """
    Class to represent tag duplicates dropping calls.

    Attributes:
        market: Run drop duplicates on market dimension.
        product: Run drop duplicates on product dimension.
        period: Run drop duplicates on period dimension.
        data: Run drop duplicates on data dimension.
    """

    def __init__(self, dictionary: dict):
        """
        Class constructor.

        Args:
            dictionary: Object dictionary representation.
        """
        self.market: bool = dictionary.get("market", False)
        self.product: bool = dictionary.get("product", False)
        self.period: bool = dictionary.get("period", False)
        self.data: bool = dictionary.get("data", False)
