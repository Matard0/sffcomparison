from typing import Union


class Descriptor:
    """
    Class to represent a dimension configuration in `rds_transform_tables`.

    Attributes:
        pattern: Wildcard pattern to select the dimension file in a directory.
        columns: Columns to select in the dimension loaded table.
        tag: Columns to create a tag from in the dimension loaded table.
        services: List of services to apply.
        tag_translation: Information to translate the tags between the meta and data tables.
    """

    def __init__(self, dictionary: dict):
        """
        Class constructor.

        Args:
            dictionary: Object dictionary representation.
        """
        self.pattern: str = dictionary.get("pattern", "*")
        self.columns: Union[list, str] = dictionary.get("columns", None)
        self.tag: Union[list, str] = dictionary.get("tag", None)
        self.services: list = dictionary.get("services", [])
        self.tag_translation: dict = dictionary.get("tag_translation", None)
