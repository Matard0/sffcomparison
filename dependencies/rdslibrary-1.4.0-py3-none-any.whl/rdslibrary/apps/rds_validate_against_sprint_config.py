from typing import List, Optional

import requests
from py4j.protocol import Py4JJavaError
from rdslibrary.utilities.spark import get_dbutils, get_spark

spark = get_spark()
dbutils = get_dbutils(spark)


def check_period_dimension(
    sch, configuration: dict, checks_to_skip: List[str], errors_raised: List, logger
) -> List:
    """Runs the Period dimension checks for SPRINT config validation.

    Args:
        sch: rds.core.schema.Schema object of the Redslim SFF
        configuration: a dictionary containing details of the SPRINT config
        checks_to_skip: a list of checks that should not be run
        errors_raised: a list, potentially containing any errors that have already been raised so far,
        logger: a python logger object to use for logging

    Returns:
        errors_raised: a list of errors that may have been raised by these checks including any that were included before these checks
    """
    # check that the number of years available is correct
    if "check_years_available" not in checks_to_skip:
        logger.info(
            "Checking that the number of years available in the period dimension is correct."
        )
        try:
            sch.period.audit_years_available(
                ranks_per_year=configuration["period"]["countPerYear"],
                expected_years=configuration["period"]["nbOfYear"],
            )
        except ValueError as err:
            errors_raised.append(err)

    # check that the periodicity is correct
    if "check_periodicity" not in checks_to_skip:
        logger.info("Checking that the periodicity of the period dimension is correct.")
        try:
            sch.period.audit_periodicity(
                expected_periodicity=configuration["period"]["periodicity"],
                full_years=configuration["period"]["nbOfYear"],
            )
        except ValueError as err:
            errors_raised.append(err)

    # check that prefixes for aggregated periods are present
    if "check_aggregated_periods" not in checks_to_skip:
        if configuration["period"]["aggregatedPeriodPrefix"]:
            logger.info(
                "Checking that the pre-aggregated periods are present in the period dimension."
            )
            try:
                sch.period.audit_pre_aggregated_periods(
                    pre_aggregated_periods=configuration["period"]["aggregatedPeriodPrefix"],
                    full_years=configuration["period"]["nbOfYear"],
                )
            except ValueError as err:
                errors_raised.append(err)
    return errors_raised


def raise_errors(errors_raised: List[str], logger):
    """Function to assemble any errors that may have been raised and raise these as a single error to the user.

    Args:
        errors_raised: a list, potentially containing any errors that have already been raised so far,
        logger: a python logger object to use for logging

    Raises:
        ValueError: if any of the SPRINT config validation checks fail. It then lists the failures.
    """
    if len(errors_raised) == 1:
        raise ValueError(
            f"SPRINT Config validation has raised the following errors:\n{errors_raised[0]}"
        )
    elif errors_raised:
        errors_raised = "\n".join([str(err) for err in errors_raised])
        raise ValueError(
            f"SPRINT Config validation has raised the following errors:\n{errors_raised}"
        )
    else:
        logger.info("SPRINT config validation passed without error.")


def validate_against_sprint_config(
    database: str, logger, sch, checks_to_skip: Optional[List[str]] = []
):
    """
    Validates a rds.core.schema.Schema object representing a Redslim SFF against its' config in SPRINT.

    Args:
        database: name of the database to be validated
            e.g. "MWNCCSA"
        sch: rds.core.schema.Schema object of the Redslim SFF

    Raises:
        ValueError: if any of the SPRINT config validation checks fail. It then lists the failures.
    """
    # fetch the config from the SPRINT API
    try:
        # Note databricks.secrets.get will not work in databricks-connect
        sprint_cache_login_password = dbutils.secrets.get("testscope", "sprintstagecredential")
    except Py4JJavaError:
        # when we are using databricks connect, get the password from an environment variable
        import os

        sprint_cache_login_password = os.getenv("SPRINTloginpassword")

    with requests.Session() as sesh:
        sesh.post(
            url="https://sprint.redslim.net/Account/SprintLoginConfirm",
            data={
                "Email": "autoloader@redslim.net",
                "Password": sprint_cache_login_password,
            },
        )
        response = sesh.get(
            url=f"https://sprint.redslim.net/Admin/GetDatabaseConfig?dbName={database}"
        )
    configuration = response.json()

    logger.info(f"configuration fetched from SPRINT is {configuration}.")
    errors_raised = []

    dimensions_to_check = ["product", "market", "data"]
    for dimension in [
        check.split("_")[-1] for check in checks_to_skip if check.startswith("check_columns_in_")
    ]:
        dimensions_to_check.remove(dimension)
    # check columns are present in each of product, market and data if they are not specified to skip
    logger.info(f"Checking the correct columns are present in {dimensions_to_check}")
    for dimension in dimensions_to_check:
        expected_columns = configuration[dimension]["otherColumns"]
        if dimension in ["product", "market"]:
            expected_columns += [
                configuration[dimension]["tagColumn"],
                configuration[dimension]["hierarchyColumn"],
            ]
        elif dimension == "data":
            expected_columns += [
                configuration[dimension]["periodColumn"],
                configuration[dimension]["productColumn"],
                configuration[dimension]["marketColumn"],
            ]
        if not all(item in sch.__getattribute__(dimension).df.columns for item in expected_columns):
            missing_columns = set(expected_columns) - set(
                sch.__getattribute__(dimension).df.columns
            )
            errors_raised.append(
                f"Columns are missing in the {dimension} dimension. Missing columns are :\n {missing_columns}"
            )

    # check total tag is present in the market and product dimensions if not to be skipped
    if "check_total_tag_in_market" not in checks_to_skip:
        logger.info("Checking the total tag is present in the market dimension.")
        try:
            sch.market.audit_value_in_column(
                configuration["market"]["tagColumn"],
                configuration["market"]["totalTag"],
            )
        except ValueError as err:
            errors_raised.append(err)
    if "check_total_tag_in_product" not in checks_to_skip:
        logger.info("Checking the total tag is present in the product dimension.")
        try:
            sch.product.audit_value_in_column(
                configuration["product"]["tagColumn"],
                configuration["product"]["totalTag"],
            )
        except ValueError as err:
            errors_raised.append(err)

    # check full product/market hierarchy value is present in the hierarchy column
    if "check_full_product_hierarchy_value" not in checks_to_skip:
        if configuration["product"]["hierarchyColumn"]:
            logger.info(
                "Checking the full product hierarchy value is present in the hierarchy column."
            )
            try:
                sch.product.audit_value_in_column(
                    configuration["product"]["hierarchyColumn"],
                    configuration["product"]["hierarchyValue"],
                    require_unique=False,
                )
            except ValueError as err:
                errors_raised.append(err)
    if "check_full_market_hierarchy_value" not in checks_to_skip:
        if configuration["market"]["hierarchyColumn"]:
            logger.info(
                "Checking the full market hierarchy value is present in the hierarchy column."
            )
            try:
                sch.market.audit_value_in_column(
                    configuration["market"]["hierarchyColumn"],
                    configuration["market"]["hierarchyValue"],
                    require_unique=False,
                )
            except ValueError as err:
                errors_raised.append(err)

    # run the period dimension SPRINT config validation checks in a separate function for simplicity
    errors_raised = check_period_dimension(
        sch, configuration, checks_to_skip, errors_raised, logger
    )

    # run the raise_errors function to raise any errors that may have occured during the above checks
    raise_errors(errors_raised, logger)
