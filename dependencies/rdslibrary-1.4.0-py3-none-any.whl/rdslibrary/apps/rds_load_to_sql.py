import logging
import re
import sys
from typing import Union

from rdslibrary.apps.configurations.Configuration import Configuration
from rdslibrary.core.schema import Schema
from rdslibrary.utilities.functions import read_json
from rdslibrary.utilities.spark import get_dbutils, get_spark

spark = get_spark()
dbutils = get_dbutils(spark)
con = None
logger = None


def execute_query(query):
    global con
    global logger
    stmt = con.createStatement()
    try:
        stmt.executeUpdate(query)
        con.commit()
        stmt.close()
        logger.info(f"Successfully executed: {query}")
    except Exception as exc:
        stmt.close()
        con.rollback()
        logger.error(f"Failed to execute: {query}")
        raise Exception(exc)


def setup_connection(sql_server: str):
    """Populates a connection_properties dictionary

    Currently setup to work on a cluster with the following setup:
        Databricks Runtime Version 6.4 (Apache Spark 2.4.5, Scala 2.11)
        Worker Type Standard_DS3_v2
        com.microsoft.azure:spark-mssql-connector:1.0.1 Connector installed

    Args:
        sql_server: Specify whether to load into the "sprint",
            or the "azure-test" SQL Server instance

    Returns:
        con: Connection object for querying the SQL Server
        connection_properties: Dictionary of some configuration properties of the SQL Server

    Raises:
        ValueError: If the configuration path does not exist.
    """
    # Setup Database connection config
    if sql_server == "sprint":
        jdbc_hostname = "cw80lej3ji.database.windows.net"
        jdbc_database = "rdsmmwebsql"
        jdbc_port = 1433
        rdsmmadmin_password = dbutils.secrets.get("testscope", "rdsmmadminpasswordsprint")
    elif sql_server == "azure-test":
        jdbc_hostname = "wenl-rdsm-00-asa-sqlserver.database.windows.net"
        jdbc_database = "wenl-rdsm-00-asa-sql-01"
        jdbc_port = 1433
        rdsmmadmin_password = dbutils.secrets.get("testscope", "rdsmmadminforazuresql")
    else:
        raise ValueError(f"sql_server parameter '{sql_server}' is not valid.")

    jdbc_url = f"jdbc:sqlserver://{jdbc_hostname}:{jdbc_port};database={jdbc_database}"
    connection_properties = {
        "user": "RDSMMAdmin",
        "password": rdsmmadmin_password,
        "url": jdbc_url,
    }
    # Initialise Database connection for queries
    driver_manager = spark._sc._gateway.jvm.java.sql.DriverManager
    con = driver_manager.getConnection(
        jdbc_url, connection_properties["user"], connection_properties["password"]
    )
    con.setAutoCommit(False)
    return con, connection_properties


def main(
    sch: Schema,
    configuration: Union[str, dict],
    database_name,
    sql_server: str = "sprint",
    partition_column_name: str = "PERIOD_TAG",
):
    """Loads a database schema object into the SQL Server Instance specified
    using Clustered Columnstore Index for the meta dimensions, and a partitioned
    clustered columnstore index for the FACT_DATA dimension.

    Currently setup to work on a cluster with the following setup:
        Databricks Runtime Version 6.4 (Apache Spark 2.4.5, Scala 2.11)
        Worker Type Standard_DS3_v2
        com.microsoft.azure:spark-mssql-connector:1.0.1 Connector installed

    Args:
        sch: azrdslibrary Schema object representing the database
        database_name: String of the name of the database
            e.g. DANOVEG
        sql_server: Specify whether to load into the "sprint",
            or the "azure-test" SQL Server instance
        configuration: Path to the configuration file or configuration dictionary
            specific to the application.
        partition_column_name: the name of the column in FACT_DATA which is to be used for partitioning
            e.g. "PERIOD_TAG"

    Raises:

    """
    # Initialize logger
    logging.basicConfig(
        stream=sys.stdout,
        level=logging.DEBUG,
        format="%(asctime)s - %(levelname)s - %(message)s",
    )
    logging.getLogger("py4j").setLevel(logging.ERROR)  # Limit cluster logging
    logger = logging.getLogger(__name__)

    logger.info("Beginning load to SQL Server Process.")

    # Parse configuration
    if isinstance(configuration, str):
        configuration = read_json(configuration)
        configuration = configuration["rds_load_to_sql"]
    else:
        pass

    configuration = Configuration(configuration)

    # Setup a connection to our SQL Server
    con, connection_properties = setup_connection(sql_server)

    # WARNING! The get_all_table_creation_string method no longer includes statements to create tables with clustered columnstore index
    table_names = configuration["table_names"]
    for table in table_names:
        table_names[table] = {
            "new": f"NEW_{table_names[table]}",
            "current": table_names[table],
            "old": f"OLD_{table_names[table]}",
        }
    sql_table_schemas = sch.get_all_table_creation_strings(table_names)

    query = ""
    # Prepare the statements for the meta tables
    for dimension in ["period", "market", "fact", "product"]:
        # drop NEW_ table if it exists
        query += f"DROP TABLE IF EXISTS dbo.{table_names[dimension]['new']};"
        # create NEW_ table
        query += sql_table_schemas[dimension]
        # drop the NEW_ data table if it exists
        query += f"DROP TABLE IF EXISTS dbo.{table_names['data']['new']};"
    execute_query(query)
    # calculate the max length of the partition_column field for use in creating the partition function
    tag_length = re.findall(
        rf"\[{partition_column_name}\] \[varchar\]\((\d+)\)", sql_table_schemas["data"]
    )[0]
    # calculate a list of the possible partition_column values
    partition_values = ",".join(
        ["'" + each["TAG"] + "'" for each in sch.period.df.select("TAG").distinct().collect()]
    )
    # drop the existing clustered columnstore index on the DATA table
    execute_query(
        f"DROP INDEX IF EXISTS cc_{database_name} ON [dbo].[{table_names['data']['current']}];"
    )
    # unpartition the existing DATA table by replacing it with a new unpartitioned index
    execute_query(
        f"CREATE CLUSTERED INDEX cc_{database_name} ON [dbo].[{table_names['data']['current']}]({partition_column_name}) ON [PRIMARY];"
    )
    query = ""
    # drop the existing partition scheme
    query += f"DROP PARTITION SCHEME {database_name}_PS;"
    # # drop the existing partition function
    query += f"DROP PARTITION FUNCTION {database_name}_PF;"
    # create the new partition function for the DATA table
    query += f"CREATE PARTITION FUNCTION [{database_name}_PF] (varchar({tag_length})) AS RANGE RIGHT FOR VALUES ({partition_values});"
    # create the new partition scheme for the DATA table
    query += f"CREATE PARTITION SCHEME [{database_name}_PS] AS PARTITION [{database_name}_PF] ALL TO ([PRIMARY]);"
    # create the new DATA table with a clustered columnstore index and partitioned on the partition_column_name
    query += sql_table_schemas["data"]
    execute_query(query)
    sch.data.df.orderBy(partition_column_name)

    # actual loading
    for dimension in ["period", "market", "fact", "product", "data"]:
        # Load the data to the NEW_table
        sch.__getattribute__(dimension).df.write.format("com.microsoft.sqlserver.jdbc.spark").mode(
            "append"
        ).option("url", connection_properties["url"]).option(
            "dbtable", table_names[dimension]
        ).option(
            "user", connection_properties["user"]
        ).option(
            "password", connection_properties["password"]
        ).option(
            "tableLock", "false"
        ).option(
            "batchsize", "1048576"
        ).save()

    query = ""
    for dimension in ["period", "market", "fact", "product", "data"]:
        # drop OLD_ table if it exists
        query += f"DROP TABLE IF EXISTS dbo.{table_names[dimension]['old']};"
        # rename the existing table to the OLD_ table
        query += f"EXEC sp_rename '{table_names[dimension]['current']}', '{table_names[dimension]['old']}';"
        # rename the NEW_ table to the existing table
        query += (
            f"EXEC sp_rename '{table_names[dimension]['new']}', '{table_names[dimension]['old']}';"
        )
    execute_query(query)

    query = ""
    for dimension in ["period", "market", "fact", "product", "data"]:
        # drop the OLD_ table if it exists
        query += f"DROP TABLE IF EXISTS dbo.{table_names[dimension]['old']};"
    execute_query(query)
