var comparison_dimensions = NaN;
var ignored_dimensions = NaN;

var table_html_string = NaN;
var report_table = NaN;
var groups_lengths = NaN;

var specific_rows_expected = NaN;
var specific_rows_actual = NaN;
var number_of_columns_expected = NaN;
var number_of_columns_difference = NaN;
var number_of_columns_actual = NaN;
var total_number_expected = NaN;
var total_number_actual = NaN;
var number_of_distinct_difference = NaN;

var actual_path = NaN;
var output_path = NaN;
var expected_path = NaN;
var latest_period_expected = NaN;
var latest_period_actual = NaN;

$( document ).ready(function() {
  $("#expected_path")[0].innerHTML = expected_path;
  $("#output_path").hide();
  $("#output_path")[0].innerHTML = output_path;
  $("#actual_path")[0].innerHTML = actual_path;
  $("#latest_period_expected")[0].innerHTML = latest_period_expected;
  $("#latest_period_actual")[0].innerHTML = latest_period_actual;

  if (comparison_dimensions.includes('period') || comparison_dimensions.includes('data'))
  {
    $("#latest_row").show();
    $("#latest_divider").show();
  } 
  else 
  {
    $("#latest_row").hide();
    $("#latest_divider").hide();
  };

  ignored_dimensions.forEach(function(item) {
    $("#"+item+"_row").hide();
    $("#"+item+"_divider").hide();
  });
  
  display_dimension(comparison_dimensions[0]);
});


$("#market_row").click(function(){display_dimension("market")});
$("#product_row").click(function(){display_dimension("product")});
$("#fact_row").click(function(){display_dimension("fact")});
$("#period_row").click(function(){display_dimension("period")});
$("#data_row").click(function(){display_dimension("data")});

$("#report_row").click(function(){display_report()});
$("#latest_row").click(function(){display_latest()});


$('table').scroll( function() {
  var translate = "translate(0,"+$(this).scrollTop()+"px)";
  $("table:not('.secret') thead")[0].style.transform = translate;
});

function display_dimension(dimension){

  $("#cards-wrapper").show();
  $("#report-wrapper").hide();
  $("#latest_periods").hide();
  
  change_color(dimension);

  resize_table();

  fill_values(dimension);

  group_table_rows(dimension)
  
};

function display_report(){

  $("#cards-wrapper").hide();
  $("#report-wrapper").show();
  $("#latest_periods").hide();
  
  change_color('report');

  resize_report ();

  $("#cards-wrapper").hide();

  fill_values('report')

};

function display_latest(){

    $("#latest_periods").toggle();
    change_color('latest');
};

function change_color(name){
    $(".nav-item").each(function() { 
        $(this).removeClass("active-row");
        $(this).find("i")[0].removeAttribute("style");
        $(this).find("i").removeClass("rotate-n-15");
    });

    $("#"+name+"_icon")[0].setAttribute('style', 'color: var(--background_color);')
    $("#"+name+"_row").addClass("active-row");
    $("#"+name+"_icon").addClass('rotate-n-15')
}


function resize_table () { 
  header = $(".table")[0].getBoundingClientRect().top-$("#content-wrapper")[0].getBoundingClientRect().top
  footer = $("#content-wrapper")[0].getBoundingClientRect().bottom-$("table")[0].getBoundingClientRect().bottom
  height = $(".sidebar")[0].getBoundingClientRect().height
  $(".table")[0].style.maxHeight = height-(header+footer+17)+'px'
};

function resize_report () { 
  header = $("#report-wrapper")[0].getBoundingClientRect().top-$("#content-wrapper")[0].getBoundingClientRect().top
  footer = $("#content-wrapper")[0].getBoundingClientRect().bottom-$("#report-wrapper")[0].getBoundingClientRect().bottom
  height = $(".sidebar")[0].getBoundingClientRect().height
  $("#report-wrapper")[0].style.maxHeight = height-(header+footer)+'px'
};


function fill_values(dimension){
  if (dimension === 'report'){
      $(".table")[0].innerHTML = report_table;
      $(".table").addClass('no-side-border')
  }
  else{
      $("#specific_rows_text")[0].innerHTML = 'Number of specific ' + dimension + 's';
      $("#number_of_columns_text")[0].innerHTML = 'Number of columns';
      $("#total_number_text")[0].innerHTML = 'Total number of ' + dimension + 's';
      $("#number_of_distinct_text")[0].innerHTML = 'Number of different rows';

      $("#specific_rows_expected")[0].innerHTML =  specific_rows_expected [dimension]
      $("#specific_rows_actual")[0].innerHTML =  specific_rows_actual [dimension]
      $("#number_of_columns_expected")[0].innerHTML =  number_of_columns_expected [dimension]
      $("#number_of_columns_difference")[0].innerHTML =  number_of_columns_difference [dimension]
      $("#number_of_columns_actual")[0].innerHTML =  number_of_columns_actual [dimension]
      $("#total_number_expected")[0].innerHTML =  total_number_expected [dimension]
      $("#total_number_actual")[0].innerHTML =  total_number_actual [dimension]
      $("#number_of_distinct_difference")[0].innerHTML =  number_of_distinct_difference [dimension]
      $("#total_number_expected")[0].innerHTML =  total_number_expected [dimension]
      $("#total_number_actual")[0].innerHTML =  total_number_actual [dimension]

      $(".table")[0].innerHTML = table_html_string[dimension];
      $(".table").removeClass('no-side-border')
  }
}

function group_table_rows(dimension){
  $(".grp").prepend("<td class='arrow' onclick=collapse('all','"+dimension+"')><i class='fas fa-chevron-right'></i></td>");
  $(".grpNone").prepend("<td class='empty_cell'></td>"); 
  for (let id in groups_lengths[dimension]) {
    $('.'+id+':first').removeClass('secret').addClass('displayed_arrow')
    $('.'+id+':not(:first)').addClass('secret')
    $(".displayed_arrow."+id).prepend("<td class='arrow' onclick=collapse('"+id+"','"+dimension+"')><i class='fas fa-chevron-right'></i></td>");
  }      
}
function collapse(id, dim){
  if(id === 'all'){
    if ($(".grp .arrow")[0].innerHTML === '<i class="fas fa-chevron-right"></i>'){
      $(".grp .arrow")[0].innerHTML = '<i class="fas fa-chevron-down"></i>';
      for (let id in groups_lengths[dim]) {
        down(id, dim)
      };
    }
    else {
      ($(".grp .arrow")[0].innerHTML = '<i class="fas fa-chevron-right"></i>')
      for (let id in groups_lengths[dim]) {
        right(id, dim)
      };
    }    
  } else {
    if ($(".displayed_arrow."+id+" .arrow")[0].rowSpan===1){
      down(id, dim)
    } else {
      right(id, dim)
    }
  };
}

function down(id, dim){
  $(".displayed_arrow."+id+" .arrow")[0].rowSpan = groups_lengths[dim][id]
  $(".displayed_arrow."+id+" .arrow")[0].innerHTML = "<i class='fas fa-chevron-down'></i>";
  $("."+id+'.secret').removeClass('secret').addClass('raised');
}

function right(id, dim){
  $(".displayed_arrow."+id+" .arrow")[0].rowSpan = 1
  $(".displayed_arrow."+id+" .arrow")[0].innerHTML = "<i class='fas fa-chevron-right'></i>";
  $("."+id+'.raised').removeClass('raised').addClass('secret');
  $(".grp .arrow")[0].innerHTML = '<i class="fas fa-chevron-right"></i>';
}