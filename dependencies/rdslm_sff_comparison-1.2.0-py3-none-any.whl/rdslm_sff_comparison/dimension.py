from copy import deepcopy
from functools import reduce
from typing import Optional

import pyspark.sql.functions as F
import pyspark.sql.types as T
from pyspark.sql.types import StringType, StructField, StructType
from rdslibrary.utilities.spark import get_spark
from rdslm_sff_comparison.utilities.utilities import (
    compare_list,
    duplicates_single_values,
    group_table,
    html_cell_string,
    match_columns_lists,
    sort_columns,
    sort_list,
)

spark = get_spark()


class dimension:
    """Class computing the difference of two dimensions.

    Attributes:
        type: String that defines the classe of the two dimensions e.g. `"market"` for Market dimension.
        expected_df: Dataframe of the MetaData or Data object from the expected files.
        actual_df: Dataframe of the MetaData or Data object from the actual files.
        ignore_columns: Columns to ignore for the comparison.
        cols: Columns on which the match between the two dimensions is made.
        facts: Fact columns if the comparison is on Data dimension.
        columns: Common columns of the expected and actual dimensions.
        df_difference: Dataframe of the different rows between the two dimensions.
        dimension_calculations: Dictionnary to store values that will be displayed in the frontend.
        pdf: Pandas dataframe of the difference between the dimensions.
        strings_table: Table of corresponding color class for each cell.
    """

    def __init__(self, dim_expected, dim_actual, ignore_columns):
        """Class constructor.

        Args:
            dim_expected: MetaData or Data object from the expected files.
            dim_actual: MetaData or Data object from the actual files.
            ignore_columns: List of columns to ignore for the comparison of the dimension eg `['SHORT','LONG','HIER_NUM']`..

        Raises:
            ValueError: If the two dimensions do not have similar types.
        """

        # Check that dimensions have similar types
        if dim_expected.__class__ != dim_actual.__class__:
            raise ValueError(
                f"Different types detected, expected is {dim_expected.__class__} and actual is {dim_actual.__class__}."
            )

        # Defines the classe of the two dimensions
        self.type = str(dim_expected.__class__).split(".")[-1][:-2].lower()

        self.expected_df = dim_expected.df
        self.actual_df = dim_actual.df
        self.ignore_columns = ignore_columns

        # Columns on which the match between the two dimensions is made depending if they are Meta or Data dimensions
        self.cols = ["TAG"] * (1 - (self.type == "data")) + [
            "MARKET_TAG",
            "PRODUCT_TAG",
            "PERIOD_TAG",
        ] * (self.type == "data")

        # Check that ignored columns are not necessary for the comparison
        self.ignore_columns = [
            col for col in self.ignore_columns if col not in self.cols
        ]

        # Creates a dictionnary to store values that will be displayed in the frontend
        self.dim_calculations = {"report": {}, "cards": {}}
        self.dim_calculations["cards"]["number_of_columns_expected"] = len(
            self.expected_df.columns
        )
        self.dim_calculations["cards"]["number_of_columns_actual"] = len(
            self.actual_df.columns
        )
        self.dim_calculations["cards"][
            "total_number_expected"
        ] = self.expected_df.count()
        self.dim_calculations["cards"]["total_number_actual"] = self.actual_df.count()

        # Calculate the tags that are in the dimension if it is a Meta dimension
        if not self.type == "data":
            list_expected = set(self.expected_df.select(["TAG"]).toPandas()["TAG"])
            list_actual = set(self.actual_df.select(["TAG"]).toPandas()["TAG"])
            self.dim_calculations["report"]["tags"] = list_expected, list_actual

        # Calculates the latest_period if we have Data or Period dimensions
        if self.type in ["data", "period"]:
            col_name = "PERIOD_" * (self.type == "data") + "TAG"
            latest_expected = (
                # self.expected_df.where(F.col(col_name).rlike("P(\\d{4})(\\d{2})"))
                self.expected_df.agg({col_name: "max"}).first()[0]
            )
            latest_actual = self.actual_df.agg({col_name: "max"}).first()[0]
            self.dim_calculations["report"]["latest_periods"] = (
                latest_expected,
                latest_actual,
            )

    def select_columns(self):
        """Drops columns to ignore and select the common columns in the two dimensions"""

        # Affects calculated values for the report table to the dictionnary 'self.dim_calculations'
        self.dim_calculations["report"]["ignored_columns"] = set(
            self.expected_df.columns
        ) & set(self.ignore_columns), set(self.actual_df.columns) & set(
            self.ignore_columns
        )

        # Drop columns to ignore
        self.expected_df = self.expected_df.select(
            [c for c in self.expected_df.columns if c not in self.ignore_columns]
        )
        self.actual_df = self.actual_df.select(
            [c for c in self.actual_df.columns if c not in self.ignore_columns]
        )

        # Select the specific columns and affect them to the report table dictionnary
        set_expected_columns = set(self.expected_df.columns)
        set_actual_columns = set(self.actual_df.columns)

        specific_columns_expected = set_expected_columns - set_actual_columns
        specific_columns_actual = set_actual_columns - set_expected_columns

        self.dim_calculations["report"]["specific_columns"] = (
            specific_columns_expected,
            specific_columns_actual,
        )

        # Select in both dataframes the common columns of the two tables
        set_common_columns = set_expected_columns & set_actual_columns
        self.columns = [
            col for col in self.expected_df.columns if col in set_common_columns
        ]
        self.expected_df = self.expected_df.select(self.columns)
        self.actual_df = self.actual_df.select(self.columns)

    def match_columns_table(self):
        """Adds for Meta dimension comparison, a dataframe with the corresponding similar tags in the actual dimension to each expected dimension tags."""

        # Verifies that we have Meta dimension and not too much values
        if not (self.type == "data"):
            if self.expected_df.count() * self.actual_df.count() < 10000:

                # Creates the structure of the matching dataframe
                schema = StructType(
                    [
                        StructField("TAG_WORD", StringType(), True),
                        StructField("TAG_MATCH", StringType(), True),
                    ]
                )

                # Creates the matching dataframe: the column 'TAG_WORD' is populated with the expected dimension tags
                # and the column 'TAG_MATCH' with the corresponding similar tags in the actual dimension
                df1, df2 = (
                    self.expected_df.select(["TAG"]).toPandas()["TAG"],
                    self.actual_df.select(["TAG"]).toPandas()["TAG"],
                )
                similar_tags = match_columns_lists(df1, df2, 0.8)
                df_matchs = spark.createDataFrame(similar_tags, schema=schema)

            else:
                # We have too much values the match is made on equality and not on similarity between the tags
                df_matchs = self.actual_df.select(
                    [F.col("TAG").alias(c) for c in ["TAG_WORD", "TAG_MATCH"]]
                )

            expression = self.expected_df["TAG"] == df_matchs["TAG_WORD"]
            self.expected_df = self.expected_df.join(df_matchs, expression, how="left")

    def rename_columns(self):
        """Rename actual and expected columns."""

        # Rename actual and expected columns
        if self.type == "data":
            # Renames the Data columns and changes the type of fact columns
            self.facts = [c for c in self.columns if c not in self.cols]
            self.expected_df = self.expected_df.select(
                [F.col(c).alias(c + "_EXPECTED") for c in self.cols]
                + [
                    F.col(c).cast(T.DoubleType()).alias(c + "_EXPECTED")
                    for c in self.facts
                ]
            )
            self.actual_df = self.actual_df.select(
                [F.col(c).alias(c + "_ACTUAL") for c in self.cols]
                + [
                    F.col(c).cast(T.DoubleType()).alias(c + "_ACTUAL")
                    for c in self.facts
                ]
            )
        else:
            # Renames the Meta Data columns
            self.expected_df = self.expected_df.select(
                [F.col(c).alias(c + "_EXPECTED") for c in self.columns] + ["TAG_MATCH"]
            )

            self.actual_df = self.actual_df.select(
                [F.col(c).alias(c + "_ACTUAL") for c in self.columns]
            )

    def calculate_difference(self):
        """Builds the difference datframe of the two dimensions."""

        # Calculates the join expression between the two dimensions depending on whether we have Meta or Data dimensions
        name = "EXPECTED" * (self.type == "data") + "MATCH" * (
            1 - (self.type == "data")
        )
        expression = None
        for i, col in enumerate(self.cols):
            e = self.expected_df[f"{col}_{name}"] == self.actual_df[f"{col}_ACTUAL"]
            if i == 0:
                expression = e
            else:
                expression = expression & e

        # Build the difference dataframe with a limit of rows to consider
        self.df_difference = self.expected_df.join(
            self.actual_df, expression, how="full_outer"
        )

        if self.type == "data":
            # Fill na values and case fact columns to decimal for Data dimensions
            self.df_difference = self.df_difference.fillna(
                0.0,
                subset=(
                    [f"{c}_EXPECTED" for c in self.facts]
                    + [f"{c}_ACTUAL" for c in self.facts]
                ),
            )
            # Create difference and ratio
            for f in self.facts:
                self.df_difference = self.df_difference.withColumn(
                    f"{f}_DIFFERENCE",
                    F.abs(F.col(f"{f}_EXPECTED") - F.col(f"{f}_ACTUAL")),
                )
                self.df_difference = self.df_difference.withColumn(
                    f"{f}_RATIO", F.col(f"{f}_DIFFERENCE") / F.col(f"{f}_EXPECTED")
                )

    def filter_difference_rows(self, threshold: Optional[float] = 0.0000001):
        """Keeps rows with at least one difference."""

        # Builds filtering expression to keep rows with at least one difference
        if self.type == "data":
            expression = (F.col("MARKET_TAG_EXPECTED").isNull()) | (
                F.col("MARKET_TAG_ACTUAL").isNull()
            )
            for i, f in enumerate(self.facts):
                expression |= (F.abs(F.col(f"{f}_RATIO")) > threshold) | (
                    F.col(f"{f}_RATIO").isNull() & (F.col(f"{f}_DIFFERENCE") != 0.0)
                )
        else:
            expression = None
            for i, c in enumerate(self.columns):
                e = (
                    (F.col(f"{c}_EXPECTED") != F.col(f"{c}_ACTUAL"))
                    | (
                        F.col(f"{c}_EXPECTED").isNull()
                        & F.col(f"{c}_ACTUAL").isNotNull()
                    )
                    | (
                        F.col(f"{c}_EXPECTED").isNotNull()
                        & F.col(f"{c}_ACTUAL").isNull()
                    )
                )
                if i == 0:
                    expression = e
                else:
                    expression |= e

        # Select rows corresponding to the filtering expression
        self.df_difference = self.df_difference.where(expression)

    def select_difference_columns(self):
        """Builds dataframe containing the [expected, actual] couples."""

        if self.type == "data":
            self.pdf = self.df_difference.select(
                [
                    F.array_distinct(
                        F.array(F.col(f"{c}_EXPECTED"), F.col(f"{c}_ACTUAL"))
                    ).alias(c)
                    for c in self.cols
                ]
                + [
                    F.array(F.col(f"{c}_EXPECTED"), F.col(f"{c}_ACTUAL")).alias(c)
                    for c in self.facts
                ]
            ).toPandas()

        else:
            self.pdf = (
                self.df_difference.select(
                    [
                        F.array(F.col(f"{c}_EXPECTED"), F.col(f"{c}_ACTUAL")).alias(c)
                        for c in self.columns
                    ]
                )
                .select([F.array_distinct(F.col(c)).alias(c) for c in self.columns])
                .toPandas()
            )

    def sort_table(self):
        """Sort and group the difference table columns and rows."""

        # Builds a table of filled values from the difference dataframe
        self.pdf = [
            list(map(duplicates_single_values, self.pdf[col])) for col in self.columns
        ]
        n, m = len(self.pdf[0]), len(self.pdf)

        # Initializes the table indexes to sort
        group_lists = [range(n)]

        # Defines the indexes of the columns to fix for each dimension
        fixed_columns_dict = {
            "market": [
                "TAG",
                "SHORT",
                "LONG",
                "DISPLAY_ORDER",
            ],
            "product": ["TAG", "SHORT", "LONG", "DISPLAY_ORDER"],
            "fact": ["TAG", "SHORT", "LONG", "DISPLAY_ORDER"],
            "period": ["TAG", "SHORT", "LONG", "DISPLAY_ORDER"],
            "data": ["MARKET_TAG", "PRODUCT_TAG", "PERIOD_TAG"],
        }
        fixed_columns = fixed_columns_dict[self.type]
        self.fixed_columns_indexes = [
            self.columns.index(col) for col in fixed_columns if col in self.columns
        ]

        # Sort the table columns depending on how fulle they are
        sorted_columns = sort_columns(
            self.columns, self.pdf, self.fixed_columns_indexes
        )

        # Sort the first column of the difference table according to their similarity
        sorted_list = sort_list([self.pdf[0][i] for i in range(n)])

        # Sort the columns and the first column of the table
        self.pdf = [
            [self.pdf[sorted_columns[k]][sorted_list[i]] for i in range(n)]
            for k in range(m)
        ]

        # Calculates the color class for each cell of the table
        self.strings_table = [compare_list(self.pdf[0])] + [
            ["Na" for i in range(n)] for k in range(m - 1)
        ]

        # Sort groups of table rows at each step
        for k in range(1, m):
            tab = deepcopy(self.pdf)

            # Adds next table indexes to sort
            gr = []
            for group in group_lists:
                # Adds indexes of equal cells to sort
                Eq = list(filter(lambda x: self.strings_table[k - 1][x] == "Eq", group))
                if len(Eq) > 1:
                    gr.append(Eq)

                # Adds indexes of similar cells to sort
                Sm = list(filter(lambda x: self.strings_table[k - 1][x] == "Sm", group))
                if len(Sm) > 1:
                    gr.append(Sm)

                # Adds indexes of expected cells to sort
                Ex = list(filter(lambda x: self.strings_table[k - 1][x] == "Ex", group))
                if len(Ex) > 1:
                    gr.append(Ex)

                # Adds indexes of actual cells to sort
                Ac = list(filter(lambda x: self.strings_table[k - 1][x] == "Ac", group))
                if len(Ac) > 1:
                    gr.append(Ac)

            group_lists = gr

            # Sort the rows of the selected indexes
            for group in group_lists:

                # Calculates the sorted indexes corresponding depending on the similarity of the cells
                sorted_list = sort_list([tab[k][i] for i in group])
                for i, x in enumerate(group):
                    for b in range(m):

                        # Updates the values of the difference table with the sorted ones
                        self.pdf[b][x] = tab[b][group[sorted_list[i]]]

            # Updates the table of color class for the step k
            self.strings_table[k] = compare_list(self.pdf[k])

        # Modifies the color class of the cells coming after 'Df' cells to 'Un' in order not to display them
        for i in range(n):
            string_table_k = [self.strings_table[k][i] for k in range(m)][0:-1]
            if "Df" in string_table_k:
                for k in range(string_table_k.index("Df") + 1, m):
                    if not self.strings_table[k][i] == "Na":
                        self.strings_table[k][i] = "Un"

        # Updates the difference table columns with the sorted ones
        self.columns = [self.columns[col] for col in sorted_columns]

        self.dim_calculations["cards"]["number_of_columns_difference"] = len(self.pdf)
        self.dim_calculations["cards"]["number_of_distinct_difference"] = len(
            self.pdf[0]
        )

        self.dim_calculations["cards"]["specific_rows_expected"] = self.strings_table[
            0
        ].count("Ac")
        self.dim_calculations["cards"]["specific_rows_actual"] = self.strings_table[
            0
        ].count("Ex")

    def html_table(self):
        """Creates the HTML string corresponding to the difference table."""

        # Checks if the table is empty or not: if so show a paragraph to tell that the table is empty, else display the table
        n, m = len(self.pdf[0]), len(self.pdf)
        if n == 0:
            # The table is empty
            table_html_string = f"<div class='table_string'><i class='col-12 fas fa-file fa-5x mb-5 text-center'></i><p>There is no difference between the two {self.type.capitalize()} dimensions !</p></div>"
            groups_lengths = {}

        else:
            columns = deepcopy(self.columns)
            pdf = deepcopy(self.pdf)
            strings_table = deepcopy(self.strings_table)
            for i, col in enumerate(columns):
                if col == "DISPLAY_ORDER":
                    # Rename 'DISPLAY_ORDER' column name to 'N°' and move it to the beginning of the table'
                    self.columns[0] = "RANK #"
                    self.pdf[0] = pdf[i]
                    self.strings_table[0] = strings_table[i]
                    # Change the index of the columns which were before 'DISPLAY ORDER' and updates the different tables of comparison
                    for k in range(i):
                        self.columns[k + 1] = columns[k]
                        self.pdf[k + 1] = pdf[k]
                        self.strings_table[k + 1] = strings_table[k]

                # Create the HTML string corresponding to the head of the difference table
                html_columns_string = reduce(
                    lambda a, b: a + b,
                    [f"<th colspan='2'>{col}</th>" for col in self.columns],
                )
            # Create the HTML string corresponding to the body of the difference table
            body = ""
            groupable, rows_dict, groups_lengths = group_table(
                [[self.strings_table[i][k] for i in range(m)] for k in range(n)]
            )
            for i in rows_dict:
                html_strings_row = [
                    html_cell_string(self.pdf[k][i], self.strings_table[k][i], k)
                    for k in range(m)
                ]

                # Add the group of neighbours as a class of the rows when the table is groupable
                tr_class = f"class='grp{rows_dict[i]}'" * groupable
                body += f"<tr {tr_class}'>{reduce(lambda a, b: a + b, html_strings_row)}</tr>"

            # Creates the HTML string corresponding to the complete difference table
            table_html_string = f"<thead><tr class='thead-dark {'grp'*groupable}'>{html_columns_string}</tr></thead><tbody>{body}</tbody>"

        self.dim_calculations["cards"]["table_html_string"] = table_html_string
        self.dim_calculations["cards"]["groups_lengths"] = groups_lengths

    def calculate_difference_and_create_html_string(self):
        # Select common columns
        self.select_columns()

        # Match and Join expected and actual dataframes depending on whether we have MetaData or Data dimensions
        self.match_columns_table()

        # Rename actual and expected columns
        self.rename_columns()

        # Builds the difference datframe of the two dimensions
        self.calculate_difference()

        # Filter to keep rows with at least one difference
        self.filter_difference_rows()

        # Build dataframe containing the [expected, actual] couples
        self.select_difference_columns()

        # Sort and group the difference table columns and rows
        self.sort_table()

        # Create the HTML string corresponding to the difference table
        self.html_table()
