from difflib import SequenceMatcher, get_close_matches
from functools import reduce
from typing import Optional

import importlib_resources
import numpy as np
from rdslm_sff_comparison import templates


def unique(variable):
    """Remove duplicates of a collection and return it in the same order.

    Args:
        variable: Collection of elements e.g. `"['2', 3, 'a', '3', 'a', 3]"`.

    Returns:
        A list of one-time elements of the collection e.g. `"['2', 3, 'a', '3']"`.
    """
    var = []
    for x in variable:
        if x not in var:
            var.append(x)
    return var


def compare_values(
    a,
    b,
    ratio: Optional[float] = 0.8,
    limit_dif: Optional[float] = 0.0000001,
    limit_ratio: Optional[float] = 0.0000001,
):
    """Checks if two values (strings, integers or None) are equal, similar or if one of them is undefined.

    Args:
        a: first value.
        b: second value.
        ratio: Limit above which the two values are considered similar if they are strings.
        limit_dif: Difference above which the two values are considered different if they are integers.
        limit_dif: Ratio above which the two values are considered different if they are integers.

    Returns:
        A string corresponding to different similarity situations.
        e.g. `"Sm"` if the values are similar strings.
    """

    # Checks if one or both of the value are undefined
    if a is None and b is None:
        return "Eq"
    else:
        if a is None:
            return "Ex"
        elif b is None:
            return "Ac"
        else:
            if a == b:
                return "Eq"
            else:
                try:
                    if type(a) == str or type(b) == str:

                        # Checks if the values are enough similar
                        a, b = a.lower().replace("_", "").replace(
                            " ", ""
                        ), b.lower().replace("_", "").replace(" ", "")

                        if SequenceMatcher(None, a, b).ratio() > ratio:
                            return "Sm"
                        return "Df"

                    if type(a) in {float, int} or type(b) in {float, int}:

                        # Checks if the values are quite equal
                        if a == 0 and not b == 0:
                            if abs(b) > limit_dif:
                                return "Df"
                            return "Sm"
                        elif (not a == 0) and b == 0:
                            if abs(a) > limit_dif:
                                return "Df"
                            return "Sm"
                        else:
                            if abs(a - b) > limit_dif or abs(1 - a / b) > limit_ratio:
                                return "Df"
                            return "Sm"
                except AttributeError:
                    return "Na"


def match_columns_lists(a, b, ratio):
    """Identifies pairs of similar or equal values between two lists.

    Args:
        a: First list of strings. eg `["apple", "ananas", "banana"]`
        b: Second list of strings. eg `["strawberry", "Banane", "ananas"]`
        ratio: Limit above which the two values are considered similar.

    Returns:
        List of similar pairs between the first and the second list.
        eg `[["banana":"Banane"],["ananas","ananas"]]`
    """
    # Checks which list is smaller in order to lower the calculations
    reverse = False
    if len(a) < len(b):
        reverse = True
        a, b = b, a

    # Associates for each value of the first list the closest matching word
    # in the second list if there is one and None else
    similar = []
    for word in a:
        try:
            replace_word = word.lower().replace("_", "").replace(" ", "")
            replace_b = dict(
                zip([x.lower().replace("_", "").replace(" ", "") for x in b], b)
            )

            match_word = get_close_matches(
                replace_word, list(replace_b.keys()), n=1, cutoff=ratio
            )[0]
            replacement = replace_b[match_word]
            if replacement not in [x[1] for x in similar]:
                similar.append([word, replacement])
            else:
                similar.append([word, None])
        except IndexError:
            similar.append([word, None])

    # Reverses the dictionnary items if the lists a and b have been reversed
    if reverse:
        similar = [[x[1], x[0]] for x in similar]

    return similar


def compare_list(pairs):
    """Calculates the similarity of each pair for a list of pairs of strings.

    Args:
        pairs: List of pairs of strings.
        eg `[["banana","Banane"],["ananas","ananas"],["apple","strawberry"]]`

    Returns:
        List of strings corresponding to their similarity calculated with compare_value() function.
        eg `["Sm", "Eq", "Df"]`
    """
    return [compare_values(combi[0], combi[1]) for combi in pairs]


def sort_list(pairs):
    """Order a list of pair of strings according to their similarity. Equal values come first, then similar ones, and so on.

    Args:
        liste: List of pairs of strings.
        eg `[("banana","Banane"),("apple","strawberry"),("ananas","ananas")]`

    Returns:
        Dictionnary representing the permutation of the sorted values.
        eg `{0:2, 1:0, 2:1}`
    """

    # Calculates the similarity of each pair for the list pairs
    li = compare_list(pairs)

    return dict(
        zip(
            [i for i in range(len(pairs))],
            [
                i
                for y in ["Eq", "Sm", "Ac", "Ex", "Df", "Na"]
                for i, x in enumerate(li)
                if x == y
            ],
        )
    )


def sort_columns(columns, table, fixed_columns: Optional[list] = [0]):
    """Sorts the columns of a table according to how full they are.

    Args:
        table: List of lists.
        fixed_columns: Indexes of the columns not to be ordered.

    Returns:
        List of the indexes of the sorted columns.
    """

    empty_columns = [i for i in range(len(table)) if i not in fixed_columns]

    # Sorts the non fixed columns of a table according to how full they are
    sorted_empty_columns = np.argsort(
        [table[i].count([None, None]) for i in empty_columns]
    )
    non_fixed_columns_sorted = [empty_columns[i] for i in sorted_empty_columns]

    hierearchy_columns = []
    for col in ["HIER_NUM", "HIER_NAME", "HIER_LEVEL_NUM", "HIER_LEVEL_NAME"]:
        if col in columns:
            if columns.index(col) in non_fixed_columns_sorted:
                hierearchy_columns.append(columns.index(col))
    non_hierearchy_columns = [
        index for index in non_fixed_columns_sorted if index not in hierearchy_columns
    ]

    if len(hierearchy_columns) > 0:
        a_indice = min([non_fixed_columns_sorted.index(x) for x in hierearchy_columns])
        return (
            fixed_columns
            + non_hierearchy_columns[0:a_indice]
            + hierearchy_columns
            + non_hierearchy_columns[a_indice:]
        )
    else:
        return fixed_columns + non_fixed_columns_sorted


def duplicates_single_values(values):
    """Fills missing value for a list and duplicates them if they are single.

    Args:
        values: List of one or two values.

    Returns:
        List of two values filled.
    """

    # Fills the missing values
    for i, x in enumerate(values):
        if type(x) not in [str, float, int]:
            values[i] = None

    # Duplicates single values
    if len(values) == 1:
        return [values[0], values[0]]
    return values


def concatenate_values(values, string):
    """Concatenates the values list and associates a string to that list.

    Args:
        values: List of two values.
        string: String calculated with compare_value.

    Returns:
        Concatanated values and a new corresponding string.
    """

    concatenated = [""]
    d = string
    if string == "Eq":
        if values[0] is None:
            d = "Na"
        else:
            concatenated = [str(values[0])]
    elif string == "Ac":
        concatenated = [str(values[0])]
    elif string == "Ex":
        concatenated = [str(values[1])]
    elif string in ["Sm", "Df"]:
        concatenated = [str(values[0]), str(values[1])]
    elif string == "Un":
        out = []
        for x in values:
            if (x not in out) and (x is not None):
                out.append(x)
        if out == []:
            d = "Na"
        else:
            concatenated = [str(x) for x in out]
    return concatenated, d


def convex_rows(values, indexes=None):
    """Find similar neighboring values in the list 'values' among the indexes given.

    Args:
        values: List of values eg `[1, 1, 1, 3, 2, 5]`.
        indexes: List of given indexes.

    Returns:
        Dictionnary with as keys the given indexes and as values the index of the first similar neighboring values eg `{0:0, 1:0, 2:0, 3:None, 4:None, 5:None]`.
    """

    # If no list of indexes is specified all the values are compared
    if not indexes:
        indexes = range(len(values))

    # Select the values corresponding to the indexes given
    values = [values[i] for i in indexes]
    convex = {x: None for x in indexes}
    index = 0
    for k in range(len(values) - 1):
        # Affect the first similar neighboring values to the dict convex if it exist
        if values[k + 1] == values[k]:
            convex[indexes[k + 1]] = indexes[index]
            convex[indexes[k]] = indexes[index]
        else:
            index = k + 1
    return convex


def group_table(table):
    """Group the equal neighbors of a table and choose the values to display according to the group of neighbors they belong to.

    Args:
        table: List of values eg `[1, 1, 1, 3, 2, 5]`.

    Returns:
        A boolean which tells if the table is grouped or not,
        A dictionnary with as keys the choosen indexes and as values the index of the first similar neighboring values eg `{0:0, 1:0, 2:0, 3:None, 4:None, 5:None],
        A dictionnary with as keys the names of the neighboiring groups and as values their lenghts eg `{'grp3':2, 'grp2':1, 'grp5':3],.
    """

    n = len(table)
    indexes = range(n)

    # If you don't have many values the table is not grouped
    if n < 30:
        groups_dict = {k: None for k in indexes}

    # If have many values the table is grouped
    else:
        # if you don't have too many values the frontend wont be able to display them and we need to choose which we will display
        if n >= 500:
            # Group the similar neighboring values in the table
            indexes = []
            convex = convex_rows(table)

            # For each group pick values to display: at least one value and proportionnally to the total number of values
            for val in set(convex.values()):
                group = [x for x in convex if convex[x] == val]
                indexes += list(
                    np.random.choice(
                        group, max(1, round(len(group) * 500 / n)), replace=False
                    )
                )

        # Group the equal neighbors of the table with the choosen indexes to display
        groups_dict = convex_rows(table, sorted(indexes))

    # Define the length of each group and if the table have been grouped or not
    lengths = {
        f"grp{val}": list(groups_dict.values()).count(val)
        for val in set(groups_dict.values()) - {None}
    }
    groupable = len(lengths) > 0

    return groupable, groups_dict, lengths


def html_cell_string(values, string, rank):
    """Associates an HTML string with a color depending on the string.

    Args:
        values: List of two values.
        string: String specifying the type of similarity of the values.

    Returns:
        String corresponding to the HTML code of a cell in a table.
    """

    string_list = concatenate_values(values, string)

    # Calculates the colspan corresponding to the cell
    colspan = 3 - len(string_list[0])

    # Calculates the color class corresponding to the cell
    color_class = string_list[1] * (not rank == 0) + "first_cell" * (rank == 0)

    HTML_code = ""
    for x in string_list[0]:
        HTML_code += f"<td colspan='{colspan}' class='{color_class}'> {x} </td>"
    return HTML_code


def html_report_table_cell_string(values):
    """Concatenate the elements in values if they are similar and create a tuple of values to be used create the associated HTML string of the list 'values'.

    Args:
        values: List of two values that can be lists and/or strings.

    Returns:
        A tuple of values to be used create the associated HTML string of the list 'values'.
    """

    # The elements of the list 'values' are concatenated into strings
    defined_values = []
    for val in values:
        if len(val) > 0:
            if type(val) in [set, list]:
                defined_values.append(reduce(lambda a, b: f"{str(a)},  {str(b)}", val))
            else:
                defined_values.append(str(val))

    # Removal of duplicates among the concatenated strings list
    defined_values = unique(defined_values)
    number = len(defined_values)
    font = "font-weight-bold"

    # Calculate values to be used in the corresponding HTML cell of 'values'
    if number == 0:
        defined_values = ["None"]
        text = [""]
        number = 1
        font = ""
    elif number == 1:
        text = [
            "text-actual" * (len(values[0]) == 0)
            + "text-expected" * (len(values[1]) == 0)
        ]
    elif number == 2:
        text = ["text-expected", "text-actual"]
    return number, font, text, defined_values


def html_report_table_dimension_string(dim, calculations):
    """Create the HTML string associated to the report table for each dimension.

    Args:
        dim: The dimension to display in the report table eg `'market'`.
        calculations: Dictionnary with as keys the name of the calculation to perform for a dimension and as values a tuple corresponding to the calculation performed on the expected and actual tables  eg `{'Ignored columns': (['PARENT_TAG', 'HIER_NUM'], ['HIER_LEVEL_NAME'])}`.

    Returns:
        A string corresponding to the HTML expression of the report table for the dimension.
    """

    string = ""
    for rank, item in enumerate(calculations.items()):
        name, values = item[0], [[] if x is None else x for x in item[1]]
        values = [str(x) if type(x) in [int, float] else x for x in values]
        number, font, text, defined_values = html_report_table_cell_string(values)

        string += "<tr class='text-center'>"
        if rank == 0:
            string += f"<th style='vertical-align: middle; min-width:8vw; max-width:8vw' rowspan='{len(calculations)}' class='align-middle h6'>{dim.upper()}</th>"
        string += f"<th class='align-middle h6' style='padding-top:12px; padding-bottom:12px; min-width:17vw; max-width:17vw'>{name.upper()}</th>"

        width = {
            1: ["min-width:26vw; max-width:26vw;", "min-width:22vw; max-width:22vw"],
            2: ["min-width:53vw; max-width:53vw;", "min-width:49vw; max-width:49vw"],
        }
        for i in range(number):
            string += f"<td class='align-middle h6 {font} {text[i]} report_td' style='{width[3-number][0]}' colspan='{3-number}'><div style='margin:auto; {width[3-number][1]}'>{defined_values[i]}</div></td>"
        string += "</tr>"
    return string


def get_template_text(name):
    return importlib_resources.read_text(templates, name)
