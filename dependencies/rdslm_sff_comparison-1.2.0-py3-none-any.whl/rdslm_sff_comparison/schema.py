import logging
import os
import sys

import pyspark.sql.functions as F
import rdslibrary as rds
from rdslibrary.utilities.spark import get_dbutils, get_spark
from rdslm_sff_comparison.dimension import dimension
from rdslm_sff_comparison.utilities.utilities import (
    get_template_text,
    html_report_table_dimension_string,
)

spark = get_spark()
dbutils = get_dbutils(spark)


class schema:
    """Class computing the difference of two schemas.

    Attributes:
        expected: MetaData or Data object from the expected files.
        actual: MetaData or Data object from the actual files.
        comparison_dimensions: Dictionary with as keys the dimensions to compare and as values the list of columns to ignore.
        keys: Set of the dimensions of comparison.
        schema_variables: Dictionary to store values that will be displayed in the frontend.
        js: String of the output file's script.
        css: String of the output file's style.
        html: String of the output file.
        aggregation: Sum of a random common fact for the newest common period between the two dimensions.
    """

    def __init__(self, expected_path, actual_path, output_path, comparison_dimensions):
        """Class constructor.

        Args:
            expected_path: Path to the directory of expected files. `"dbfs:/mnt/lab_mount/makhtar/sff_comparison/expected"`.
            actual_path: Path to the directory of actual files. `"dbfs:/mnt/lab_mount/makhtar/sff_comparison/actual"`.
            output_path: Path to the directory of the output file. e.g. `"dbfs:/mnt/lab_mount/makhtar/sff_comparison"`.
            comparison_dimensions: Dictionary with as keys the dimensions to compare and as values the list of columns to ignore.
            for each dimension e.g. `{'market':['SHORT','LONG','HIER_NUM'], 'period':[], 'fact':['PER_AGGREGATION'], 'data':[]}`.

        Raises:
            ValueError: If no dimension of comparison is specified in the dictionary.
        """

        # Initialize logger
        logging.basicConfig(
            stream=sys.stdout,
            level=logging.DEBUG,
            format="\n\n %(asctime)s - %(levelname)s - %(message)s",
        )
        logging.getLogger("py4j").setLevel(logging.ERROR)  # Limit cluster logging
        self.logger = logging.getLogger(__name__)

        self.comparison_dimensions = comparison_dimensions
        self.keys = set(comparison_dimensions.keys())
        if len(self.keys) == 0:
            raise ValueError("No dimension of comparison selected.")

        # Creates a dictionary to store values that will be displayed in the frontend
        self.schema_variables = {}
        self.schema_variables["expected_path"] = expected_path
        self.schema_variables["actual_path"] = actual_path
        self.schema_variables["output_path"] = output_path
        self.schema_variables["comparison_dimensions"] = list(self.keys)
        self.schema_variables["ignored_dimensions"] = [
            x
            for x in ["market", "product", "period", "fact", "data"]
            if x not in self.keys
        ]

        # Read the HTML, CSS and JavaSript files
        self.js = get_template_text("template.js")
        self.css = get_template_text("template.css")
        self.html = get_template_text("template.html")

        # Read the SFF files of the two dimensions
        self.logger.info(
            f"Starting reading the SFF files from '{expected_path}' and actual='{actual_path}'."
        )
        self.expected = rds.read().blob(expected_path)
        self.actual = rds.read().blob(actual_path)
        self.logger.info("Finished reading the SFF files.")
        expected_data = self.expected.data.df
        actual_data = self.actual.data.df

        for dim in [
            x for x in ["market", "product", "period", "fact", "data"] if x in self.keys
        ]:
            self.logger.info(
                f"Started building the difference dataframe for the {dim} dimension."
            )
            # Define for each dimension in the comparison_dimensions dictionary
            difference = dimension(
                getattr(self.expected, dim),
                getattr(self.actual, dim),
                self.comparison_dimensions[dim],
            )
            # Create HTML string table from the expected and actual files
            difference.calculate_difference_and_create_html_string()

            # Set to self the dimension class
            setattr(self, dim, difference)
            self.logger.info(
                f"Finished building the difference dataframe for the {dim} dimension."
            )

        # Compute the tags of the MetaData dimensions different of fact which are in the data dimension
        # and if data is among the comparison dimensions, get the list of common periods of the two schema
        for dim in {"market", "product", "period", "data"} & self.keys:
            dim = dim.replace("data", "period")
            tag = dim.upper() + "_TAG"
            tags_expected = set(expected_data.select([tag]).toPandas()[tag])
            tags_actual = set(actual_data.select([tag]).toPandas()[tag])
            setattr(self, f"{dim}s_in_data", (tags_expected, tags_actual))
            # Get the list of common periods for Period or Data dimensions and set the latest_period variable
            # if we have data or period among the comparison dimensions
            if dim == "period":
                common_periods = sorted(tags_expected & tags_actual)

        # Compute the fact tags which are in the data dimension and get the list of common facts of the two schema
        for dim in {"fact", "data"} & self.keys:
            cols = ["MARKET_TAG", "PRODUCT_TAG", "PERIOD_TAG"]
            fact_tags_expected = set(expected_data.columns) - set(cols)
            fact_tags_actual = set(actual_data.columns) - set(cols)
            self.facts_in_data = fact_tags_expected, fact_tags_actual
            common_facts = sorted(fact_tags_expected & fact_tags_actual)

        # Get the sum of a random common fact for periods equal to the newest common period between the two dimensions
        if "data" in self.keys:
            try:
                common_fact = common_facts[-1]
                common_period = common_periods[-1]
                expected_agg = (
                    expected_data.where(F.col("PERIOD_TAG") == f"{common_period}")
                    .agg({f"{common_fact}": "sum"})
                    .first()[0]
                )
                actual_agg = (
                    actual_data.where(F.col("PERIOD_TAG") == f"{common_period}")
                    .agg({f"{common_fact}": "sum"})
                    .first()[0]
                )
                self.aggregation = expected_agg, actual_agg, common_fact, common_period
            except IndexError:
                # if there is no common fact or common period the aggregation calculation is undefined
                self.aggregation = None

        self.schema_variables["latest_period_expected"] = expected_data.agg(
            {"PERIOD_TAG": "max"}
        ).first()[0]
        self.schema_variables["latest_period_actual"] = actual_data.agg(
            {"PERIOD_TAG": "max"}
        ).first()[0]

    def replace_variable_with(self, js_var, var):
        """Replaces the javascript variable 'js_var' with the variable 'var' in self.js.

        Args:
            js_var: String corresponding to a javascript variable defined in the template.
            e.g. `"number_of_columns_difference"`.
            var: Integer or string with which js_var is replaced.
        """

        if type(var) == str or (var is None):
            self.js = self.js.replace(
                f"var {js_var} = NaN;", f'var {js_var} = "{var}";'
            )
        else:
            self.js = self.js.replace(f"var {js_var} = NaN;", f"var {js_var} = {var};")

    def replace_schema_variables(self):
        """Replace the schema variables with their computed values."""

        # Get the javascript values for each dimension of comparison and replace them in the HTML string
        for js_var, python_val in self.schema_variables.items():
            self.replace_variable_with(js_var, python_val)

    def replace_javascript_variables(self):
        """Replace the javascript variables with their computed values for each dimension."""

        variables_list = [
            "table_html_string",
            "number_of_columns_difference",
            "number_of_distinct_difference",
            "specific_rows_expected",
            "specific_rows_actual",
            "number_of_columns_expected",
            "number_of_columns_actual",
            "total_number_expected",
            "total_number_actual",
            "groups_lengths",
        ]
        variables_dict = {variable: {} for variable in variables_list}
        for dim in [
            x for x in ["market", "product", "period", "fact", "data"] if x in self.keys
        ]:
            # Get the javascript values for each dimension of comparison and replace them in the HTML string
            cards_details = getattr(self, dim).dim_calculations["cards"]
            for js_var, python_val in cards_details.items():
                variables_dict[js_var][dim] = python_val
        for js_var, var_dict in variables_dict.items():
            self.replace_variable_with(js_var, var_dict)

    def get_report_calculations(self, dim):
        """Get the calculations made for the report table for a given dimension.

        Args:
            dim: Dimension of comparison e.g. `"market"`.

        Returns:
            Dictionary with as keys the name that will be displayed for each calculation and as key its value.
        """

        # Get the calculations made from the dimension for the report table
        dim_calulations = getattr(self, dim).dim_calculations["report"]

        # Create the dictionary of calculated values and their names
        details = {
            "Ignored columns": dim_calulations["ignored_columns"],
            "Specific columns": dim_calulations["specific_columns"],
        }
        if not dim == "data":
            # Compute the missing tags of the dimension if it is a MetaData dimension
            list_of_tags_missing_in_data = list(
                map(
                    lambda x: x[0] - x[1],
                    zip(dim_calulations["tags"], getattr(self, f"{dim}s_in_data")),
                )
            )
            details[f"{dim}s not in data".capitalize()] = list_of_tags_missing_in_data
        else:
            # Compute the latest period and the aggregation calculation if it is a Data dimension
            details["Latest period"] = dim_calulations["latest_periods"]
            if self.aggregation:
                name = f"Sum of '{self.aggregation[2]}' <br> at period '{self.aggregation[3]}'"
                details[name] = self.aggregation[0:2]
            else:
                details["Data aggregation"] = None

        if dim == "period":
            # Compute the latest period if it is a Period dimension
            details["Latest period"] = dim_calulations["latest_periods"]

        return details

    def replace_report_table(self):
        """Build the report table and replaces the javascript variable corresponding."""

        report_table = ""
        # Get the calculations made for the report table for each dimension of comparison
        for dim in [
            x for x in ["market", "product", "period", "fact", "data"] if x in self.keys
        ]:
            report_table_details = self.get_report_calculations(dim)
            # Append the HTML string corresponding to those calculations in the report table HTML string
            report_table += html_report_table_dimension_string(
                dim, report_table_details
            )
        self.replace_variable_with("report_table", report_table)

    def replace_html_markers(self):
        """Replace in the HTML string the markers corresponding to the Javascript code and the CSS style."""

        # Replaces in the HTML string the markers corresponding to the Javascript code
        self.html = self.html.replace(
            "<script></script>", "<script>" + self.js + "</script>"
        )

        # Replaces in the HTML string the markers corresponding to the CSS style
        self.html = self.html.replace(
            "<style></style>", "<style>" + self.css + "</style>"
        )

    def upload_file(self):
        """Upldoad the output file in an Azure directory when specificed."""

        output_path = self.schema_variables["output_path"]
        if not output_path == "":
            # Shows the expected path marker in the HTML file if specified
            self.html = self.html.replace(
                '$("#output_path").hide();', '$("#output_path").show();'
            )
            # Write index.html file in the directory output specified in the parameters
            dbutils.fs.put(os.path.join(output_path, "index.html"), self.html, True)
            self.logger.info(f"The directory of the output path is {output_path}.")

    def display(self):
        """Replaces all Javascript and CSS markers in the HTML string."""

        self.logger.info("Displaying the difference dataframe in HTML format.")

        # Replace the schema variables with their computed values
        self.replace_schema_variables()

        # Replace the javascript variables with their computed values for each dimension
        self.replace_javascript_variables()

        # Replace in the HTML string the markers corresponding to the report table
        self.replace_report_table()

        # Replace in the HTML string the markers corresponding to the Javascript code and the CSS style
        self.replace_html_markers()

        # Upldoad the output file in an Azure directory when specificed
        self.upload_file()

        self.logger.info("Schema comparison finished.")
